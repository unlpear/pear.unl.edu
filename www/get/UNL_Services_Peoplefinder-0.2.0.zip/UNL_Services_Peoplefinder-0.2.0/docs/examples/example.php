<?php
require_once 'UNL/Services/Peoplefinder.php';
$uid = 'bbieber2';
echo 'The user '.$uid.' is '.UNL_Services_Peoplefinder::getFullName($uid);

?>