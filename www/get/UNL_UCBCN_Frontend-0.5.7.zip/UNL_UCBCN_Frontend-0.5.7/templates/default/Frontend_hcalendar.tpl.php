<?php
/**
 * This template file is the basis for the hcalendar output.
 */
UNL_UCBCN::displayRegion($this->output);
?>