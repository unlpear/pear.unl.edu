<h1>Events for the week of </h1>
<?php
/**
 * HTML Output template for a week view.
 */
UNL_UCBCN::displayRegion($this->output);
?>