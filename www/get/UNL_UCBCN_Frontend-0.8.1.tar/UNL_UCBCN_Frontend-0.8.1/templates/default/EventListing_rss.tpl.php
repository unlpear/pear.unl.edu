<?php
/**
 * This is the output for an event listing in rss format.
 * @package UNL_UCBCN_Frontend
 */
UNL_UCBCN::outputTemplate('UNL_UCBCN_EventInstance','EventInstance_rss');
UNL_UCBCN::displayRegion($this->events);
?>