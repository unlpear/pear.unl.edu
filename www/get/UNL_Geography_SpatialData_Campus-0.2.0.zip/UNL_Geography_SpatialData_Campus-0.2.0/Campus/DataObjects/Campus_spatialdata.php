<?php
/**
 * Table Definition for campus_spatialdata
 */
require_once 'DB/DataObject.php';

class UNL_Geography_SpatialData_Campus_DataObjects_Campus_spatialdata extends DB_DataObject 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__table = 'campus_spatialdata';              // table name
    public $id;                              // int(11)  not_null primary_key auto_increment
    public $code;                            // string(10)  not_null unique_key
    public $lat;                             // real(16)  not_null
    public $lon;                             // real(16)  not_null

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('UNL_Geography_SpatialData_Campus_DataObjects_Campus_spatialdata',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
