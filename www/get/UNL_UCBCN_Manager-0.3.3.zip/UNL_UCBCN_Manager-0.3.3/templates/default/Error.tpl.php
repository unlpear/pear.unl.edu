<div class='error'>
<h3>Error</h3>
<?php echo $this->message; ?>
</div>