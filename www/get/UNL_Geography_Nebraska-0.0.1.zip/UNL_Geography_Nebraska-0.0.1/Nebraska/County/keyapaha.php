<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_keyapaha extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_keyapaha()
	{
		$this->_cities = array(
			'burton' => 'Burton',
			'mills' => 'Mills',
			'norden' => 'Norden',
			'springview' => 'Springview',
		);
	}

	function countyName()
	{
		return 'Keya Paha';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="KeyaPahaCounty" id="KeyaPahaCounty">' .
			'<area shape="rect" coords="421, 28, 470, 60" href="' . sprintf($urlpattern, 'mills') . '" alt="Mills"/>' .
			'<area shape="rect" coords="336, 45, 404, 83" href="' . sprintf($urlpattern, 'burton') . '" alt="Burton"/>' .
			'<area shape="rect" coords="240, 101, 323, 134" href="' . sprintf($urlpattern, 'springview') . '" alt="Springview"/>' .
			'<area shape="rect" coords="50, 67, 129, 98" href="' . sprintf($urlpattern, 'norden') . '" alt="Norden"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'KeyaPahaCounty';
	}	
	
	function imageMapImage() {
		return 'keyapaha.gif';
	}
	
}