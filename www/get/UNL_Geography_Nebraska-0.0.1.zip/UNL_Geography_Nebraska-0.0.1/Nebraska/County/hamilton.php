<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_hamilton extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_hamilton()
	{
		$this->_cities = array(
			'aurora' => 'Aurora',
			'giltner' => 'Giltner',
			'hampton' => 'Hampton',
			'hordville' => 'Hordville',
			'marquette' => 'Marquette',
			'phillips' => 'Phillips',
			'stockham' => 'Stockham',
		);
	}

	function countyName()
	{
		return 'Hamilton';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="HamiltonCounty" id="HamiltonCounty">' .
			'<area shape="rect" coords="34, 187, 104, 224" href="' . sprintf($urlpattern, 'phillips') . '" alt="Phillips"/>' .
			'<area shape="rect" coords="70, 283, 141, 316" href="' . sprintf($urlpattern, 'giltner') . '" alt="Giltner"/>' .
			'<area shape="rect" coords="217, 325, 306, 359" href="' . sprintf($urlpattern, 'stockham') . '" alt="Stockham"/>' .
			'<area shape="rect" coords="181, 206, 250, 249" href="' . sprintf($urlpattern, 'aurora') . '" alt="Aurora"/>' .
			'<area shape="rect" coords="263, 193, 341, 233" href="' . sprintf($urlpattern, 'hampton') . '" alt="Hampton"/>' .
			'<area shape="rect" coords="161, 119, 262, 156" href="' . sprintf($urlpattern, 'marquette') . '" alt="Marquette"/>' .
			'<area shape="rect" coords="254, 60, 343, 99" href="' . sprintf($urlpattern, 'hordville') . '" alt="Hordville"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'HamiltonCounty';
	}	
	
	function imageMapImage() {
		return 'hamilton.gif';
	}
	
}