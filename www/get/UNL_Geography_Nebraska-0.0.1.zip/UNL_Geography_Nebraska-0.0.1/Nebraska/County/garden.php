<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_garden extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_garden()
	{
		$this->_cities = array(
			'lewellen' => 'Lewellen',
			'lisco' => 'Lisco',
			'oshkosh' => 'Oshkosh',
		);
	}

	function countyName()
	{
		return 'Garden';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="GardenCounty" id="GardenCounty">' .
			'<area shape="rect" coords="182, 266, 261, 297" href="' . sprintf($urlpattern, 'lewellen') . '" alt="Lewellen"/>' .
			'<area shape="rect" coords="104, 234, 170, 270" href="' . sprintf($urlpattern, 'oshkosh') . '" alt="Oshkosh"/>' .
			'<area shape="rect" coords="17, 197, 74, 225" href="' . sprintf($urlpattern, 'lisco') . '" alt="Lisco"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'GardenCounty';
	}	
	
	function imageMapImage() {
		return 'garden.gif';
	}
	
}