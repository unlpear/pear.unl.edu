<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_clay extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_clay()
	{
		$this->_cities = array(
				'claycenter' => 'Clay Center',
				'deweese' => 'Deweese',
				'edgar' => 'Edgar',
				'fairfield' => 'Fairfield',
				'glenvil' => 'Glenvil',
				'harvard' => 'Harvard',
				'ong' => 'Ong',
				'saronville' => 'Saronville',
				'sutton' => 'Sutton',
				'trumbull' => 'Trumbull',
			);
	}

	function countyName()
	{
		return 'Clay';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="ClayCounty" id="ClayCounty">' .
			'<area shape="rect" coords="369, 250, 417, 286" href="' . sprintf($urlpattern, 'ong') . '" alt="Ong" />' .
			'<area shape="rect" coords="244, 276, 314, 309" href="' . sprintf($urlpattern, 'edgar') . '" alt="Edgar" />' .
			'<area shape="rect" coords="85, 290, 173, 321" href="' . sprintf($urlpattern, 'deweese') . '" alt="Deweese" />' .
			'<area shape="rect" coords="112, 217, 210, 255" href="' . sprintf($urlpattern, 'fairfield') . '" alt="Fairfield" />' .
			'<area shape="rect" coords="148, 138, 271, 176" href="' . sprintf($urlpattern, 'claycenter') . '" alt="Clay Center" />' .
			'<area shape="rect" coords="251, 82, 362, 116" href="' . sprintf($urlpattern, 'saronville') . '" alt="Saronville" />' .
			'<area shape="rect" coords="346, 65, 417, 97" href="' . sprintf($urlpattern, 'sutton') . '" alt="Sutton" />' .
			'<area shape="rect" coords="5, 152, 79, 195" href="' . sprintf($urlpattern, 'glenvil') . '" alt="Glenvil" />' .
			'<area shape="rect" coords="120, 50, 214, 91" href="' . sprintf($urlpattern, 'harvard') . '" alt="Harvard" />' .
			'<area shape="rect" coords="0, 3, 101, 35" href="' . sprintf($urlpattern, 'trumbull') . '" alt="Trumbull" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'ClayCounty';
	}	
	
	function imageMapImage() {
		return 'clay.gif';
	}
	
}