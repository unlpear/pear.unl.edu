<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_wheeler extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_wheeler()
	{
		$this->_cities = array(
			'bartlett' => 'Bartlett',
			'cumminsville' => 'Cumminsville',
			'ericson' => 'Ericson',
		);
	}

	function countyName()
	{
		return 'Wheeler';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="WheelerCounty" id="WheelerCounty">' .
			'<area shape="rect" coords="26, 207, 97, 242" href="' . sprintf($urlpattern, 'ericson') . '" alt="Ericson" />' .
			'<area shape="rect" coords="118, 136, 209, 163" href="' . sprintf($urlpattern, 'bartlett') . '" alt="Bartlett" />' .
			'<area shape="rect" coords="101, 49, 221, 83" href="' . sprintf($urlpattern, 'cumminsville') . '" alt="Cumminsville" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'WheelerCounty';
	}	
	
	function imageMapImage() {
		return 'wheeler.gif';
	}
	
}