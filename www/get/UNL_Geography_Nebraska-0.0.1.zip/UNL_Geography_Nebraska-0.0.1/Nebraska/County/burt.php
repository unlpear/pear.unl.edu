<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_burt extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_burt()
	{
		$this->_cities = array(
				'craig' => 'Craig',
				'decatur' => 'Decatur',
				'lyons' => 'Lyons',
				'oakland' => 'Oakland',
				'tekamah' => 'Tekamah',
			);
	}

	function countyName()
	{
		return 'Burt';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="BurtCounty" id="BurtCounty">' .
			'<area shape="rect" coords="186, 34, 262, 68" href="' . sprintf($urlpattern, 'decatur') . '" alt="Decatur"/>' .
			'<area shape="rect" coords="221, 188, 306, 226" href="' . sprintf($urlpattern, 'tekamah') . '" alt="Tekamah"/>' .
			'<area shape="rect" coords="126, 187, 186, 220" href="' . sprintf($urlpattern, 'craig') . '" alt="Craig"/>' .
			'<area shape="rect" coords="29, 153, 113, 187" href="' . sprintf($urlpattern, 'oakland') . '" alt="Oakland"/>' .
			'<area shape="rect" coords="41, 72, 104, 103" href="' . sprintf($urlpattern, 'lyons') . '" alt="Lyons"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'BurtCounty';
	}	
	
	function imageMapImage() {
		return 'burt.gif';
	}
	
}