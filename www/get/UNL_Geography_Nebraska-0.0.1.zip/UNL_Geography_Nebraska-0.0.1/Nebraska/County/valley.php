<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_valley extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_valley()
	{
		$this->_cities = array(
			'arcadia' => 'Arcadia',
			'elyria' => 'Elyria',
			'northloup' => 'North Loup',
			'ord' => 'Ord',
		);
	}

	function countyName()
	{
		return 'Valley';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="ValleyCounty" id="ValleyCounty">' .
			'<area shape="rect" coords="57, 227, 140, 260" href="' . sprintf($urlpattern, 'arcadia') . '" alt="Arcadia" />' .
			'<area shape="rect" coords="251, 170, 348, 206" href="' . sprintf($urlpattern, 'northloup') . '" alt="North Loup" />' .
			'<area shape="rect" coords="187, 99, 243, 135" href="' . sprintf($urlpattern, 'ord') . '" alt="Ord" />' .
			'<area shape="rect" coords="127, 41, 196, 76" href="' . sprintf($urlpattern, 'elyria') . '" alt="Elyria" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'ValleyCounty';
	}	
	
	function imageMapImage() {
		return 'valley.gif';
	}
	
}