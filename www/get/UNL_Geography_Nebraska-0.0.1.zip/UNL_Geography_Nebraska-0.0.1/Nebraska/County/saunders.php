<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_saunders extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_saunders()
	{
		$this->_cities = array(
			'ashland' => 'Ashland',
			'cedarbluffs' => 'Cedar Bluffs',
			'ceresco' => 'Ceresco',
			'colon' => 'Colon',
			'ithaca' => 'Ithaca',
			'leshara' => 'Leshara',
			'malmo' => 'Malmo',
			'mead' => 'Mead',
			'memphis' => 'Memphis',
			'morsebluff' => 'Morse Bluff',
			'prague' => 'Prague',
			'valparaiso' => 'Valparaiso',
			'wahoo' => 'Wahoo',
			'weston' => 'Weston',
			'yutan' => 'Yutan',
		);
	}

	function countyName()
	{
		return 'Saunders';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="SaundersCounty" id="SaundersCounty">' .
			'<area shape="rect" coords="326, 272, 397, 301" href="' . sprintf($urlpattern, 'ashland') . '" alt="Ashland" />' .
			'<area shape="rect" coords="295, 232, 365, 265" href="' . sprintf($urlpattern, 'memphis') . '" alt="Memphis" />' .
			'<area shape="rect" coords="153, 259, 223, 290" href="' . sprintf($urlpattern, 'ceresco') . '" alt="Ceresco" />' .
			'<area shape="rect" coords="228, 190, 287, 218" href="' . sprintf($urlpattern, 'ithaca') . '" alt="Ithica" />' .
			'<area shape="rect" coords="17, 243, 107, 277" href="' . sprintf($urlpattern, 'valparaiso') . '" alt="Valparaiso" />' .
			'<area shape="rect" coords="90, 165, 152, 197" href="' . sprintf($urlpattern, 'weston') . '" alt="Weston" />' .
			'<area shape="rect" coords="172, 149, 231, 183" href="' . sprintf($urlpattern, 'wahoo') . '" alt="Wahoo" />' .
			'<area shape="rect" coords="268, 142, 318, 172" href="' . sprintf($urlpattern, 'mead') . '" alt="Mead" />' .
			'<area shape="rect" coords="331, 130, 384, 159" href="' . sprintf($urlpattern, 'yutan') . '" alt="Yutan" />' .
			'<area shape="rect" coords="278, 64, 348, 99" href="' . sprintf($urlpattern, 'leshara') . '" alt="Leshara" />' .
			'<area shape="rect" coords="185, 92, 239, 125" href="' . sprintf($urlpattern, 'colon') . '" alt="Colon" />' .
			'<area shape="rect" coords="104, 115, 161, 144" href="' . sprintf($urlpattern, 'malmo') . '" alt="Malmo" />' .
			'<area shape="rect" coords="44, 85, 105, 116" href="' . sprintf($urlpattern, 'prague') . '" alt="Prague" />' .
			'<area shape="rect" coords="161, 35, 255, 67" href="' . sprintf($urlpattern, 'cedarbluffs') . '" alt="Cedar Bluffs" />' .
			'<area shape="rect" coords="50, 6, 149, 39" href="' . sprintf($urlpattern, 'morsebluff') . '" alt="Morse Bluff" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'SaundersCounty';
	}	
	
	function imageMapImage() {
		return 'saunders.gif';
	}
	
}