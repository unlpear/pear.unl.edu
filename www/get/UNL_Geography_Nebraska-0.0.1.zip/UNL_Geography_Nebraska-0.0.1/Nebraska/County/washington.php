<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_washington extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_washington()
	{
		$this->_cities = array(
			'arlington' => 'Arlington',
			'blair' => 'Blair',
			'fortcalhoun' => 'Fort Calhoun',
			'herman' => 'Herman',
			'kennard' => 'Kennard',
			'washington' => 'Washington',
		);
	}

	function countyName()
	{
		return 'Washington';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="WashingtonCounty" id="WashingtonCounty">' .
			'<area shape="rect" coords="255, 172, 373, 202" href="' . sprintf($urlpattern, 'fortcalhoun') . '" alt="Fort Calhoun" />' .
			'<area shape="rect" coords="131, 195, 232, 225" href="' . sprintf($urlpattern, 'washington') . '" alt="Washington" />' .
			'<area shape="rect" coords="54, 156, 139, 186" href="' . sprintf($urlpattern, 'arlington') . '" alt="Arlington" />' .
			'<area shape="rect" coords="148, 143, 226, 174" href="' . sprintf($urlpattern, 'kennard') . '" alt="Kennard" />' .
			'<area shape="rect" coords="212, 83, 264, 119" href="' . sprintf($urlpattern, 'blair') . '" alt="Blair" />' .
			'<area shape="rect" coords="138, 10, 216, 39" href="' . sprintf($urlpattern, 'herman') . '" alt="Herman" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'WashingtonCounty';
	}	
	
	function imageMapImage() {
		return 'washington.gif';
	}
	
}