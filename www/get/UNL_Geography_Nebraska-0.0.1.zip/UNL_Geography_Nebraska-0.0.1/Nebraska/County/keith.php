<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_keith extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_keith()
	{
		$this->_cities = array(
			'brule' => 'Brule',
			'keystone' => 'Keystone',
			'lemoyne' => 'Lemoyne',
			'ogallala' => 'Ogallala',
			'paxton' => 'Paxton',
			'roscoe' => 'Roscoe',
		);
	}

	function countyName()
	{
		return 'Keith';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="KeithCounty" id="KeithCounty">' .
			'<area shape="rect" coords="290, 118, 362, 157" href="' . sprintf($urlpattern, 'paxton') . '" alt="Paxton"/>' .
			'<area shape="rect" coords="208, 112, 292, 143" href="' . sprintf($urlpattern, 'roscoe') . '" alt="Roscoe"/>' .
			'<area shape="rect" coords="112, 115, 198, 152" href="' . sprintf($urlpattern, 'ogallala') . '" alt="Ogallala"/>' .
			'<area shape="rect" coords="48, 132, 108, 164" href="' . sprintf($urlpattern, 'brule') . '" alt="Brule"/>' .
			'<area shape="rect" coords="207, 68, 316, 99" href="' . sprintf($urlpattern, 'keystone') . '" alt="Keystone"/>' .
			'<area shape="rect" coords="100, 44, 201, 75" href="' . sprintf($urlpattern, 'lemoyne') . '" alt="Lemoyne"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'KeithCounty';
	}	
	
	function imageMapImage() {
		return 'keith.gif';
	}
	
}