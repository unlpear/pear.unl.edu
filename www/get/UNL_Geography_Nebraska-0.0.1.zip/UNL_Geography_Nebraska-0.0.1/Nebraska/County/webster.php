<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_webster extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_webster()
	{
		$this->_cities = array(
			'bladen' => 'Bladen',
			'bluehill' => 'Blue Hill',
			'cowles' => 'Cowles',
			'guiderock' => 'Guide Rock',
			'inavale' => 'Inavale',
			'redcloud' => 'Red Cloud',
		);
	}

	function countyName()
	{
		return 'Webster';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="WebsterCounty" id="WebsterCounty">' .
			'<area shape="rect" coords="281, 207, 381, 245" href="' . sprintf($urlpattern, 'guiderock') . '" alt="Guide Rock" />' .
			'<area shape="rect" coords="126, 198, 234, 234" href="' . sprintf($urlpattern, 'redcloud') . '" alt="Red Cloud" />' .
			'<area shape="rect" coords="28, 195, 113, 230" href="' . sprintf($urlpattern, 'inavale') . '" alt="Inavale" />' .
			'<area shape="rect" coords="198, 129, 275, 165" href="' . sprintf($urlpattern, 'cowles') . '" alt="Cowles" />' .
			'<area shape="rect" coords="188, 12, 278, 48" href="' . sprintf($urlpattern, 'bluehill') . '" alt="Blue Hill" />' .
			'<area shape="rect" coords="73, 18, 148, 53" href="' . sprintf($urlpattern, 'bladen') . '" alt="Bladen" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'WebsterCounty';
	}	
	
	function imageMapImage() {
		return 'webster.gif';
	}
	
}