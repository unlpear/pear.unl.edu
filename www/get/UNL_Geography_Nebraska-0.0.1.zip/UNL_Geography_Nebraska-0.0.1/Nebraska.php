<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */

include_once 'Nebraska/County.php';
include_once 'PEAR.php';

class UNL_Geography_Nebraska {

	var $_counties = array();
	var $_countyOb = array();
	
	function UNL_Geography_Nebraska()
	{
		$this->_counties = 	array(
			'adams' => 'Adams',
			'antelope' => 'Antelope',
			'arthur' => 'Arthur',
			'banner' => 'Banner',
			'blaine' => 'Blaine',
			'boone' => 'Boone',
			'boxbutte' => 'Box Butte',
			'boyd' => 'Boyd',
			'brown' => 'Brown',
			'buffalo' => 'Buffalo',
			'burt' => 'Burt',
			'butler' => 'Butler',
			'cass' => 'Cass',
			'cedar' => 'Cedar',
			'chase' => 'Chase',
			'cherry' => 'Cherry',
			'cheyenne' => 'Cheyenne',
			'clay' => 'Clay',
			'colfax' => 'Colfax',
			'cuming' => 'Cuming',
			'custer' => 'Custer',
			'dakota' => 'Dakota',
			'dawes' => 'Dawes',
			'dawson' => 'Dawson',
			'deuel' => 'Deuel',
			'dixon' => 'Dixon',
			'dodge' => 'Dodge',
			'douglas' => 'Douglas',
			'dundy' => 'Dundy',
			'fillmore' => 'Fillmore',
			'franklin' => 'Franklin',
			'frontier' => 'Frontier',
			'furnas' => 'Furnas',
			'gage' => 'Gage',
			'garden' => 'Garden',
			'garfield' => 'Garfield',
			'gosper' => 'Gosper',
			'grant' => 'Grant',
			'greeley' => 'Greeley',
			'hall' => 'Hall',
			'hamilton' => 'Hamilton',
			'harlan' => 'Harlan',
			'hayes' => 'Hayes',
			'hitchcock' => 'Hithccock',
			'holt' => 'Holt',
			'hooker' => 'Hooker',
			'howard' => 'Howard',
			'jefferson' => 'Jefferson',
			'johnson' => 'Johnson',
			'kearney' => 'Kearney',
			'keith' => 'Keith',
			'keyapaha' => 'Keya Paha',
			'kimball' => 'Kimball',
			'knox' => 'Knox',
			'lancaster' => 'Lancaster',
			'lincoln' => 'Lincoln',
			'logan' => 'Logan',
			'loup' => 'Loup',
			'madison' => 'Madison',
			'mcpherson' => 'McPherson',
			'merrick' => 'Merrick',
			'morrill' => 'Morrill',
			'nance' => 'Nance',
			'nemaha' => 'Nemaha',
			'nuckolls' => 'Nuckolls',
			'otoe' => 'Otoe',
			'pawnee' => 'Pawnee',
			'perkins' => 'Perkins',
			'phelps' => 'Phelps',
			'pierce' => 'Pierce',
			'platte' => 'Platte',
			'polk' => 'Polk',
			'redwillow' => 'Red Willow',
			'richardson' => 'Richardson',
			'rock' => 'Rock',
			'saline' => 'Saline',
			'sarpy' => 'Sarpy',
			'saunders' => 'Saunders',
			'scottsbluff' => 'Scottsbluff',
			'seward' => 'Seward',
			'sheridan' => 'Sheridan',
			'sherman' => 'Sherman',
			'sioux' => 'Sioux',
			'stanton' => 'Stanton',
			'thayer' => 'Thayer',
			'thomas' => 'Thomas',
			'thurston' => 'Thurston',
			'valley' => 'Valley',
			'washington' => 'Washington',
			'wayne' => 'Wayne',
			'webster' => 'Webster',
			'wheeler' => 'Wheeler',
			'york' => 'York',
		);

	}
	
	function getCounties()
	{
		return $this->_counties;
	}
	
	function _loadCounties()
	{
		if (!count($this->_countyOb)) {
			foreach ($this->_counties as $key => $val) {
				$county = &Nebraska_County::singleton($key);
				if (!is_a($county, 'Pear_Error')) {
					$this->_countyOb[$key] = &$county;
				}
			}
		}
	}
	
	function getCities()
	{
		static $cities = array();
		
		if (!count($cities)) {
			$this->_loadCounties();
			$cities = array();
			foreach ($this->_countyOb as $county) {
				$cities = array_merge($cities, $county->getCities());
			}
			asort($cities);
		}
		
		return $cities;
	}
	
	function inCounty($city)
	{
		static $in_county = array();
		
		if (empty($in_county[$city])) {
			$this->_loadCounties();
			foreach ($this->_counties as $key => $val) {
				$cities = $this->_countyOb[$key]->getCities();
				if (in_array($city, array_keys($cities))) {
					$in_county[$city] = $key;
				}
			}
		}
		
		return $in_county[$city];
	}
	
	function imageMap($urlpattern = null)
	{
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="NebraskaCounties" id="NebraskaCounties">'.
			'<area shape="poly" coords="607, 283, 643, 281, 660, 306, 609, 309" href="' . sprintf($urlpattern, 'richardson') . '" alt="Richardson"/>' .
			'<area shape="poly" coords="573, 287, 607, 284, 608, 308, 575, 311" href="' . sprintf($urlpattern, 'pawnee') . '" alt="Pawnee"/>' .
			'<area shape="poly" coords="602, 259, 629, 258, 641, 281, 604, 283" href="' . sprintf($urlpattern, 'nemaha') . '" alt="Nemaha"/>' .
			'<area shape="poly" coords="572, 259, 600, 258, 603, 282, 573, 286" href="' . sprintf($urlpattern, 'johnson') . '" alt="Johnson"/>' .
			'<area shape="poly" coords="536, 260, 572, 260, 573, 310, 537, 311" href="' . sprintf($urlpattern, 'gage') . '" alt="Gage"/>' .
			'<area shape="poly" coords="504, 280, 537, 276, 537, 312, 506, 313" href="' . sprintf($urlpattern, 'jefferson') . '" alt="Jefferson"/>' .
			'<area shape="poly" coords="470, 278, 504, 278, 505, 313, 471, 313" href="' . sprintf($urlpattern, 'thayer') . '" alt="Thayer"/>' .
			'<area shape="poly" coords="435, 280, 469, 280, 470, 314, 437, 314" href="' . sprintf($urlpattern, 'nuckolls') . '" alt="Nuckolls"/>' .
			'<area shape="poly" coords="503, 244, 536, 243, 536, 277, 503, 279" href="' . sprintf($urlpattern, 'saline') . '" alt="Saline"/>' .
			'<area shape="poly" coords="467, 247, 502, 246, 503, 279, 469, 279" href="' . sprintf($urlpattern, 'fillmore') . '" alt="Fillmore"/>' .
			'<area shape="poly" coords="436, 247, 467, 246, 469, 278, 437, 278" href="' . sprintf($urlpattern, 'clay') . '" alt="Clay"/>' .
			'<area shape="poly" coords="570, 236, 613, 230, 625, 254, 572, 259" href="' . sprintf($urlpattern, 'otoe') . '" alt="Otoe"/>' .
			'<area shape="poly" coords="570, 210, 586, 211, 590, 212, 612, 207, 616, 230, 571, 233" href="' . sprintf($urlpattern, 'cass') . '" alt="Cass"/>' .
			'<area shape="poly" coords="533, 209, 569, 207, 570, 259, 537, 259" href="' . sprintf($urlpattern, 'lancaster') . '" alt="Lancaster"/>' .
			'<area shape="poly" coords="504, 210, 534, 209, 536, 244, 503, 244" href="' . sprintf($urlpattern, 'seward') . '" alt="Seward"/>' .
			'<area shape="poly" coords="468, 212, 503, 211, 502, 245, 468, 246" href="' . sprintf($urlpattern, 'york') . '" alt="York"/>' .
			'<area shape="poly" coords="612, 192, 580, 194, 579, 205, 588, 213, 597, 208, 613, 206" href="' . sprintf($urlpattern, 'sarpy') . '" alt="Sarpy"/>' .
			'<area shape="poly" coords="606, 173, 567, 174, 577, 192, 611, 192" href="' . sprintf($urlpattern, 'douglas') . '" alt="Douglass"/>' .
			'<area shape="poly" coords="536, 172, 558, 169, 571, 179, 578, 194, 578, 208, 537, 208" href="' . sprintf($urlpattern, 'saunders') . '" alt="Saunders"/>' .
			'<area shape="poly" coords="534, 171, 502, 178, 502, 209, 535, 209" href="' . sprintf($urlpattern, 'butler') . '" alt="Bulter"/>' .
			'<area shape="poly" coords="468, 200, 468, 211, 501, 211, 502, 178" href="' . sprintf($urlpattern, 'polk') . '" alt="Polk"/>' .
			'<area shape="poly" coords="434, 232, 434, 246, 467, 244, 468, 202" href="' . sprintf($urlpattern, 'hamilton') . '" alt="Hamilton"/>' .
			'<area shape="poly" coords="433, 193, 433, 231, 484, 183, 483, 179, 475, 179, 475, 182, 475, 183" href="' . sprintf($urlpattern, 'merrick') . '" alt="Merrick"/>' .
			'<area shape="poly" coords="432, 172, 434, 191, 474, 183, 475, 167, 455, 166" href="' . sprintf($urlpattern, 'nance') . '" alt="Nance"/>' .
			'<area shape="poly" coords="567, 145, 591, 146, 596, 158, 605, 170, 575, 170" href="' . sprintf($urlpattern, 'washington') . '" alt="Washington"/>' .
			'<area shape="poly" coords="533, 141, 565, 141, 568, 159, 577, 170, 566, 174, 558, 168, 535, 169" href="' . sprintf($urlpattern, 'dodge') . '" alt="Dodge"/>' .
			'<area shape="poly" coords="509, 143, 533, 142, 535, 169, 509, 177" href="' . sprintf($urlpattern, 'colfax') . '" alt="Colfax"/>' .
			'<area shape="poly" coords="466, 144, 509, 144, 509, 177, 494, 176, 485, 184, 483, 177, 477, 177, 466, 163" href="' . sprintf($urlpattern, 'platte') . '" alt="Platte"/>' .
			'<area shape="poly" coords="560, 114, 582, 112, 590, 117, 595, 133, 592, 142, 564, 143" href="' . sprintf($urlpattern, 'burt') . '" alt="Burt"/>' .
			'<area shape="poly" coords="526, 108, 558, 107, 559, 139, 527, 141" href="' . sprintf($urlpattern, 'cuming') . '" alt="Cuming"/>' .
			'<area shape="poly" coords="498, 107, 524, 108, 526, 141, 501, 142" href="' . sprintf($urlpattern, 'stanton') . '" alt="Stanton"/>' .
			'<area shape="poly" coords="539, 91, 545, 88, 571, 85, 578, 107, 576, 110, 558, 112, 558, 107, 535, 104" href="' . sprintf($urlpattern, 'thurston') . '" alt="Thurston"/>' .
			'<area shape="poly" coords="546, 64, 568, 67, 573, 86, 545, 86" href="' . sprintf($urlpattern, 'dakota') . '" alt="Dakota"/>' .
			'<area shape="poly" coords="524, 44, 543, 48, 549, 61, 545, 61, 544, 89, 522, 88" href="' . sprintf($urlpattern, 'dixon') . '" alt="Dixon"/>' .
			'<area shape="poly" coords="498, 84, 522, 82, 522, 89, 537, 90, 538, 103, 528, 106, 498, 105" href="' . sprintf($urlpattern, 'wayne') . '" alt="Wayne"/>' .
			'<area shape="poly" coords="431, 128, 464, 126, 464, 164, 433, 169" href="' . sprintf($urlpattern, 'boone') . '" alt="Boone"/>' .
			'<area shape="poly" coords="487, 33, 506, 32, 510, 39, 522, 40, 523, 80, 498, 81, 496, 73, 489, 73" href="' . sprintf($urlpattern, 'cedar') . '" alt="Cedar"/>' .
			'<area shape="poly" coords="463, 108, 498, 106, 500, 140, 466, 142" href="' . sprintf($urlpattern, 'madison') . '" alt="Madison"/>' .
			'<area shape="poly" coords="461, 75, 497, 74, 497, 107, 464, 107" href="' . sprintf($urlpattern, 'pierce') . '" alt="Pierce"/>' .
			'<area shape="poly" coords="429, 75, 462, 74, 463, 125, 430, 127" href="' . sprintf($urlpattern, 'antelope') . '" alt="Antelope"/>' .
			'<area shape="poly" coords="427, 32, 450, 40, 456, 37, 460, 33, 486, 33, 489, 73, 429, 74" href="' . sprintf($urlpattern, 'knox') . '" alt="Knox"/>' .
			'<area shape="poly" coords="400, 283, 436, 280, 437, 315, 400, 316" href="' . sprintf($urlpattern, 'webster') . '" alt="Webster"/>' .
			'<area shape="poly" coords="366, 282, 401, 281, 400, 315, 367, 317" href="' . sprintf($urlpattern, 'franklin') . '" alt="Franklin"/>' .
			'<area shape="poly" coords="331, 284, 367, 282, 367, 315, 331, 315" href="' . sprintf($urlpattern, 'harlan') . '" alt="Harlan"/>' .
			'<area shape="poly" coords="402, 249, 435, 247, 435, 279, 402, 280" href="' . sprintf($urlpattern, 'adams') . '" alt="Adams"/>' .
			'<area shape="poly" coords="366, 251, 390, 251, 401, 247, 401, 279, 367, 281" href="' . sprintf($urlpattern, 'kearney') . '" alt="Kearney"/>' .
			'<area shape="poly" coords="334, 249, 367, 251, 366, 280, 331, 280" href="' . sprintf($urlpattern, 'phelps') . '" alt="Phelps"/>' .
			'<area shape="poly" coords="400, 212, 432, 213, 433, 246, 401, 247" href="' . sprintf($urlpattern, 'hall') . '" alt="Hall"/>' .
			'<area shape="poly" coords="347, 213, 400, 213, 401, 247, 392, 251, 349, 249" href="' . sprintf($urlpattern, 'buffalo') . '" alt="Buffalo"/>' .
			'<area shape="poly" coords="400, 178, 433, 178, 433, 212, 398, 211" href="' . sprintf($urlpattern, 'howard') . '" alt="Howard"/>' .
			'<area shape="poly" coords="363, 179, 398, 176, 397, 212, 363, 212" href="' . sprintf($urlpattern, 'sherman') . '" alt="Sherman"/>' .
			'<area shape="poly" coords="398, 143, 431, 144, 433, 177, 398, 177" href="' . sprintf($urlpattern, 'greeley') . '" alt="Greely"/>' .
			'<area shape="poly" coords="363, 145, 397, 146, 398, 177, 363, 179" href="' . sprintf($urlpattern, 'valley') . '" alt="Valley"/>' .
			'<area shape="poly" coords="395, 111, 430, 111, 431, 143, 397, 143" href="' . sprintf($urlpattern, 'wheeler') . '" alt="Wheeler"/>' .
			'<area shape="poly" coords="362, 111, 395, 111, 397, 144, 363, 144" href="' . sprintf($urlpattern, 'garfield') . '" alt="Garfield"/>' .
			'<area shape="poly" coords="290, 284, 332, 282, 332, 316, 289, 316" href="' . sprintf($urlpattern, 'furnas') . '" alt="Furnas"/>' .
			'<area shape="poly" coords="304, 247, 332, 248, 331, 282, 297, 282, 297, 274, 304, 273" href="' . sprintf($urlpattern, 'gosper') . '" alt="Gosper"/>' .
			'<area shape="poly" coords="287, 215, 347, 213, 349, 249, 329, 246, 288, 245" href="' . sprintf($urlpattern, 'dawson') . '" alt="Dawson"/>' .
			'<area shape="poly" coords="285, 146, 362, 144, 363, 212, 287, 214" href="' . sprintf($urlpattern, 'custer') . '" alt="Custer"/>' .
			'<area shape="poly" coords="330, 110, 362, 111, 361, 145, 329, 145" href="' . sprintf($urlpattern, 'loup') . '" alt="Loup"/>' .
			'<area shape="poly" coords="285, 111, 328, 111, 328, 144, 286, 145" href="' . sprintf($urlpattern, 'blaine') . '" alt="Blaine"/>' .
			'<area shape="poly" coords="249, 282, 289, 283, 288, 314, 247, 315" href="' . sprintf($urlpattern, 'redwillow') . '" alt="Redwillow"/>' .
			'<area shape="poly" coords="248, 247, 305, 247, 305, 272, 296, 272, 296, 280, 246, 281" href="' . sprintf($urlpattern, 'frontier') . '" alt="Frontier"/>' .
			'<area shape="poly" coords="205, 283, 248, 283, 247, 317, 205, 315" href="' . sprintf($urlpattern, 'hitchcock') . '" alt="Hitchcock"/>' .
			'<area shape="poly" coords="151, 283, 204, 282, 205, 315, 150, 313" href="' . sprintf($urlpattern, 'dundy') . '" alt="Dundy"/>' .
			'<area shape="poly" coords="206, 249, 247, 247, 246, 282, 204, 282" href="' . sprintf($urlpattern, 'hayes') . '" alt="Hayes"/>' .
			'<area shape="poly" coords="153, 248, 204, 248, 204, 281, 152, 281" href="' . sprintf($urlpattern, 'chase') . '" alt="Chase"/>' .
			'<area shape="poly" coords="152, 219, 211, 217, 212, 246, 152, 246" href="' . sprintf($urlpattern, 'perkins') . '" alt="Perkins"/>' .
			'<area shape="poly" coords="211, 180, 287, 180, 287, 245, 212, 246" href="' . sprintf($urlpattern, 'lincoln') . '" alt="Lincoln"/>' .
			'<area shape="poly" coords="154, 178, 210, 179, 211, 216, 152, 216" href="' . sprintf($urlpattern, 'keith') . '" alt="Keith"/>' .
			'<area shape="poly" coords="110, 194, 151, 193, 152, 217, 110, 214" href="' . sprintf($urlpattern, 'deuel') . '" alt="Deuel"/>' .
			'<area shape="poly" coords="254, 147, 285, 145, 285, 178, 254, 179" href="' . sprintf($urlpattern, 'logan') . '" alt="Logan"/>' .
			'<area shape="poly" coords="201, 144, 253, 146, 253, 177, 202, 178" href="' . sprintf($urlpattern, 'mcpherson') . '" alt="McPherson"/>' .
			'<area shape="poly" coords="159, 145, 201, 143, 201, 176, 157, 177" href="' . sprintf($urlpattern, 'arthur') . '" alt="Arthur"/>' .
			'<area shape="poly" coords="243, 113, 284, 111, 285, 143, 245, 144" href="' . sprintf($urlpattern, 'thomas') . '" alt="Thomas"/>' .
			'<area shape="poly" coords="202, 111, 244, 111, 243, 144, 201, 143" href="' . sprintf($urlpattern, 'hooker') . '" alt="Hooker"/>' .
			'<area shape="poly" coords="158, 110, 200, 112, 200, 144, 159, 145, 155, 140, 153, 118, 154, 119" href="' . sprintf($urlpattern, 'grant') . '" alt="Grant"/>' .
			'<area shape="poly" coords="106, 115, 153, 118, 154, 142, 158, 143, 157, 177, 154, 176, 152, 194, 110, 192" href="' . sprintf($urlpattern, 'garden') . '" alt="Garden"/>' .
			'<area shape="poly" coords="56, 171, 109, 171, 109, 216, 52, 212" href="' . sprintf($urlpattern, 'cheyenne') . '" alt="Cheyenne"/>' .
			'<area shape="poly" coords="5, 173, 54, 176, 53, 215, 3, 210" href="' . sprintf($urlpattern, 'kimball') . '" alt="Kimball"/>' .
			'<area shape="poly" coords="6, 144, 54, 146, 55, 174, 5, 172" href="' . sprintf($urlpattern, 'banner') . '" alt="Banner"/>' .
			'<area shape="poly" coords="57, 116, 106, 115, 109, 171, 56, 171" href="' . sprintf($urlpattern, 'morrill') . '" alt="Morrill"/>' .
			'<area shape="poly" coords="8, 113, 58, 114, 55, 145, 7, 142" href="' . sprintf($urlpattern, 'scottsbluff') . '" alt="Scottsbluff"/>' .
			'<area shape="poly" coords="360, 41, 382, 30, 404, 38, 427, 43, 429, 109, 361, 110" href="' . sprintf($urlpattern, 'holt') . '" alt="Holt"/>' .
			'<area shape="poly" coords="358, 23, 414, 21, 427, 32, 429, 42, 412, 41, 398, 38, 386, 36, 381, 31, 362, 38" href="' . sprintf($urlpattern, 'boyd') . '" alt="Boyd"/>' .
			'<area shape="poly" coords="329, 51, 359, 40, 360, 111, 330, 110" href="' . sprintf($urlpattern, 'rock') . '" alt="Rock"/>' .
			'<area shape="poly" coords="292, 37, 328, 49, 330, 110, 293, 110" href="' . sprintf($urlpattern, 'brown') . '" alt="Brown"/>' .
			'<area shape="poly" coords="290, 22, 359, 21, 360, 39, 337, 47, 325, 47, 291, 37" href="' . sprintf($urlpattern, 'keyapaha') . '" alt="Keyapaha"/>' .
			'<area shape="poly" coords="155, 19, 290, 21, 292, 111, 161, 109" href="' . sprintf($urlpattern, 'cherry') . '" alt="Cherry"/>' .
			'<area shape="poly" coords="101, 18, 154, 18, 157, 116, 106, 115" href="' . sprintf($urlpattern, 'sheridan') . '" alt="Sheridan"/>' .
			'<area shape="poly" coords="56, 71, 103, 72, 105, 114, 55, 113" href="' . sprintf($urlpattern, 'boxbutte') . '" alt="Boxbutte"/>' .
			'<area shape="poly" coords="51, 15, 102, 18, 102, 72, 53, 69" href="' . sprintf($urlpattern, 'dawes') . '" alt="Dawes"/>' .
			'<area shape="poly" coords="13, 15, 49, 15, 54, 113, 9, 111" href="' . sprintf($urlpattern, 'sioux') . '" alt="Souix"/>' .
			'</map>';

		return $map;
	}
	
	function imageMapImage()
	{
		return 'countymap.gif';
	}
	
	function imageMapName()
	{
		return 'NebraskaCounties';
	}
}