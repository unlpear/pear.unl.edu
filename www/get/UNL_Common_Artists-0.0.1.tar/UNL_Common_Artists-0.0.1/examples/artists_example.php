<?php
ini_set('display_errors',true);
require_once 'UNL/Common/Artists.php';
DB_DataObject::debugLevel(3);
$artists = new UNL_Common_Artists();
if ($artists->find()) {
	while ($artists->fetch()) {
		echo "{$artists->last_name}, {$artists->first_name} ".date('Y',strtotime($artists->dob))."<br />";
	}
}

?>