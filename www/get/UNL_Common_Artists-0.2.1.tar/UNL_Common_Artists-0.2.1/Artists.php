<?php
/**
 * This package is an a DB_DataObject which connects to the database and allows searching for artist info.
 * 
 * @package UNL_Common_Arists
 * @author bbieber
 */
require_once 'DB/DataObject.php';
require_once 'UNL/Common/Artists/config.inc.php';

class UNL_Common_Artists extends DB_DataObject 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__table = 'artists';                         // table name
    public $id;                              // int(11)  not_null primary_key auto_increment
    public $first_name;                      // string(50)  not_null
    public $middle_name;                     // string(100)  
    public $last_name;                       // string(50)  not_null
    public $dob;                             // date(10)  binary
    public $dod;                             // date(10)  binary
    public $info;                            // blob(16777215)  blob

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('UNL_Common_Artists',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
