<?php
ini_set('display_errors',true);


require_once 'UNL/TidyTemplate.php';

$site = '/Library/WebServer/Documents/policetest/index.shtml';

$t = new UNL_TidyTemplate();
$t->tidyLocalFiles(array($site));
print_r($t);

?>