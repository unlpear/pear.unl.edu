<?php
/**
 * This package has information for buildings on campus. 
 * Currently the information is structured in HTML snippets.
 * 
 * @package UNL_Common_Building_Info
 * @author Brett Bieber
 */

require_once 'UNL/Common/Building.php'; 

class UNL_Common_Building_Info
{
	var $bldgs;
	
	function __construct()
	{
		$this->bldgs = new UNL_Common_Building();
	}
	
	function UNL_Geography_SpatialData_Campus()
	{
		return parent::__construct();
	}
	
	/**
	 * Returns a HTML snippet of information about a building on campus.
	 * 
	 * @param string $code Building Code for the building you want coordinates of.
	 * @return string Snippet of text description. 
	 */
	function getHtml($code)
	{
		if (isset($this->bldgs->codes[$code])) {
			// Code is valid, find the building information.
			$link = mysql_connect('crusader.unl.edu', 'unl_common');
			if (!$link) {
				return false;
			} else {
				mysql_select_db('unl_common');
				$query = 'SELECT description FROM building_info WHERE code = \''.$code.'\';';
				$result = mysql_query($query) or die('Query failed: ' . mysql_error());
				if (mysql_num_rows($result) == 1) {
					while ($data = mysql_fetch_assoc($result)) {
						return $data['description'];
					}
				} else {
					return false;
				}
				mysql_close($link);
			}
		} else {
			return false;
		}
	}
}
?>