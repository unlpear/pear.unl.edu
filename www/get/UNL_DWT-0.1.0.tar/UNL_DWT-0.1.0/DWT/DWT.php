<?php
/**
 * This package is intended to create PHP Class files (Objects) from Dreamweaver template (.dwt) files.
 * It allows designers to create a standalone Dreamweaver template for the website design, and developers
 * to use that design in php pages without interference.
 *
 * Similar to the way DB_DataObject works, the DWT package uses a Generator to scan a .dwt file for editable
 * regions and creates an appropriately named class for that .dwt file with member variables for each region.
 *
 * Once the objects have been generated, you can render a html page from the template.
 * 
 * $page = new UNL_DWT::factory('Template_style1');
 * $page->pagetitle = "Contact Information";
 * $page->maincontent = "Contact us by telephone at 111-222-3333.";
 * echo $page->toHtml();
 *
 * Parts of this package are modeled on (borrowed from) the PEAR package DB_DataObject.
 *
 * @author Brett Bieber
 * @created 01/18/2006
 */
 ini_set('include_path',ini_get('include_path').':/Library/WebServer/Documents/pear.unl.edu/:/Library/WebServer/pear.unl.edu/:/Library/WebServer/pear.unl.edu/UNL_DWT/DWT/');
/**
 * Obtain the PEAR class so it can be extended from
 */
 require_once 'PEAR.php';

/**
 * The code returned by many methods upon success
 */
 define('UNL_DWT_OK', 1);

/**
 * Unkown error
 */
 define('UNL_DWT_ERROR', -1);

/**
 * An identifier in the query refers to a non-existant object
 */
 define('UNL_DWT_ERROR_NOT_FOUND', -4);

class UNL_DWT
{
	var $__template;
	
	function UNL_DWT()
	{
		$this->__constructor();
	}
	
	function __constructor()
	{
		
	}
	
	function toHtml()
	{
		$options = &PEAR::getStaticProperty('UNL_DWT','options');
		if (!isset($this->__template)) {
			return "";
		}
		/*
		More Options for this method:
			Extend this to automatically generate the .tpl files and cache.
			Check for a cached copy of the template file.
			Connect to a template server and get the latest template copy.
			
			Ex: $p = file_get_contents("http://pear.unl.edu/UNL/Templates/server.php?template=".$this->__template);
		*/
		$p = file_get_contents($options['tpl_location'].$this->__template);
		$regions = get_object_vars($this);
		foreach ($regions as $region=>$value) {
			/* Replace the region with the replacement text */
			if (strpos($p,"<!--"." TemplateBeginEditable name=\"{$region}\" -->")) {
				$p = str_replace(between("<!--"." TemplateBeginEditable name=\"{$region}\" -->","<!--"." TemplateEndEditable -->",$p),$value,$p);
			} elseif(strpos($p,"<!--"." InstanceBeginEditable name=\"{$region}\" -->")) {
				$p = str_replace(between("<!--"." InstanceBeginEditable name=\"{$region}\" -->","<!--"." InstanceEndEditable -->",$p),$value,$p);
			}	
		}
		return $p;
	}
	
	/**
	* Create a new UNL_DWT object for the specified layout type
	*
	* @param string $type     the template type (eg "fixed")
	* @param array  $options  an associative array of option names and values
	*
	* @return object  a new UNL_DWT.  A UNL_DWT_Error object on failure.
	*
	* @see UNL_DWT_common::setOption()
	*/
	function &factory($type, $coptions = false) {
		$options = &PEAR::getStaticProperty('UNL_DWT','options');
		
		include_once $options['class_location']."{$type}.php";
		
		if (!is_array($coptions)) {
			$coptions = array();
		}
		
		$classname = $options['class_prefix'].$type;
		
		if (!class_exists($classname)) {
			$tmp = PEAR::raiseError(null, UNL_DWT_ERROR_NOT_FOUND, null, null,
			"Unable to include the {$options['class_location']}{$type}.php file.",
			'UNL_DWT_Error', true);
			return $tmp;
		}
		
		@$obj =& new $classname;
		
		foreach ($coptions as $option => $value) {
			$test = $obj->setOption($option, $value);
			if (UNL_DWT::isError($test)) {
				return $test;
			}
		}
		
		return $obj;
	}
	
	/**
	* Determines if a variable is a UNL_DWT_Error object
	*
	* @param mixed $value  the variable to check
	*
	* @return bool  whether $value is UNL_DWT_Error object
	*/
	function isError($value)
	{
		return is_a($value, 'UNL_DWT_Error');
	}
	
	/**
	 *
	 *
	 *
	 */
	function debug($message)
	{
		echo $message;
	}
	
    // {{{ errorMessage()

    /**
     * Return a textual error message for a DB error code
     *
     * @param integer $value  the DB error code
     *
     * @return string  the error message or false if the error code was
     *                  not recognized
     */
    function errorMessage($value)
    {
        static $errorMessages;
        if (!isset($errorMessages)) {
            $errorMessages = array(
                UNL_DWT_ERROR                    => 'unknown error',
                UNL_DWT_ERROR_NOT_FOUND          => 'not found',
                UNL_DWT_OK                       => 'no error',
            );
        }

        if (UNL_DWT::isError($value)) {
            $value = $value->getCode();
        }

        return isset($errorMessages[$value]) ? $errorMessages[$value]
                     : $errorMessages[UNL_DWT_ERROR];
    }
	// }}}
}

/**
 * DB_Error implements a class for reporting portable database error
 * messages
 *
 * @category   Database
 * @package    DB
 * @author     Stig Bakken <ssb@php.net>
 * @copyright  1997-2005 The PHP Group
 * @license    http://www.php.net/license/3_0.txt  PHP License 3.0
 * @version    Release: @package_version@
 * @link       http://pear.php.net/package/DB
 */
 if (!class_exists('UNL_DWT_Error')) {
	 class UNL_DWT_Error extends PEAR_Error
	 {
		// {{{ constructor
	
		/**
		* DB_Error constructor
		*
		* @param mixed $code       DB error code, or string with error message
		* @param int   $mode       what "error mode" to operate in
		* @param int   $level      what error level to use for $mode &
		*                           PEAR_ERROR_TRIGGER
		* @param mixed $debuginfo  additional debug info, such as the last query
		*
		* @see PEAR_Error
		*/
		function UNL_DWT_Error($code = UNL_DWT_ERROR, $mode = PEAR_ERROR_RETURN,
						$level = E_USER_NOTICE, $debuginfo = null)     {
			if (is_int($code)) {
				$this->PEAR_Error('UNL DWT Error: ' . UNL_DWT::errorMessage($code), $code,
				$mode, $level, $debuginfo);
			} else {
				$this->PEAR_Error("UNL DWT Error: $code", UNL_DWT_ERROR,
				$mode, $level, $debuginfo);
			}
		}
		// }}}
	 }
 }
 if (!function_exists("between")) {
function between($start,$end,$p) {
	if (!empty($start) && strpos($p,$start)!=false) {
		$p = substr($p,strpos($p,$start)+strlen($start));
	}
	if (strpos($p,$end)!=false) {
		$p = substr($p,0,strpos($p,$end));
	}
	return $p;
}
}