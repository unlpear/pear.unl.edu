<?php
require_once 'CustomClass.php';

$page = new CustomClass();

echo $page;

?>
<pre>
<?php
$foobar = array('DOCUMENT_ROOT','SCRIPT_NAME', 'SCRIPT_FILENAME','PHP_SELF','REQUEST_URI');

foreach ($foobar as $v) {
   echo "$v" . $_SERVER[$v] . "\n";
}
?>
</pre>