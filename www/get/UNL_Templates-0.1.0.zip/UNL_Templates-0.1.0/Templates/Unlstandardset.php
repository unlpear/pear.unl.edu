<?php
/**
 * Template Definition for unlstandardset.dwt
 */
require_once 'UNL/Templates.php';

class UNL_Templates_Unlstandardset extends UNL_Templates 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__template = 'Unlstandardset.tpl';              // template name
    public $doctitle = "<title>UNL | Standard Template Set</title>";                       // string()  
    public $head = "<link rel=\"stylesheet\" href=\"/unlpub/templatedependents/templatecss/layouts/document.css\" type=\"text/css\" media=\"print\" /> <link rel=\"alternate stylesheet\" href=\"/unlpub/templatedependents/templatecss/layouts/splash.css\" type=\"text/css\" title=\"Splash\" /> <link rel=\"alternate stylesheet\" href=\"/unlpub/templatedependents/templatecss/layouts/liquidnoweather.css\" type=\"text/css\" title=\"Liquid No-Weather\" /> <link rel=\"alternate stylesheet\" href=\"/unlpub/templatedependents/templatecss/layouts/liquidnosidebars.css\" type=\"text/css\" title=\"Liquid No-Sidebars\" /> <link rel=\"alternate stylesheet\" href=\"/unlpub/templatedependents/templatecss/layouts/fixed.css\" type=\"text/css\" title=\"Fixed\" /> <link rel=\"alternate stylesheet\" href=\"/unlpub/templatedependents/templatecss/layouts/fixedwsidebars.css\" type=\"text/css\" title=\"Fixed With Sidebars\" /> <link rel=\"alternate stylesheet\" href=\"/unlpub/templatedependents/templatecss/layouts/fixednosidebar.css\" type=\"text/css\" title=\"Fixed No-Sidebar\" /> <link rel=\"alternate stylesheet\" href=\"/unlpub/templatedependents/templatecss/layouts/popup.css\" type=\"text/css\" title=\"Popup\" /> <link rel=\"alternate stylesheet\" href=\"/unlpub/templatedependents/templatecss/layouts/document.css\" type=\"text/css\" title=\"Print (Document)\" /> <script type=\"text/javascript\"> var navl2Links = 0; //Default navline2 links to display (zero based counting) </script>";                           // string()  
    public $leftRandomPromo = "<div id=\"leftRandomPromo\"> <a href=\"#\" id=\"leftRandomPromoAnchor\"><img id=\"leftRandomPromoImage\" alt=\"\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/transpixel.gif\" height=\"88\" width=\"88\" /></a> <script type=\"text/javascript\" src=\"/cssunltemplates/sharedcode/leftRandomPromo.js\"></script> </div>";                // string()  
    public $leftcollinks = "<!-- WDN: see glossary item \'sidebar links\' --> <!--#include virtual=\"/cssunltemplates/sharedcode/relatedLinks.html\" --> <!--#include virtual=\"/unlpub/templatedependents/templatesharedcode/includes/sidefooter/sidefooter.shtml\" -->";                   // string()  
    public $header = "<div id=\"titlegraphic\"> <!-- WDN: see glossary item \'title graphics\' --> <h1>Page Header</h1></div> <div id=\"breadcrumbs\"> <!-- WDN: see glossary item \'breadcrumbs\' --> <ul> <li class=\"first\"><a href=\"http://www.unl.edu/\">UNL</a></li> <li><a href=\"http://www.unl.edu/\">My Organization</a></li> <li>This Page Title</li> </ul> </div>";                         // string()  
    public $maincontent = "<!--#include virtual=\"/unlpub/templatedependents/templatesharedcode/includes/browsersniffers/noscript.html\" --> <!--THIS IS THE MAIN CONTENT AREA; WDN: see glossary item \'main content area\' --> <div style=\"margin:20px; border:3px solid #CC0000;padding:10px; text-align:center\"> <p style=\"margin:0px;font-weight:bold;\">Delete this box and place your content here.</p> <p>Remember to validate your pages before publishing!<br /> <a href=\"http://validator.w3.org/check/referer\">Click here to check Validation</a></p> <p style=\"margin:1.5em 0;\">Sample layouts are available through the <a href=\"http://www.unl.edu/webdevnet/\">Web Developer Network</a>.</p> </div> <!--THIS IS THE END OF THE MAIN CONTENT AREA.-->";                    // string()  
    public $rightcolcontent = "<div id=\"weather\"> <div class=\"content\"> <!--#include virtual=\"/unlpub/templatedependents/templatesharedcode/includes/weather/weather.html\" --> </div> </div> <div id=\"rightRandomPromo\"> <a href=\"#\" id=\"rightRandomPromoAnchor\"><img id=\"rightRandomPromoImage\" alt=\"\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/transpixel.gif\" width=\"100\" height=\"486\" /></a> <script type=\"text/javascript\" src=\"/cssunltemplates/scripts/rightRandomPromo.js\"></script> </div>";                // string()  
    public $footercontent = "<!--#include virtual=\"/cssunltemplates/sharedcode/footer.html\" -->";                  // string()  
    public $navcontent = "<div id=\"navlinks\" > <!--#include virtual=\"/cssunltemplates/sharedcode/navigation.html\" --> </div> <div id=\"toolbar\"> <!--#include virtual=\"/unlpub/templatedependents/templatesharedcode/includes/toolbar/toolbar.shtml\" --> </div> <script type=\"text/javascript\" src=\"/unlpub/templatedependents/templatesharedcode/scripts/navigation.js\"></script>";                     // string()  

    /* Static get */
    function staticGet($k,$v=NULL) { return UNL_DWT::staticGet('UNL_Templates_Unlstandardset',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
