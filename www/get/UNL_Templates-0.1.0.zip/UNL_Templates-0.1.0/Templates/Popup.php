<?php
/**
 * Template Definition for popup.dwt
 */
require_once 'UNL/Templates.php';

class UNL_Templates_Popup extends UNL_Templates 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__template = 'Popup.tpl';                       // template name
    public $doctitle = "<title>UNL | Popup</title>";                       // string()  
    public $head = "";                           // string()  
    public $titlegraphic = "<h1>Popup Template</h1>";                   // string()  
    public $maincontentarea = "<div style=\"margin:20px; border:3px solid #CC0000;padding:10px; text-align:center\"> <p style=\"margin:0px;font-weight:bold;\">Delete this box and place your content here.</p> <p>Remember to validate your pages before publishing!<br /> <a href=\"http://validator.w3.org/check/referer\">Click here to check Validation</a></p> <p style=\"margin:1.5em 0;\">Sample layouts are available through the <a href=\"http://www.unl.edu/webdevnet/\">Web Developer Network</a>.</p> </div>";                // string()  
    public $footercontent = "<!--#include virtual=\"/cssunltemplates/sharedcode/footer.html\" -->";                  // string()  

    /* Static get */
    function staticGet($k,$v=NULL) { return UNL_DWT::staticGet('UNL_Templates_Popup',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
