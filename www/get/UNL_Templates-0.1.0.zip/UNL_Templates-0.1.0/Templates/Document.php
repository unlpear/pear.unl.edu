<?php
/**
 * Template Definition for document.dwt
 */
require_once 'UNL/Templates.php';

class UNL_Templates_Document extends UNL_Templates 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__template = 'Document.tpl';                    // template name
    public $doctitle = "<title>UNL | Document</title>";                       // string()  
    public $head = "";                           // string()  
    public $titlegraphic = "<h1>Page Header</h1>";                   // string()  
    public $maincontentarea = "<!--THIS IS THE MAIN CONTENT AREA; WDN: see glossary item \'main content area\' --> <div style=\"margin:20px; border:3px solid #CC0000;padding:10px; text-align:center\"> <p style=\"margin:0px;font-weight:bold;\">Delete this box and place your content here.</p> <p>Remember to validate your pages before publishing!<br /> <a href=\"http://validator.w3.org/check/referer\">Click here to check Validation</a></p> <p style=\"margin:1.5em 0;\">Sample layouts are available through the <a href=\"http://www.unl.edu/webdevnet/\">Web Developer Network</a>.</p> </div> <!--THIS IS THE END OF THE MAIN CONTENT AREA.-->";                // string()  
    public $footercontent = "<!--#include virtual=\"/cssunltemplates/sharedcode/footer.html\" -->";                  // string()  

    /* Static get */
    function staticGet($k,$v=NULL) { return UNL_DWT::staticGet('UNL_Templates_Document',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
