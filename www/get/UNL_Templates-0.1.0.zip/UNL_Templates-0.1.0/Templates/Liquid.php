<?php
/**
 * Template Definition for liquid.dwt
 */
require_once 'UNL/Templates.php';

class UNL_Templates_Liquid extends UNL_Templates 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__template = 'Liquid.tpl';                      // template name
    public $doctitle = "<title>UNL | Liquid</title>";                       // string()  
    public $head = "<script type=\"text/javascript\"> var navl2Links = 0; //Default navline2 links to display (zero based counting) </script>";                           // string()  
    public $leftRandomPromo = "<div id=\"leftRandomPromo\"> <a href=\"#\" id=\"leftRandomPromoAnchor\"><img id=\"leftRandomPromoImage\" alt=\"\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/transpixel.gif\" height=\"88\" width=\"88\" /></a> <script type=\"text/javascript\" src=\"/cssunltemplates/sharedcode/leftRandomPromo.js\"></script> </div>";                // string()  
    public $leftcollinks = "<!-- WDN: see glossary item \'sidebar links\' --> <!--#include virtual=\"/cssunltemplates/sharedcode/relatedLinks.html\" --> <!--#include virtual=\"/unlpub/templatedependents/templatesharedcode/includes/sidefooter/sidefooter.shtml\" -->";                   // string()  
    public $titlegraphic = "<h1>Page Header</h1>";                   // string()  
    public $breadcrumbs = "<ul> <li class=\"first\"><a href=\"http://www.unl.edu/\">UNL</a></li> <li><a href=\"http://www.unl.edu/\">My Organization</a></li> <li>This Page Title</li> </ul>";                    // string()  
    public $maincontentarea = "<div style=\"margin:20px; border:3px solid #CC0000;padding:10px; text-align:center\"> <p style=\"margin:0px;font-weight:bold;\">Delete this box and place your content here.</p> <p>Remember to validate your pages before publishing!<br /> <a href=\"http://validator.w3.org/check/referer\">Click here to check Validation</a></p> <p style=\"margin:1.5em 0;\">Sample layouts are available through the <a href=\"http://www.unl.edu/webdevnet/\">Web Developer Network</a>.</p> </div>";                // string()  
    public $rightrandompromojs = "<script type=\"text/javascript\" src=\"/cssunltemplates/sharedcode/rightRandomPromo.js\"></script>";             // string()  
    public $footercontent = "<!--#include virtual=\"/cssunltemplates/sharedcode/footer.html\" -->";                  // string()  
    public $navlinks = "<!--#include virtual=\"/cssunltemplates/sharedcode/navigation.html\" -->";                       // string()  
    public $toolbar = "<!--#include virtual=\"/unlpub/templatedependents/templatesharedcode/includes/toolbar/toolbar.shtml\" -->";                        // string()  

    /* Static get */
    function staticGet($k,$v=NULL) { return UNL_DWT::staticGet('UNL_Templates_Liquid',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
