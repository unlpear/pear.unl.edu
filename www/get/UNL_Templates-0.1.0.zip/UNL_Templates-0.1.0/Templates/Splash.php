<?php
/**
 * Template Definition for splash.dwt
 */
require_once 'UNL/Templates.php';

class UNL_Templates_Splash extends UNL_Templates 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__template = 'Splash.tpl';                      // template name
    public $doctitle = "<title>UNL | Splash</title>";                       // string()  
    public $head = "<style type=\"text/css\"> #buttonlinks { margin-left:1px; } .btn_l1 img { padding: 0pt; margin-bottom: -3px; } .btn_l1 { margin-left:0px; margin-right:7px; } </style> <script type=\"text/javascript\"> var navl2Links = 0; //Default navline2 links to display (zero based counting) </script>";                           // string()  
    public $titlegraphic = "<img alt=\"\" id=\"splashRandomImg\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/transpixel.gif\" /> <script type=\"text/javascript\" src=\"/cssunltemplates/sharedcode/splash.js\"></script>";                   // string()  
    public $maincontentarea = "<!-- begin link button table --> <div id=\"buttonlinks\"> <a class=\"btn_l1\" href=\"http://www.unl.edu/unlpub/admissions.shtml\" title=\"Information for prospective UNL undergraduate, graduate, law and distance education students\"><img style=\"border:none;\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/btn_l1_prostu.gif\" width=\"81\" height=\"120\" alt=\"prospective students\" /></a> <a class=\"btn_l1\" href=\"http://www.unl.edu/unlpub/tour/frame3/index_fullpage.shtml\" title=\"Campus tour of the University of Nebraska-Lincoln (high bandwidth; requires QuickTime)\"><img style=\"border:none;\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/btn_l1_camtou.gif\" width=\"81\" height=\"120\" alt=\"campus tour\" /></a> <a class=\"btn_l1\" href=\"http://www.unl.edu/unlpub/tour/unlmaps/\" title=\"UNL Campus Maps\"><img style=\"border:none;\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/btn_l1_cammap.gif\" width=\"81\" height=\"120\" alt=\"campus maps\" /></a> <a class=\"btn_l1\" href=\"http://realnebraska.unl.edu\" title=\"Real Nebraska\"><img style=\"border:none;\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/btn_l1_reaneb.gif\" width=\"81\" height=\"120\" alt=\"Real Nebraska\" /></a> <a class=\"btn_l1\" href=\"javascript:makeRemoteCAL()\" title=\"UNL Searchable Events Calendar\"><img style=\"border:none;\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/btn_l1_unlcal.gif\" width=\"81\" height=\"120\" alt=\"UNL calendar\" /></a> <a class=\"btn_l1\" href=\"http://hr.unl.edu/employment/\" title=\"UNL Employment Opportunities\"><img style=\"border:none;\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/btn_l1_empopp.gif\" width=\"81\" height=\"120\" alt=\"UNL  Employment Opportunities\" /></a> <a class=\"btn_l1\" href=\"http://ucommxsrv1.unl.edu/unlnews2004/\" title=\"UNL News Releases\"><img style=\"border:none;\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/btn_l1_newrel.gif\" width=\"81\" height=\"120\" alt=\"UNL news\" /></a> <a class=\"btn_l1\" style=\"margin-right:0px; \" href=\"http://www.unl.edu/unlpub/2004unltoday.shtml\" title=\"UNL Today, our live homepage for the University of Nebraska-Lincoln community\"><img style=\"border:none;\" src=\"http://www.unl.edu/unlpub/2004sharedgraphics/btn_l1_unltod.gif\" width=\"81\" height=\"120\" alt=\"UNL Today\" /></a> </div> <!-- end of link button table -->";                // string()  
    public $footercontent = "<!--#include virtual=\"/cssunltemplates/sharedcode/footer.html\" -->";                  // string()  
    public $navlinks = "<!--#include virtual=\"/cssunltemplates/sharedcode/navigation.html\" -->";                       // string()  
    public $toolbar = "<!--#include virtual=\"/unlpub/templatedependents/templatesharedcode/includes/toolbar/toolbar.shtml\" -->";                        // string()  

    /* Static get */
    function staticGet($k,$v=NULL) { return UNL_DWT::staticGet('UNL_Templates_Splash',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
