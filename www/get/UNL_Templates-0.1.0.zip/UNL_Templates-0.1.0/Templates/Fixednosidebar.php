<?php
/**
 * Template Definition for fixednosidebar.dwt
 */
require_once 'UNL/Templates.php';

class UNL_Templates_Fixednosidebar extends UNL_Templates 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__template = 'Fixednosidebar.tpl';              // template name
    public $doctitle = "<title>UNL | Fixed No Sidebar</title>";                       // string()  
    public $head = "<script type=\"text/javascript\"> var navl2Links = 0; //Default navline2 links to display (zero based counting) </script>";                           // string()  
    public $titlegraphic = "<h1>Page Header</h1>";                   // string()  
    public $breadcrumbs = "<ul> <li class=\"first\"><a href=\"http://www.unl.edu/\">UNL</a></li> <li><a href=\"http://www.unl.edu/\">My Organization</a></li> <li>This Page Title</li> </ul>";                    // string()  
    public $maincontentarea = "<div style=\"margin:20px; border:3px solid #CC0000;padding:10px; text-align:center\"> <p style=\"margin:0px;font-weight:bold;\">Delete this box and place your content here.</p> <p>Remember to validate your pages before publishing!<br /> <a href=\"http://validator.w3.org/check/referer\">Click here to check Validation</a></p> <p style=\"margin:1.5em 0;\">Sample layouts are available through the <a href=\"http://www.unl.edu/webdevnet/\">Web Developer Network</a>.</p> </div>";                // string()  
    public $footercontent = "<!--#include virtual=\"/cssunltemplates/sharedcode/footer.html\" -->";                  // string()  
    public $navlinks = "<!--#include virtual=\"/cssunltemplates/sharedcode/navigation.html\" -->";                       // string()  
    public $toolbar = "<!--#include virtual=\"/unlpub/templatedependents/templatesharedcode/includes/toolbar/toolbar.shtml\" -->";                        // string()  

    /* Static get */
    function staticGet($k,$v=NULL) { return UNL_DWT::staticGet('UNL_Templates_Fixednosidebar',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
