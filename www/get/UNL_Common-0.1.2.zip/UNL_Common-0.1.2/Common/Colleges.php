<?php
/**
* @author Brett Bieber
* Created on Mar 27, 2006
*/
class UNL_Common_Colleges {
	var $colleges = array();
	function UNL_Common_Colleges()
	{
		$this->colleges[] = 'Business Administration';
		$this->colleges[] = 'Fine & Performing Arts';
		$this->colleges[] = 'Arts & Sciences';
		$this->colleges[] = 'Education and Human Sciences';
		$this->colleges[] = 'Journalism & Mass Communications';
		$this->colleges[] = 'Agricultural Sciences & Natural Resources';
		$this->colleges[] = 'Engineering & Technology';
		$this->colleges[] = 'Architecture';
		$this->colleges[] = 'College of Dentistry';
		$this->colleges[] = 'Law';
		array_multisort($this->colleges,SORT_ASC);
	}
	
	/**
	* Return all the codes
	*
	* @access  public
	* @return  array   all colleges as associative array
	*/
	function getAllColleges()
	{
		return $this->colleges;
	}
}
?>
