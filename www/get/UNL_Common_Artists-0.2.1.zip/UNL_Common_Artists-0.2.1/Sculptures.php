<?php
/**
 * This package is an a DB_DataObject which connects to the database and allows searching for sculpture info.
 * 
 * @package UNL_Common_Arists
 * @author bbieber
 */
require_once 'DB/DataObject.php';
require_once 'UNL/Common/Artists/config.inc.php';

class UNL_Common_Sculptures extends DB_DataObject 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__table = 'sculptures';                      // table name
    public $id;                              // int(11)  not_null primary_key auto_increment
    public $title;                           // string(255)  not_null
    public $media;                           // string(100)  not_null
    public $date;                            // date(10)  binary
    public $info;                            // blob(16777215)  not_null blob
    public $imageurl;                        // string(255)  
    public $lat;                             // real(16)  
    public $lon;                             // real(16)  

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('UNL_Common_Sculptures',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
