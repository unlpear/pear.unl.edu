<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_stanton extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_stanton()
	{
		$this->_cities = array(
			'pilger' => 'Pilger',
			'stanton' => 'Stanton',
		);
	}

	function countyName()
	{
		return 'Stanton';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="StantonCounty" id="StantonCounty">' .
			'<area shape="rect" coords="214, 41, 279, 77" href="' . sprintf($urlpattern, 'pilger') . '" alt="Pilger" />' .
			'<area shape="rect" coords="73, 90, 159, 123" href="' . sprintf($urlpattern, 'stanton') . '" alt="Stanton" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'StantonCounty';
	}	
	
	function imageMapImage() {
		return 'stanton.gif';
	}
	
}