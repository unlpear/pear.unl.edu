<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_loup extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_loup()
	{
		$this->_cities = array(
			'almeria' => 'Almeria',
			'taylor' => 'Taylor',
		);
	}

	function countyName()
	{
		return 'Loup';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="LoupCounty" id="LoupCounty">' .
			'<area shape="rect" coords="219, 226, 310, 261" href="' . sprintf($urlpattern, 'taylor') . '" alt="Taylor" />' .
			'<area shape="rect" coords="115, 183, 209, 222" href="' . sprintf($urlpattern, 'almeria') . '" alt="Almeria" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'LoupCounty';
	}	
	
	function imageMapImage() {
		return 'loup.gif';
	}
	
}