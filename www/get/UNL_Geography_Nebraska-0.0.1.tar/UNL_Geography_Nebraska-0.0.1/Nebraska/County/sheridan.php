<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_sheridan extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_sheridan()
	{
		$this->_cities = array(
			'antioch' => 'Antioch',
			'bingham' => 'Bingham',
			'clinton' => 'Clinton',
			'ellsworth' => 'Ellsworth',
			'gordon' => 'Gordon',
			'haysprings' => 'Hay Springs',
			'lakeside' => 'Lakeside',
			'rushville' => 'Rushville',
			'whiteclay' => 'Whiteclay',
		);
	}

	function countyName()
	{
		return 'Sheridan';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="SheridanCounty" id="SheridanCounty">' .
			'<area shape="rect" coords="192, 340, 271, 362" href="' . sprintf($urlpattern, 'bingham') . '" alt="Bingham" />' .
			'<area shape="rect" coords="158, 313, 235, 344" href="' . sprintf($urlpattern, 'ellsworth') . '" alt="Ellsworth" />' .
			'<area shape="rect" coords="101, 332, 162, 362" href="' . sprintf($urlpattern, 'lakeside') . '" alt="Lakeside" />' .
			'<area shape="rect" coords="38, 315, 97, 339" href="' . sprintf($urlpattern, 'antioch') . '" alt="Antioch" />' .
			'<area shape="rect" coords="5, 111, 85, 146" href="' . sprintf($urlpattern, 'haysprings') . '" alt="Hay Springs" />' .
			'<area shape="rect" coords="87, 94, 160, 126" href="' . sprintf($urlpattern, 'rushville') . '" alt="Rushville" />' .
			'<area shape="rect" coords="135, 66, 193, 95" href="' . sprintf($urlpattern, 'clinton') . '" alt="Clinton" />' .
			'<area shape="rect" coords="200, 70, 257, 95" href="' . sprintf($urlpattern, 'gordon') . '" alt="Gordon" />' .
			'<area shape="rect" coords="48, 0, 126, 32" href="' . sprintf($urlpattern, 'whiteclay') . '" alt="Whiteclay" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'SheridanCounty';
	}	
	
	function imageMapImage() {
		return 'sheridan.gif';
	}
	
}