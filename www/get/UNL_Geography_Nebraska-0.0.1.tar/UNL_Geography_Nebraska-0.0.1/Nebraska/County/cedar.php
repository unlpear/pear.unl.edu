<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_cedar extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_cedar()
	{
		$this->_cities = array(
				'belden' => 'Belden',
				'bowvalley' => 'Bow Valley',
				'coleridge' => 'Coleridge',
				'fordyce' => 'Fordyce',
				'hartington' => 'Hartington',
				'laurel' => 'Laurel',
				'magnet' => 'Magnet',
				'obert' => 'Obert',
				'randolph' => 'Randolph',
				'sthelena' => 'St. Helena',
				'wynot' => 'Wynot',
			);
	}

	function countyName()
	{
		return 'Cedar';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="CedarCounty" id="CedarCounty">' .
			'<area shape="rect" coords="238, 280, 299, 308" href="' . sprintf($urlpattern, 'laurel') . '" alt="Laurel"/>' .
			'<area shape="rect" coords="160, 286, 219, 318" href="' . sprintf($urlpattern, 'belden') . '" alt="Belden"/>' .
			'<area shape="rect" coords="74, 319, 169, 344" href="' . sprintf($urlpattern, 'randolph') . '" alt="Randolph"/>' .
			'<area shape="rect" coords="3, 269, 80, 294" href="' . sprintf($urlpattern, 'magnet') . '" alt="Magnet"/>' .
			'<area shape="rect" coords="150, 226, 229, 254" href="' . sprintf($urlpattern, 'coleridge') . '" alt="Coleridge"/>' .
			'<area shape="rect" coords="109, 150, 201, 178" href="' . sprintf($urlpattern, 'hartington') . '" alt="Hartington"/>' .
			'<area shape="rect" coords="258, 111, 319, 139" href="' . sprintf($urlpattern, 'obert') . '" alt="Obert"/>' .
			'<area shape="rect" coords="139, 102, 230, 133" href="' . sprintf($urlpattern, 'bowvalley') . '" alt="Bow Valley"/>' .
			'<area shape="rect" coords="50, 97, 120, 129" href="' . sprintf($urlpattern, 'fordyce') . '" alt="Fordyce"/>' .
			'<area shape="rect" coords="182, 75, 242, 102" href="' . sprintf($urlpattern, 'wynot') . '" alt="Wynot"/>' .
			'<area shape="rect" coords="79, 32, 173, 57" href="' . sprintf($urlpattern, 'sthelena') . '" alt="St. Helena"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'CedarCounty';
	}	
	
	function imageMapImage() {
		return 'cedar.gif';
	}
	
}