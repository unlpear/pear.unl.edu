<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_furnas extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_furnas()
	{
		$this->_cities = array(
			'arapahoe' => 'Arapahoe',
			'beavercity' => 'Beaver City',
			'cambridge' => 'Cambridge',
			'edison' => 'Edison',
			'hendley' => 'Hendley',
			'holbrook' => 'Holbrook',
			'oxford' => 'Oxford',
			'wilsonville' => 'Wilsonville',
		);
	}

	function countyName()
	{
		return 'Furnas';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="FurnasCounty" id="FurnasCounty">' .
			'<area shape="rect" coords="10, 154, 116, 191" href="' . sprintf($urlpattern, 'wilsonville') . '" alt="Wilsonville"/>' .
			'<area shape="rect" coords="116, 136, 193, 177" href="' . sprintf($urlpattern, 'hendley') . '" alt="Hendley"/>' .
			'<area shape="rect" coords="202, 137, 310, 175" href="' . sprintf($urlpattern, 'beavercity') . '" alt="Beaver City"/>' .
			'<area shape="rect" coords="309, 55, 392, 81" href="' . sprintf($urlpattern, 'oxford') . '" alt="Oxford"/>' .
			'<area shape="rect" coords="253, 28, 324, 61" href="' . sprintf($urlpattern, 'edison') . '" alt="Edison"/>' .
			'<area shape="rect" coords="163, 33, 251, 61" href="' . sprintf($urlpattern, 'arapahoe') . '" alt="Arapahoe"/>' .
			'<area shape="rect" coords="82, 12, 181, 42" href="' . sprintf($urlpattern, 'holbrook') . '" alt="Holbrook"/>' .
			'<area shape="rect" coords="9, 46, 112, 74" href="' . sprintf($urlpattern, 'cambridge') . '" alt="Cambridge"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'FurnasCounty';
	}	
	
	function imageMapImage() {
		return 'furnas.gif';
	}
	
}