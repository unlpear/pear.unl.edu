<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_phelps extends UNL_Geography_Nebraska_County {

	function Nebraska_County_phelps()
	{
		$this->_cities = array(
			'atlanta' => 'Atlanta',
			'bertrand' => 'Bertrand',
			'funk' => 'Funk',
			'holdrege' => 'Holdrege',
			'loomis' => 'Loomis',
		);
	}

	function countyName()
	{
		return 'Phelps';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="PhelpsCounty" id="PhelpsCounty">' .
			'<area shape="rect" coords="290, 156, 346, 191" href="' . sprintf($urlpattern, 'funk') . '" alt="Funk" />' .
			'<area shape="rect" coords="169, 171, 264, 210" href="' . sprintf($urlpattern, 'holdrege') . '" alt="Holdrege" />' .
			'<area shape="rect" coords="96, 233, 180, 267" href="' . sprintf($urlpattern, 'atlanta') . '" alt="Atlanta" />' .
			'<area shape="rect" coords="80, 144, 146, 180" href="' . sprintf($urlpattern, 'loomis') . '" alt="Loomis" />' .
			'<area shape="rect" coords="0, 105, 86, 140" href="' . sprintf($urlpattern, 'bertrand') . '" alt="Bertrand" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'PhelpsCounty';
	}	
	
	function imageMapImage() {
		return 'phelps.gif';
	}
	
}