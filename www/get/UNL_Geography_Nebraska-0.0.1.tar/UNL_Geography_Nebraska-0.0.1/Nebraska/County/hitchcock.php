<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_hitchcock extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_hitchcock()
	{
		$this->_cities = array(
			'culbertson' => 'Culbertson',
			'palisade' => 'Palisade',
			'stratton' => 'Stratton',
			'trenton' => 'Trenton',
		);
	}

	function countyName()
	{
		return 'Hitchcock';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="HitchcockCounty" id="HitchcockCounty">' .
			'<area shape="rect" coords="26, 137, 115, 177" href="' . sprintf($urlpattern, 'stratton') . '" alt="Stratton"/>' .
			'<area shape="rect" coords="174, 123, 269, 160" href="' . sprintf($urlpattern, 'trenton') . '" alt="Trenton"/>' .
			'<area shape="rect" coords="274, 79, 394, 126" href="' . sprintf($urlpattern, 'culbertson') . '" alt="Culbertson"/>' .
			'<area shape="rect" coords="113, 7, 202, 43" href="' . sprintf($urlpattern, 'palisade') . '" alt="Palisade"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'HitchcockCounty';
	}	
	
	function imageMapImage() {
		return 'hitchcock.gif';
	}
	
}