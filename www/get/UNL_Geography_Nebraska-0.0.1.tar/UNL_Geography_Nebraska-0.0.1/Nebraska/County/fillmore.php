<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_fillmore extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_fillmore()
	{
		$this->_cities = array(
			'exeter' => 'Exeter',
			'fairmont' => 'Fairmont',
			'geneva' => 'Geneva',
			'grafton' => 'Grafton',
			'milligan' => 'Milligan',
			'ohiowa' => 'Ohiowa',
			'shickley' => 'Shickley',
			'strang' => 'Strang',
		);
	}

	function countyName()
	{
		return 'Fillmore';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="FillmoreCounty" id="FillmoreCounty">' .
			'<area shape="rect" coords="275, 213, 352, 252" href="' . sprintf($urlpattern, 'ohiowa') . '" alt="Ohiowa" />' .
			'<area shape="rect" coords="303, 144, 384, 177" href="' . sprintf($urlpattern, 'milligan') . '" alt="Milligan" />' .
			'<area shape="rect" coords="161, 214, 236, 250" href="' . sprintf($urlpattern, 'strang') . '" alt="Strang" />' .
			'<area shape="rect" coords="43, 213, 130, 247" href="' . sprintf($urlpattern, 'shickley') . '" alt="Shickley" />' .
			'<area shape="rect" coords="155, 117, 228, 156" href="' . sprintf($urlpattern, 'geneva') . '" alt="Geneva" />' .
			'<area shape="rect" coords="279, 20, 354, 57" href="' . sprintf($urlpattern, 'exeter') . '" alt="Exeter" />' .
			'<area shape="rect" coords="163, 31, 252, 66" href="' . sprintf($urlpattern, 'fairmont') . '" alt="Fairmont" />' .
			'<area shape="rect" coords="53, 36, 138, 72" href="' . sprintf($urlpattern, 'grafton') . '" alt="Grafton" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'FillmoreCounty';
	}	
	
	function imageMapImage() {
		return 'fillmore.gif';
	}
	
}