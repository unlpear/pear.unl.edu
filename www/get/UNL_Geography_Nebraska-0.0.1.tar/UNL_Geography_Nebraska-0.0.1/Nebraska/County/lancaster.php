<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_lancaster extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_lancaster()
	{
		$this->_cities = array(
			'bennet' => 'Bennet',
			'davey' => 'Davey',
			'denton' => 'Denton',
			'firth' => 'Firth',
			'hallam' => 'Hallam',
			'hickman' => 'Hickman',
			'lincoln' => 'Lincoln',
			'malcolm' => 'Malcolm',
			'panama' => 'Panama',
			'raymond' => 'Raymond',
			'roca' => 'Roca',
			'sprague' => 'Sprague',
			'waverly' => 'Waverly',
		);
	}

	function countyName()
	{
		return 'Lancaster';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="LancasterCounty" id="LancasterCounty">' .
			'<area shape="rect" coords="248, 288, 310, 320" href="' . sprintf($urlpattern, 'panama') . '" alt="Panama" />' .
			'<area shape="rect" coords="188, 332, 239, 362" href="' . sprintf($urlpattern, 'firth') . '" alt="Firth" />' .
			'<area shape="rect" coords="161, 287, 229, 319" href="' . sprintf($urlpattern, 'hickman') . '" alt="Hickman" />' .
			'<area shape="rect" coords="59, 333, 122, 363" href="' . sprintf($urlpattern, 'hallam') . '" alt="Hallam" />' .
			'<area shape="rect" coords="89, 285, 151, 309" href="' . sprintf($urlpattern, 'sprague') . '" alt="Sprague" />' .
			'<area shape="rect" coords="151, 248, 197, 280" href="' . sprintf($urlpattern, 'roca') . '" alt="Roca" />' .
			'<area shape="rect" coords="250, 232, 309, 266" href="' . sprintf($urlpattern, 'bennet') . '" alt="Bennet" />' .
			'<area shape="rect" coords="22, 192, 84, 229" href="' . sprintf($urlpattern, 'denton') . '" alt="Denton" />' .
			'<area shape="rect" coords="124, 143, 191, 182" href="' . sprintf($urlpattern, 'lincoln') . '" alt="Lincoln" />' .
			'<area shape="rect" coords="4, 76, 74, 108" href="' . sprintf($urlpattern, 'malcolm') . '" alt="Malcolm" />' .
			'<area shape="rect" coords="229, 73, 301, 106" href="' . sprintf($urlpattern, 'waverly') . '" alt="Waverly" />' .
			'<area shape="rect" coords="57, 46, 129, 75" href="' . sprintf($urlpattern, 'raymond') . '" alt="Raymond" />' .
			'<area shape="rect" coords="143, 29, 200, 58" href="' . sprintf($urlpattern, 'davey') . '" alt="Davey" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'LancasterCounty';
	}	
	
	function imageMapImage() {
		return 'lancaster.gif';
	}
	
}