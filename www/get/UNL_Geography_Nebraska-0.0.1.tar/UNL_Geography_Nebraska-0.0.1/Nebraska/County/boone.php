<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_boone extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_boone()
	{
		$this->_cities = array(
				'albion' => 'Albion',
				'boone' => 'Boone',
				'cedarrapids' => 'Cedar Rapids',
				'loretto' => 'Loretto',
				'petersburg' => 'Petersburg',
				'primrose' => 'Primrose',
				'raeville' => 'Raeville',
				'stedward' => 'St. Edward',
			);
	}

	function countyName()
	{
		return 'Boone';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="BooneCounty" id="BooneCounty">' .
			'<area shape="rect" coords="255, 251, 348, 283" href="' . sprintf($urlpattern, 'stedward') . '" alt="St. Edward"/>' .
			'<area shape="rect" coords="57, 242, 167, 279" href="' . sprintf($urlpattern, 'cedarrapids') . '" alt="Cedar Rapids"/>' .
			'<area shape="rect" coords="8, 194, 86, 230" href="' . sprintf($urlpattern, 'primrose') . '" alt="Primrose"/>' .
			'<area shape="rect" coords="252, 198, 320, 232" href="' . sprintf($urlpattern, 'boone') . '" alt="Boone"/>' .
			'<area shape="rect" coords="191, 147, 259, 177" href="' . sprintf($urlpattern, 'albion') . '" alt="Albion"/>' .
			'<area shape="rect" coords="128, 91, 201, 125" href="' . sprintf($urlpattern, 'loretto') . '" alt="Loretto"/>' .
			'<area shape="rect" coords="117, 33, 224, 60" href="' . sprintf($urlpattern, 'petersburg') . '" alt="Petersburg"/>' .
			'<area shape="rect" coords="174, 5, 264, 28" href="' . sprintf($urlpattern, 'raeville') . '" alt="Raeville"/>' .
			'</map>';
			
		return $map;
	}

	function imageMapName() {
		return 'BooneCounty';
	}	
	
	function imageMapImage() {
		return 'boone.gif';
	}
	
}