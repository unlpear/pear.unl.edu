<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_hayes extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_hayes()
	{
		$this->_cities = array(
			'hamlet' => 'Hamlet',
			'hayescenter' => 'Hayes Center',
		);
	}

	function countyName()
	{
		return 'Hayes';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="HayesCounty" id="HayesCounty">' .
			'<area shape="rect" coords="51, 217, 123, 248" href="' . sprintf($urlpattern, 'hamlet') . '" alt="Hamlet"/>' .
			'<area shape="rect" coords="179, 112, 312, 159" href="' . sprintf($urlpattern, 'hayescenter') . '" alt="Hayes Center"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'HayesCounty';
	}	
	
	function imageMapImage() {
		return 'hayes.gif';
	}
	
}