<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_dakota extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_dakota()
	{
		$this->_cities = array(
				'dakotacity' => 'Dakota City',
				'emerson' => 'Emerson',
				'homer' => 'Homer',
				'hubbard' => 'Hubbard',
				'jackson' => 'Jackson',
				'southsiouxcity' => 'South Sioux City',
			);
	}

	function countyName()
	{
		return 'Dakota';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="DakotaCounty" id="DakotaCounty">' .
			'<area shape="rect" coords="240, 24, 382, 53" href="' . sprintf($urlpattern, 'southsiouxcity') . '" alt="South Sioux City"/>' .
			'<area shape="rect" coords="138, 72, 253, 102" href="' . sprintf($urlpattern, 'dakotacity') . '" alt="Dakota City"/>' .
			'<area shape="rect" coords="93, 44, 167, 72" href="' . sprintf($urlpattern, 'jackson') . '" alt="Jackson"/>' .
			'<area shape="rect" coords="68, 95, 148, 122" href="' . sprintf($urlpattern, 'hubbard') . '" alt="Hubbard"/>' .
			'<area shape="rect" coords="151, 140, 218, 170" href="' . sprintf($urlpattern, 'homer') . '" alt="Homer"/>' .
			'<area shape="rect" coords="0, 179, 79, 202" href="' . sprintf($urlpattern, 'emerson') . '" alt="Emerson"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'DakotaCounty';
	}	
	
	function imageMapImage() {
		return 'dakota.gif';
	}
	
}