<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_dawson extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_dawson()
	{
		$this->_cities = array(
				'cozad' => 'Cozad',
				'eddyville' => 'Eddyville',
				'farnam' => 'Farnam',
				'gothenburg' => 'Gothenburg',
				'lexington' => 'Lexington',
				'overton' => 'Overton',
				'sumner' => 'Sumner',
				'willowisland' => 'Willow Island',
			);
	}

	function countyName()
	{
		return 'Dawson';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="DawsonCounty" id="DawsonCounty">' .
			'<area shape="rect" coords="343, 168, 440, 207" href="' . sprintf($urlpattern, 'overton') . '" alt="Overton"/>' .
			'<area shape="rect" coords="231, 135, 331, 181" href="' . sprintf($urlpattern, 'lexington') . '" alt="Lexington"/>' .
			'<area shape="rect" coords="371, 56, 453, 90" href="' . sprintf($urlpattern, 'sumner') . '" alt="Sumner"/>' .
			'<area shape="rect" coords="292, 10, 395, 49" href="' . sprintf($urlpattern, 'eddyville') . '" alt="Eddyville"/>' .
			'<area shape="rect" coords="0, 168, 76, 202" href="' . sprintf($urlpattern, 'farnam') . '" alt="Farnam"/>' .
			'<area shape="rect" coords="105, 107, 174, 144" href="' . sprintf($urlpattern, 'cozad') . '" alt="Cozad"/>' .
			'<area shape="rect" coords="77, 73, 220, 107" href="' . sprintf($urlpattern, 'willowisland') . '" alt="Willow Island"/>' .
			'<area shape="rect" coords="5, 47, 115, 78" href="' . sprintf($urlpattern, 'gothenburg') . '" alt="Gothenburg"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'DawsonCounty';
	}	
	
	function imageMapImage() {
		return 'dawson.gif';
	}
	
}