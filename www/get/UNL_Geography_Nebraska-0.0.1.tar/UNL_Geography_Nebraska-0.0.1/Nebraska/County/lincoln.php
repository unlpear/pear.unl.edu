<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_lincoln extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_lincoln()
	{
		$this->_cities = array(
			'brady' => 'Brady',
			'dickens' => 'Dickens',
			'hershey' => 'Hershey',
			'maxwell' => 'Maxwell',
			'northplatte' => 'North Platte',
			'sutherland' => 'Sutherland',
			'wallace' => 'Wallace',
			'wellfleet' => 'Wellfleet',
		);
	}

	function countyName()
	{
		return 'Lincoln';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="LincolnCounty" id="LincolnCounty">' .
			'<area shape="rect" coords="199, 233, 312, 267" href="' . sprintf($urlpattern, 'wellfleet') . '" alt="Wellfleet" />' .
			'<area shape="rect" coords="102, 210, 196, 240" href="' . sprintf($urlpattern, 'dickens') . '" alt="Dickens" />' .
			'<area shape="rect" coords="14, 206, 90, 247" href="' . sprintf($urlpattern, 'wallace') . '" alt="Wallace" />' .
			'<area shape="rect" coords="346, 133, 408, 161" href="' . sprintf($urlpattern, 'brady') . '" alt="Brady" />' .
			'<area shape="rect" coords="280, 109, 369, 137" href="' . sprintf($urlpattern, 'maxwell') . '" alt="Maxwell" />' .
			'<area shape="rect" coords="189, 89, 317, 115" href="' . sprintf($urlpattern, 'northplatte') . '" alt="North Platte" />' .
			'<area shape="rect" coords="102, 82, 189, 113" href="' . sprintf($urlpattern, 'hershey') . '" alt="Hershey" />' .
			'<area shape="rect" coords="11, 88, 107, 123" href="' . sprintf($urlpattern, 'sutherland') . '" alt="Sutherland" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'LincolnCounty';
	}	
	
	function imageMapImage() {
		return 'lincoln.gif';
	}
	
}