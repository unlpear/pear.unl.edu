<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_thurston extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_thurston()
	{
		$this->_cities = array(
			'macy' => 'Macy',
			'pender' => 'Pender',
			'rosalie' => 'Rosalie',
			'thurston' => 'Thurston',
			'walthill' => 'Walthill',
			'winnebago' => 'Winnebago',
		);
	}

	function countyName()
	{
		return 'Thurston';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="ThurstonCounty" id="ThurstonCounty">' .
			'<area shape="rect" coords="214, 157, 284, 189" href="' . sprintf($urlpattern, 'rosalie') . '" alt="Rosalie" />' .
			'<area shape="rect" coords="356, 115, 417, 147" href="' . sprintf($urlpattern, 'macy') . '" alt="Macy" />' .
			'<area shape="rect" coords="217, 83, 305, 115" href="' . sprintf($urlpattern, 'walthill') . '" alt="Walthill" />' .
			'<area shape="rect" coords="226, 12, 330, 46" href="' . sprintf($urlpattern, 'winnebago') . '" alt="Winnebago" />' .
			'<area shape="rect" coords="50, 115, 127, 149" href="' . sprintf($urlpattern, 'pender') . '" alt="Pender" />' .
			'<area shape="rect" coords="53, 64, 141, 94" href="' . sprintf($urlpattern, 'thurston') . '" alt="Thurston" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'ThurstonCounty';
	}	
	
	function imageMapImage() {
		return 'thurston.gif';
	}
	
}