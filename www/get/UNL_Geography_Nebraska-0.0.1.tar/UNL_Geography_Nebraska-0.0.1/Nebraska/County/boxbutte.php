<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_boxbutte extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_boxbutte()
	{
		$this->_cities = array(
				'alliance' => 'Alliance',
				'hemingford' => 'Hemingford',
			);
	}

	function countyName()
	{
		return 'Box Butte';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="BoxButteCounty" id="BoxButteCounty">' .
			'<area shape="rect" coords="206, 139, 280, 174" href="' . sprintf($urlpattern, 'alliance') . '" alt="Alliance"/>' .
			'<area shape="rect" coords="111, 46, 208, 82" href="' . sprintf($urlpattern, 'hemingford') . '" alt="Hemingford"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'BoxButteCounty';
	}	
	
	function imageMapImage() {
		return 'boxbutte.gif';
	}
	
}