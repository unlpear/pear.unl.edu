<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_johnson extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_johnson()
	{
		$this->_cities = array(
			'cook' => 'Cook',
			'craborchard' => 'Crab Orchard',
			'elkcreek' => 'Elk Creek',
			'sterling' => 'Sterling',
			'stmary' => 'St. Mary',
			'tecumseh' => 'Tecumseh',
		);
	}

	function countyName()
	{
		return 'Johnson';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="JohnsonCounty" id="JohnsonCounty">' .
			'<area shape="rect" coords="176, 101, 266, 132" href="' . sprintf($urlpattern, 'tecumseh') . '" alt="Tecumseh" />' .
			'<area shape="rect" coords="104, 61, 181, 93" href="' . sprintf($urlpattern, 'stmary') . '" alt="St. Mary" />' .
			'<area shape="rect" coords="226, 170, 315, 203" href="' . sprintf($urlpattern, 'elkcreek') . '" alt="Elk Creek" />' .
			'<area shape="rect" coords="6, 131, 127, 165" href="' . sprintf($urlpattern, 'craborchard') . '" alt="Crab Orchard" />' .
			'<area shape="rect" coords="37, 29, 117, 64" href="' . sprintf($urlpattern, 'sterling') . '" alt="Sterling" />' .
			'<area shape="rect" coords="218, 6, 271, 38" href="' . sprintf($urlpattern, 'cook') . '" alt="Cook" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'JohnsonCounty';
	}	
	
	function imageMapImage() {
		return 'johnson.gif';
	}
	
}