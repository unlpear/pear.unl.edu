<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_howard extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_howard()
	{
		$this->_cities = array(
			'boelus' => 'Boelus',
			'cotesfield' => 'Cotesfield',
			'cushing' => 'Cushing',
			'dannebrog' => 'Dannebrog',
			'elba' => 'Elba',
			'farwell' => 'Farwell',
			'stlibory' => 'St. Libory',
			'stpaul' => 'St. Paul',
		);
	}

	function countyName()
	{
		return 'Howard';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="HowardCounty" id="HowardCounty">' .
			'<area shape="rect" coords="254, 220, 340, 253" href="' . sprintf($urlpattern, 'stlibory') . '" alt="St. Libory"/>' .
			'<area shape="rect" coords="2, 227, 64, 257" href="' . sprintf($urlpattern, 'boelus') . '" alt="Boelus"/>' .
			'<area shape="rect" coords="105, 189, 208, 221" href="' . sprintf($urlpattern, 'dannebrog') . '" alt="Dannebrog"/>' .
			'<area shape="rect" coords="185, 118, 258, 150" href="' . sprintf($urlpattern, 'stpaul') . '" alt="St. Paul"/>' .
			'<area shape="rect" coords="55, 120, 131, 153" href="' . sprintf($urlpattern, 'farwell') . '" alt="Farwell"/>' .
			'<area shape="rect" coords="254, 57, 328, 90" href="' . sprintf($urlpattern, 'cushing') . '" alt="Cushing"/>' .
			'<area shape="rect" coords="112, 69, 166, 95" href="' . sprintf($urlpattern, 'elba') . '" alt="Elba"/>' .
			'<area shape="rect" coords="40, 26, 135, 54" href="' . sprintf($urlpattern, 'cotesfield') . '" alt="Cotesfield"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'HowardCounty';
	}	
	
	function imageMapImage() {
		return 'howard.gif';
	}
	
}