<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_cherry extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_cherry()
	{
		$this->_cities = array(
				'brownlee' => 'Brownlee',
				'cody' => 'Cody',
				'crookston' => 'Crookston',
				'elsmere' => 'Elsmere',
				'kilgore' => 'Kilgore',
				'merriman' => 'Merriman',
				'nenzel' => 'Nenzel',
				'sparks' => 'Sparks',
				'valentine' => 'Valentine',
				'woodlake' => 'Wood Lake',
			);
	}

	function countyName()
	{
		return 'Cherry';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="CherryCounty" id="CherryCounty">' .
			'<area shape="rect" coords="491, 224, 555, 264" href="' . sprintf($urlpattern, 'elsmere') . '" alt="Elsmere"/>' .
			'<area shape="rect" coords="376, 191, 463, 232" href="' . sprintf($urlpattern, 'brownlee') . '" alt="Brownlee"/>' .
			'<area shape="rect" coords="465, 95, 548, 133" href="' . sprintf($urlpattern, 'woodlake') . '" alt="Wood Lake"/>' .
			'<area shape="rect" coords="488, 14, 546, 44" href="' . sprintf($urlpattern, 'sparks') . '" alt="Sparks"/>' .
			'<area shape="rect" coords="411, 40, 482, 70" href="' . sprintf($urlpattern, 'valentine') . '" alt="Valentine"/>' .
			'<area shape="rect" coords="345, 20, 427, 45" href="' . sprintf($urlpattern, 'crookston') . '" alt="Crookston"/>' .
			'<area shape="rect" coords="296, 3, 359, 30" href="' . sprintf($urlpattern, 'kilgore') . '" alt="Kilgore"/>' .
			'<area shape="rect" coords="260, 22, 308, 56" href="' . sprintf($urlpattern, 'nenzel') . '" alt="Nenzel"/>' .
			'<area shape="rect" coords="195, 5, 249, 32" href="' . sprintf($urlpattern, 'cody') . '" alt="Cody"/>' .
			'<area shape="rect" coords="78, 20, 151, 54" href="' . sprintf($urlpattern, 'merriman') . '" alt="Merriman"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'CherryCounty';
	}	
	
	function imageMapImage() {
		return 'cherry.gif';
	}
	
}