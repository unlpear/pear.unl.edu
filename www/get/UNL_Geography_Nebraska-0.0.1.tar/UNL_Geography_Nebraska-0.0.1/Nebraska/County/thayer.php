<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_thayer extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_thayer()
	{
		$this->_cities = array(
			'alexandria' => 'Alexandria',
			'belvidere' => 'Belvidere',
			'bruning' => 'Bruning',
			'byron' => 'Byron',
			'carleton' => 'Carleton',
			'chester' => 'Chester',
			'davenport' => 'Davenport',
			'deshler' => 'Deshler',
			'gilead' => 'Gilead',
			'hebron' => 'Hebron',
			'hubbell' => 'Hubbell',
		);
	}

	function countyName()
	{
		return 'Thayer';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="ThayerCounty" id="ThayerCounty">' .
			'<area shape="rect" coords="232, 263, 312, 296" href="' . sprintf($urlpattern, 'hubbell') . '" alt="Hubbell" />' .
			'<area shape="rect" coords="133, 264, 211, 295" href="' . sprintf($urlpattern, 'chester') . '" alt="Chester" />' .
			'<area shape="rect" coords="19, 262, 79, 300" href="' . sprintf($urlpattern, 'byron') . '" alt="Byron" />' .
			'<area shape="rect" coords="311, 147, 379, 184" href="' . sprintf($urlpattern, 'gilead') . '" alt="Gilead" />' .
			'<area shape="rect" coords="45, 152, 126, 188" href="' . sprintf($urlpattern, 'deshler') . '" alt="Deshler" />' .
			'<area shape="rect" coords="162, 135, 235, 168" href="' . sprintf($urlpattern, 'hebron') . '" alt="Hebron" />' .
			'<area shape="rect" coords="278, 85, 385, 116" href="' . sprintf($urlpattern, 'alexandria') . '" alt="Alexandria" />' .
			'<area shape="rect" coords="175, 61, 269, 94" href="' . sprintf($urlpattern, 'belvidere') . '" alt="Belvidere" />' .
			'<area shape="rect" coords="207, 0, 294, 28" href="' . sprintf($urlpattern, 'bruning') . '" alt="Bruning" />' .
			'<area shape="rect" coords="78, 37, 164, 65" href="' . sprintf($urlpattern, 'carleton') . '" alt="Carleton" />' .
			'<area shape="rect" coords="3, 10, 101, 42" href="' . sprintf($urlpattern, 'davenport') . '" alt="Davenport" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'ThayerCounty';
	}	
	
	function imageMapImage() {
		return 'thayer.gif';
	}
	
}