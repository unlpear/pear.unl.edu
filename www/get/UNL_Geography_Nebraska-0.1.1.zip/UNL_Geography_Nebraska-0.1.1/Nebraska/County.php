<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


include_once 'PEAR.php';

class UNL_Geography_Nebraska_County {

	var $_cities = array();
	
	function getCities() {
		return $this->_cities;
	}
	
	function countyName() {
		return false;
	}
	
	function cityName($city) {
		return $this->_cities[$city];
	}
	
	function imageMap() {
		return false;
	}
	
	function imageMapName() {
		return false;
	}
	
	function imageMapImage() {
		return false;
	}
	
	function &factory($county)
	{

		ini_set('track_errors', 1);
		$include_error = '';
		include_once 'UNL/Geography/Nebraska/County/' . $county . '.php';
		if (isset($php_errormsg)) {
			$include_error = $php_errormsg;
		}
		ini_restore('track_errors');
		
		$class = 'UNL_Geography_Nebraska_County_' . $county;
		if (class_exists($class)) {
			$county = &new $class();
            return $county;
		} else {
			return PEAR::raiseError('Nebraska County (' . $county . ') not found' . ($include_error ? ': ' . $include_error : '') . '.');
		}
	}
	
	function &singleton($county)
	{
		static $instances = array();
		
		if (empty($instances[$county])) {
			$instances[$county] = UNL_Geography_Nebraska_County::factory($county);
		}
		
		return $instances[$county];
	}

}