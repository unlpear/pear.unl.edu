<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_hooker extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_hooker()
	{
		$this->_cities = array(
			'mullen' => 'Mullen',
		);
	}

	function countyName()
	{
		return 'Hooker';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="HookerCounty" id="HookerCounty">' .
			'<area shape="rect" coords="261, 19, 365, 64" href="' . sprintf($urlpattern, 'mullen') . '" alt="Mullen"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'HookerCounty';
	}	
	
	function imageMapImage() {
		return 'hooker.gif';
	}
	
}