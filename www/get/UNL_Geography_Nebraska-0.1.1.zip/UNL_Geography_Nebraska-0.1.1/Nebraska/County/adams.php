<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_adams extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_adams()
	{
		$this->_cities = array(
			'ayr' => 'Ayr',
			'hastings' => 'Hastings',
			'holstein' => 'Holstein',
			'juniata' => 'Juniata',
			'kenesaw' => 'Kenesaw',
			'prosser' => 'Prosser',
			'roseland' => 'Roseland',
		);
	}
	
	function countyName()
	{
		return 'Adams';
	}

	function imageMap($urlpattern = null, $cities = array())
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		if (!count($cities)) {
			$cities = array_keys($this->_cities);
		}
		
		$map = '<map name="AdamsCounty" id="AdamsCounty">' .
			'<area shape="rect" coords="214, 196, 263, 229" href="' . sprintf($urlpattern, 'ayr') . '" alt="Ayr"/>' .
			'<area shape="rect" coords="113, 169, 200, 207" href="' . sprintf($urlpattern, 'roseland') . '" alt="Roseland"/>' .
			'<area shape="rect" coords="16, 172, 105, 209" href="' . sprintf($urlpattern, 'holstein') . '" alt="Holstein"/>' .
			'<area shape="rect" coords="232, 74, 321, 110" href="' . sprintf($urlpattern, 'hastings') . '" alt="Hastings"/>' .
			'<area shape="rect" coords="143, 69, 224, 103" href="' . sprintf($urlpattern, 'juniata') . '" alt="Juniata"/>' .
			'<area shape="rect" coords="12, 45, 95, 77" href="' . sprintf($urlpattern, 'kenesaw') . '" alt="Kenesaw"/>' .
			'<area shape="rect" coords="84, 6, 164, 37" href="' . sprintf($urlpattern, 'prosser') . '" alt="Prosser"/>' .
			'</map>';
		
		return $map;
	}

	function imageMapName() {
		return 'AdamsCounty';
	}	
	
	function imageMapImage() {
		return 'adams.gif';
	}
}