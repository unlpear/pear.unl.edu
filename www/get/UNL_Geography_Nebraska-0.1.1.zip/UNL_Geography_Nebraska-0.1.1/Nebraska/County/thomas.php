<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_thomas extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_thomas()
	{
		$this->_cities = array(
			'halsey' => 'Halsey',
			'seneca' => 'Seneca',
			'thedford' => 'Thedford',
		);
	}

	function countyName()
	{
		return 'Thomas';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="ThomasCounty" id="ThomasCounty">' .
			'<area shape="rect" coords="350, 125, 445, 163" href="' . sprintf($urlpattern, 'halsey') . '" alt="Halsey" />' .
			'<area shape="rect" coords="196, 70, 314, 110" href="' . sprintf($urlpattern, 'thedford') . '" alt="Thedford" />' .
			'<area shape="rect" coords="8, 26, 103, 60" href="' . sprintf($urlpattern, 'seneca') . '" alt="Seneca" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'ThomasCounty';
	}	
	
	function imageMapImage() {
		return 'thomas.gif';
	}
	
}