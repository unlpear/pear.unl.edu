<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_nemaha extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_nemaha()
	{
		$this->_cities = array(
			'auburn' => 'Auburn',
			'brock' => 'Brock',
			'brownville' => 'Brownville',
			'johnson' => 'Johnson',
			'julian' => 'Julian',
			'nemaha' => 'Nemaha',
			'peru' => 'Peru',
		);
	}

	function countyName()
	{
		return 'Nemaha';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="NemahaCounty" id="NemahaCounty">' .
			'<area shape="rect" coords="261, 146, 338, 181" href="' . sprintf($urlpattern, 'nemaha') . '" alt="Nemaha" />' .
			'<area shape="rect" coords="239, 98, 346, 135" href="' . sprintf($urlpattern, 'brownville') . '" alt="Brownville" />' .
			'<area shape="rect" coords="150, 91, 223, 125" href="' . sprintf($urlpattern, 'auburn') . '" alt="Auburn" />' .
			'<area shape="rect" coords="253, 33, 301, 67" href="' . sprintf($urlpattern, 'peru') . '" alt="Peru" />' .
			'<area shape="rect" coords="21, 74, 98, 108" href="' . sprintf($urlpattern, 'johnson') . '" alt="Johnson" />' .
			'<area shape="rect" coords="60, 17, 123, 51" href="' . sprintf($urlpattern, 'brock') . '" alt="Brock" />' .
			'<area shape="rect" coords="137, 1, 201, 31" href="' . sprintf($urlpattern, 'julian') . '" alt="Julian" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'NemahaCounty';
	}	
	
	function imageMapImage() {
		return 'nemaha.gif';
	}
	
}