<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_rock extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_rock()
	{
		$this->_cities = array(
			'bassett' => 'Bassett',
			'newport' => 'Newport',
			'rose' => 'Rose',
		);
	}

	function countyName()
	{
		return 'Rock';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="RockCounty" id="RockCounty">' .
			'<area shape="rect" coords="58, 330, 109, 366" href="' . sprintf($urlpattern, 'rose') . '" alt="Rose" />' .
			'<area shape="rect" coords="152, 97, 222, 136" href="' . sprintf($urlpattern, 'newport') . '" alt="Newport" />' .
			'<area shape="rect" coords="41, 109, 112, 143" href="' . sprintf($urlpattern, 'bassett') . '" alt="Bassett" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'RockCounty';
	}	
	
	function imageMapImage() {
		return 'rock.gif';
	}
	
}