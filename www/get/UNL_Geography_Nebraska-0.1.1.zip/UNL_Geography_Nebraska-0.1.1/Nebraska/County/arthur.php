<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_arthur extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_arthur()
	{
		$this->_cities = array(
				'arthur' => 'Arthur',
			);
	}

	function countyName()
	{
		return 'Arthur';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="ArthurCounty" id="ArthurCounty">' .
			'<area shape="rect" coords="179, 97, 271, 136" href="' . sprintf($urlpattern, 'arthur') . '" alt="Arthur"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'ArthurCounty';
	}	
	
	function imageMapImage() {
		return 'arthur.gif';
	}
	
}