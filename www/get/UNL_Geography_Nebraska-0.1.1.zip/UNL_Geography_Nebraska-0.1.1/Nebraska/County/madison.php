<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_madison extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_madison()
	{
		$this->_cities = array(
			'battlecreek' => 'Battle Creek',
			'madison' => 'Madison',
			'meadowgrove' => 'Meadow Grove',
			'newmangrove' => 'Newman Grove',
			'norfolk' => 'Norfolk',
		);
	}

	function countyName()
	{
		return 'Madison';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="MadisonCounty" id="MadisonCounty">' .
			'<area shape="rect" coords="6, 247, 129, 280" href="' . sprintf($urlpattern, 'newmangrove') . '" alt="Newman Grove" />' .
			'<area shape="rect" coords="257, 185, 338, 216" href="' . sprintf($urlpattern, 'madison') . '" alt="Madison" />' .
			'<area shape="rect" coords="286, 21, 366, 52" href="' . sprintf($urlpattern, 'norfolk') . '" alt="Norfolk" />' .
			'<area shape="rect" coords="127, 48, 244, 83" href="' . sprintf($urlpattern, 'battlecreek') . '" alt="Battle Creek" />' .
			'<area shape="rect" coords="13, 27, 137, 63" href="' . sprintf($urlpattern, 'meadowgrove') . '" alt="Meadow Grove" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'MadisonCounty';
	}	
	
	function imageMapImage() {
		return 'madison.gif';
	}
	
}