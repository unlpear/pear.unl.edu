<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_cass extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_cass()
	{
		$this->_cities = array(
				'alvo' => 'Alvo',
				'avoca' => 'Avoca',
				'cedarcreek' => 'Cedar Creek',
				'eagle' => 'Eagle',
				'elmwood' => 'Elmwood',
				'greenwood' => 'Greenwood',
				'louisville' => 'Louisville',
				'manley' => 'Manley',
				'murdock' => 'Murdock',
				'murray' => 'Murray',
				'nehawka' => 'Nehawka',
				'plattsmouth' => 'Plattsmouth',
				'southbend' => 'South Bend',
				'union' => 'Union',
				'weepingwater' => 'Weeping Water',
			);
	}

	function countyName()
	{
		return 'Cass';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="CassCounty" id="CassCounty">' .
			'<area shape="rect" coords="407, 198, 467, 231" href="' . sprintf($urlpattern, 'union') . '" alt="Union" />' .
			'<area shape="rect" coords="338, 173, 423, 204" href="' . sprintf($urlpattern, 'nehawka') . '" alt="Nehawka" />' .
			'<area shape="rect" coords="245, 196, 311, 233" href="' . sprintf($urlpattern, 'avoca') . '" alt="Avoca" />' .
			'<area shape="rect" coords="246, 134, 376, 169" href="' . sprintf($urlpattern, 'weepingwater') . '" alt="Weeping Water" />' .
			'<area shape="rect" coords="127, 162, 221, 196" href="' . sprintf($urlpattern, 'elmwood') . '" alt="Elmwood" />' .
			'<area shape="rect" coords="5, 180, 64, 216" href="' . sprintf($urlpattern, 'eagle') . '" alt="Eagle" />' .
			'<area shape="rect" coords="45, 139, 96, 174" href="' . sprintf($urlpattern, 'alvo') . '" alt="Alvo" />' .
			'<area shape="rect" coords="393, 103, 467, 136" href="' . sprintf($urlpattern, 'murray') . '" alt="Murray" />' .
			'<area shape="rect" coords="209, 99, 278, 131" href="' . sprintf($urlpattern, 'manley') . '" alt="Manley" />' .
			'<area shape="rect" coords="113, 92, 191, 129" href="' . sprintf($urlpattern, 'murdock') . '" alt="Murdock" />' .
			'<area shape="rect" coords="7, 67, 106, 97" href="' . sprintf($urlpattern, 'greenwood') . '" alt="Greenwood" />' .
			'<area shape="rect" coords="375, 43, 491, 73" href="' . sprintf($urlpattern, 'plattsmouth') . '" alt="Plattsmouth" />' .
			'<area shape="rect" coords="203, 54, 298, 82" href="' . sprintf($urlpattern, 'louisville') . '" alt="Louisville" />' .
			'<area shape="rect" coords="85, 41, 188, 68" href="' . sprintf($urlpattern, 'southbend') . '" alt="South Bend" />' .
			'<area shape="rect" coords="283, 8, 401, 38" href="' . sprintf($urlpattern, 'cedarcreek') . '" alt="Cedar Creek" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'CassCounty';
	}	
	
	function imageMapImage() {
		return 'cass.gif';
	}
	
}