<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_dawes extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_dawes()
	{
		$this->_cities = array(
				'chadron' => 'Chadron',
				'crawford' => 'Crawford',
				'marsland' => 'Marsland',
				'whitney' => 'Whitney',
			);
	}

	function countyName()
	{
		return 'Dawes';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="DawesCounty" id="DawesCounty">' .
			'<area shape="rect" coords="78, 215, 170, 239" href="' . sprintf($urlpattern, 'marsland') . '" alt="Marsland"/>' .
			'<area shape="rect" coords="17, 130, 94, 162" href="' . sprintf($urlpattern, 'crawford') . '" alt="Crawford"/>' .
			'<area shape="rect" coords="71, 81, 139, 113" href="' . sprintf($urlpattern, 'whitney') . '" alt="Whitney"/>' .
			'<area shape="rect" coords="176, 65, 246, 101" href="' . sprintf($urlpattern, 'chadron') . '" alt="Chadron"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'DawesCounty';
	}	
	
	function imageMapImage() {
		return 'dawes.gif';
	}
	
}