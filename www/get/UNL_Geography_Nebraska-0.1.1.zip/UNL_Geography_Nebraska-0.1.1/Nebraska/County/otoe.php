<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_otoe extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_otoe()
	{
		$this->_cities = array(
			'burr' => 'Burr',
			'douglas' => 'Douglas',
			'dunbar' => 'Dunbar',
			'lorton' => 'Lorton',
			'nebraskacity' => 'Nebraska City',
			'otoe' => 'Otoe',
			'palmyra' => 'Palmyra',
			'syracuse' => 'Syracuse',
			'talmage' => 'Talmage',
			'unadilla' => 'Unadilla',
		);
	}

	function countyName()
	{
		return 'Otoe';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="OtoeCounty" id="OtoeCounty">' .
			'<area shape="rect" coords="398, 82, 518, 118" href="' . sprintf($urlpattern, 'nebraskacity') . '" alt="Nebraska City" />' .
			'<area shape="rect" coords="318, 183, 402, 218" href="' . sprintf($urlpattern, 'talmage') . '" alt="Talmage" />' .
			'<area shape="rect" coords="325, 129, 395, 160" href="' . sprintf($urlpattern, 'lorton') . '" alt="Lorton" />' .
			'<area shape="rect" coords="322, 74, 396, 109" href="' . sprintf($urlpattern, 'dunbar') . '" alt="Dunbar" />' .
			'<area shape="rect" coords="257, 31, 309, 62" href="' . sprintf($urlpattern, 'otoe') . '" alt="Otoe" />' .
			'<area shape="rect" coords="188, 98, 271, 125" href="' . sprintf($urlpattern, 'syracuse') . '" alt="Syracuse" />' .
			'<area shape="rect" coords="111, 73, 199, 106" href="' . sprintf($urlpattern, 'unadilla') . '" alt="Unadilla" />' .
			'<area shape="rect" coords="110, 183, 162, 215" href="' . sprintf($urlpattern, 'burr') . '" alt="Burr" />' .
			'<area shape="rect" coords="33, 139, 109, 169" href="' . sprintf($urlpattern, 'douglas') . '" alt="Douglas" />' .
			'<area shape="rect" coords="22, 46, 104, 79" href="' . sprintf($urlpattern, 'palmyra') . '" alt="Palmyra" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'OtoeCounty';
	}	
	
	function imageMapImage() {
		return 'otoe.gif';
	}
	
}