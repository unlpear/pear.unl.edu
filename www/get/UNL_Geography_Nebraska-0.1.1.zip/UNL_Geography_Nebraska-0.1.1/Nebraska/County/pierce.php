<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_pierce extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_pierce()
	{
		$this->_cities = array(
			'foster' => 'Foster',
			'hadar' => 'Hadar',
			'mclean' => 'McLean',
			'osmond' => 'Osmond',
			'pierce' => 'Pierce',
			'plainview' => 'Plainview',
		);
	}

	function countyName()
	{
		return 'Pierce';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="PierceCounty" id="PierceCounty">' .
			'<area shape="rect" coords="238, 216, 297, 245" href="' . sprintf($urlpattern, 'hadar') . '" alt="Hadar" />' .
			'<area shape="rect" coords="187, 149, 247, 184" href="' . sprintf($urlpattern, 'pierce') . '" alt="Pierce" />' .
			'<area shape="rect" coords="93, 95, 155, 130" href="' . sprintf($urlpattern, 'foster') . '" alt="Foster" />' .
			'<area shape="rect" coords="220, 17, 287, 50" href="' . sprintf($urlpattern, 'mclean') . '" alt="McLean" />' .
			'<area shape="rect" coords="136, 35, 200, 70" href="' . sprintf($urlpattern, 'osmond') . '" alt="Osmond" />' .
			'<area shape="rect" coords="6, 37, 82, 67" href="' . sprintf($urlpattern, 'plainview') . '" alt="Plainview" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'PierceCounty';
	}	
	
	function imageMapImage() {
		return 'pierce.gif';
	}
	
}