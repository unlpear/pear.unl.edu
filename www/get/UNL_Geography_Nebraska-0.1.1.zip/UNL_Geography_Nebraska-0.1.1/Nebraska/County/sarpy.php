<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_sarpy extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_sarpy()
	{
		$this->_cities = array(
			'bellevue' => 'Bellevue',
			'gretna' => 'Gretna',
			'lavista' => 'La Vista',
			'papillion' => 'Papillion',
			'springfield' => 'Springfield',
		);
	}

	function countyName()
	{
		return 'Sarpy';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="SarpyCounty" id="SarpyCounty">' .
			'<area shape="rect" coords="362, 25, 465, 56" href="' . sprintf($urlpattern, 'bellevue') . '" alt="Bellevue" />' .
			'<area shape="rect" coords="216, 4, 322, 33" href="' . sprintf($urlpattern, 'lavista') . '" alt="La Vista" />' .
			'<area shape="rect" coords="245, 34, 344, 70" href="' . sprintf($urlpattern, 'papillion') . '" alt="Papillion" />' .
			'<area shape="rect" coords="139, 88, 260, 126" href="' . sprintf($urlpattern, 'springfield') . '" alt="Springfield" />' .
			'<area shape="rect" coords="55, 32, 145, 74" href="' . sprintf($urlpattern, 'gretna') . '" alt="Gretna" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'SarpyCounty';
	}	
	
	function imageMapImage() {
		return 'sarpy.gif';
	}
	
}