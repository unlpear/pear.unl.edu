<?php

class UNL_Common
{
    static public $db_file = 'unl_common.sqlite';
    
    static private $db;
    
    static function getDB()
    {
        if (!isset(UNL_Common::$db)) {
            return self::__connect();
        }
        return UNL_Common::$db;
    }

    static public function getDataDir()
    {
        if ('@@DATA_DIR@@' == '@@DATA'.'_DIR@@') {
            return dirname(__FILE__) . '/data/';
        }
        return '@@DATA_DIR@@/UNL_Common/data/';
    }
    
    static protected function __connect()
    {
        if (UNL_Common::$db = new SQLiteDatabase(self::getDataDir().UNL_Common::$db_file)) {
            return UNL_Common::$db;
        }
        throw new Exception('Cannot connect to database!');
    }
    
    static function tableExists($table)
    {
        $db = self::getDB();
        $result = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='$table'");
        return $result->numRows() > 0;
    }
    
    static function importCSV($table, $filename)
    {
        $db = self::getDB();
        if ($h = fopen($filename,'r')) {
            while ($line = fgets($h)) {
                $db->queryExec("INSERT INTO ".$table." VALUES ($line);");
            }
        }
    }
}

?>