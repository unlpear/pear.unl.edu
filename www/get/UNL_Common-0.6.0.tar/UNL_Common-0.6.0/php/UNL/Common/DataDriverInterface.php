<?php
interface UNL_Common_DataDriverInterface
{
    public function getCityBuildings();
    public function getEastBuildings();
    public function getAllBuildings();
}