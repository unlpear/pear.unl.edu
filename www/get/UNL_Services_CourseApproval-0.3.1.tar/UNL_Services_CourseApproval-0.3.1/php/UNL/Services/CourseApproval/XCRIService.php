<?php 
interface UNL_Services_CourseApproval_XCRIService
{
    function getAllCourses();
    function getSubjectArea($subjectarea);
}
