<?php

/**
 * This class holds all the events for the list.
 * 
 */
class UNL_UCBCN_EventListing
{
	// Array of UNL_UCBCN_Event objects for this listing.
	var $status;
	var $events = array();
	
	function __construct()
	{
		
	}
}
