<?php
class UNL_Services_CourseApproval_College
{
    public $areas_of_study;
}
