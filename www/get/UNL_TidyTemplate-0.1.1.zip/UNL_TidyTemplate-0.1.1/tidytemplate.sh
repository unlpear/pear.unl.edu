#!/usr/bin/php
<?php
/**
 * Executable script to tidy template files.
 * @package UNL_TidyTemplate
 */

require_once 'UNL/TidyTemplate.php';

if (!@$_SERVER['argv'][1]) {
    PEAR::raiseError("\nERROR: UNL TidyTemplate usage:\n./tidytemplate.sh *.shtml\n\n", null, PEAR_ERROR_DIE);
    exit;
}

ini_set('memory_limit','16M');

$tidytemplate = new UNL_TidyTemplate();

unset($_SERVER['argv'][0]);
if (stristr($_SERVER['argv'][1],'.')=='.app') {
	unset($_SERVER['argv'][1]);
}
$tidytemplate->tidyLocalFiles($_SERVER['argv']);

$results = array_count_values($tidytemplate->files);

echo 'Template files found: '.count($tidytemplate->files)."\n";

if (isset($results[1])) {
	echo 'Valid pages: '.$results[1]."\n";
}
if (isset($results[0])) {
	echo 'Invalid pages: '.$results[0]."\n";
}

echo 'TidyTemplate was able to fix the following files, but you should check them: '.count($tidytemplate->fixed)."\n";
foreach ($tidytemplate->fixed as $fixed) {
	echo $fixed."\n";
}

