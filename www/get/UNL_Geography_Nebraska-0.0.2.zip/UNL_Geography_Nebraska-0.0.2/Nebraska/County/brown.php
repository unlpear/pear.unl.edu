<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_brown extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_brown()
	{
		$this->_cities = array(
				'ainsworth' => 'Ainsworth',
				'johnstown' => 'Johnstown',
				'longpine' => 'Long Pine',
			);
	}

	function countyName()
	{
		return 'Brown';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="BrownCounty" id="BrownCounty">' .
			'<area shape="rect" coords="198, 155, 275, 188" href="' . sprintf($urlpattern, 'longpine') . '" alt="Long Pine"/>' .
			'<area shape="rect" coords="133, 129, 218, 163" href="' . sprintf($urlpattern, 'ainsworth') . '" alt="Ainsworth"/>' .
			'<area shape="rect" coords="29, 138, 114, 172" href="' . sprintf($urlpattern, 'johnstown') . '" alt="Johnstown"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'BrownCounty';
	}	
	
	function imageMapImage() {
		return 'brown.gif';
	}
	
}