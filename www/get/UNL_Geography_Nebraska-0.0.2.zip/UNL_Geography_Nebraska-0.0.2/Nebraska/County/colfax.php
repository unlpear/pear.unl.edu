<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_colfax extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_colfax()
	{
		$this->_cities = array(
				'clarkson' => 'Clarkson',
				'howells' => 'Howells',
				'leigh' => 'Leigh',
				'richland' => 'Richland',
				'rogers' => 'Rogers',
				'schuyler' => 'Schuyler',
			);
	}

	function countyName()
	{
		return 'Colfax';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="ColfaxCounty" id="ColfaxCounty">' .
			'<area shape="rect" coords="4, 230, 86, 262" href="' . sprintf($urlpattern, 'richland') . '" alt="Richland"/>' .
			'<area shape="rect" coords="113, 223, 198, 256" href="' . sprintf($urlpattern, 'schuyler') . '" alt="Schuyler"/>' .
			'<area shape="rect" coords="219, 203, 287, 240" href="' . sprintf($urlpattern, 'rogers') . '" alt="Rogers"/>' .
			'<area shape="rect" coords="10, 21, 73, 49" href="' . sprintf($urlpattern, 'leigh') . '" alt="Leigh"/>' .
			'<area shape="rect" coords="80, 12, 170, 42" href="' . sprintf($urlpattern, 'clarkson') . '" alt="Clarkson"/>' .
			'<area shape="rect" coords="179, 12, 262, 42" href="' . sprintf($urlpattern, 'howells') . '" alt="Howells"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'ColfaxCounty';
	}	
	
	function imageMapImage() {
		return 'colfax.gif';
	}
	
}