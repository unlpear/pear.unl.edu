<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_platte extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_platte()
	{
		$this->_cities = array(
			'columbus' => 'Columbus',
			'cornlea' => 'Cornlea',
			'creston' => 'Creston',
			'duncan' => 'Duncan',
			'humphrey' => 'Humphrey',
			'lindsay' => 'Lindsay',
			'monroe' => 'Monroe',
			'plattecenter' => 'Platte Center',
			'tarnov' => 'Tarnov',
		);
	}

	function countyName()
	{
		return 'Platte';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="PlatteCounty" id="PlatteCounty">' .
			'<area shape="rect" coords="309, 214, 400, 247" href="' . sprintf($urlpattern, 'columbus') . '" alt="Columbus" />' .
			'<area shape="rect" coords="216, 247, 289, 277" href="' . sprintf($urlpattern, 'duncan') . '" alt="Duncan" />' .
			'<area shape="rect" coords="140, 185, 210, 214" href="' . sprintf($urlpattern, 'monroe') . '" alt="Monroe" />' .
			'<area shape="rect" coords="201, 137, 322, 167" href="' . sprintf($urlpattern, 'plattecenter') . '" alt="Platte Center" />' .
			'<area shape="rect" coords="240, 87, 330, 114" href="' . sprintf($urlpattern, 'tarnov') . '" alt="Tarnov" />' .
			'<area shape="rect" coords="168, 49, 239, 77" href="' . sprintf($urlpattern, 'cornlea') . '" alt="Cornlea" />' .
			'<area shape="rect" coords="72, 14, 146, 44" href="' . sprintf($urlpattern, 'lindsay') . '" alt="Lindsay" />' .
			'<area shape="rect" coords="218, 23, 306, 52" href="' . sprintf($urlpattern, 'humphrey') . '" alt="Humphrey" />' .
			'<area shape="rect" coords="314, 7, 389, 38" href="' . sprintf($urlpattern, 'creston') . '" alt="Creston" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'PlatteCounty';
	}	
	
	function imageMapImage() {
		return 'platte.gif';
	}
	
}