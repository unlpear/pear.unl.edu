<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_knox extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_knox()
	{
		$this->_cities = array(
			'bazilemills' => 'Bazile Mills',
			'bloomfield' => 'Bloomfield',
			'center' => 'Center',
			'creighton' => 'Creighton',
			'crofton' => 'Crofton',
			'niobrara' => 'Niobrara',
			'santee' => 'Santee',
			'verdel' => 'Verdel',
			'verdigre' => 'Verdigre',
			'wausa' => 'Wausa',
			'winnetoon' => 'Winnetoon',
		);
	}

	function countyName()
	{
		return 'Knox';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="KnoxCounty" id="KnoxCounty">' .
			'<area shape="rect" coords="389, 204, 453, 233" href="' . sprintf($urlpattern, 'wausa') . '" alt="Wausa"/>' .
			'<area shape="rect" coords="220, 228, 303, 255" href="' . sprintf($urlpattern, 'creighton') . '" alt="Creighton"/>' .
			'<area shape="rect" coords="220, 202, 308, 224" href="' . sprintf($urlpattern, 'bazilemills') . '" alt="Bazile Mills"/>' .
			'<area shape="rect" coords="132, 197, 210, 224" href="' . sprintf($urlpattern, 'winnetoon') . '" alt="Winnetoon"/>' .
			'<area shape="rect" coords="362, 152, 455, 177" href="' . sprintf($urlpattern, 'bloomfield') . '" alt="Bloomfield"/>' .
			'<area shape="rect" coords="228, 138, 277, 169" href="' . sprintf($urlpattern, 'center') . '" alt="Center"/>' .
			'<area shape="rect" coords="126, 143, 191, 173" href="' . sprintf($urlpattern, 'verdigre') . '" alt="Verdigre"/>' .
			'<area shape="rect" coords="403, 77, 472, 103" href="' . sprintf($urlpattern, 'crofton') . '" alt="Crofton"/>' .
			'<area shape="rect" coords="245, 24, 295, 50" href="' . sprintf($urlpattern, 'santee') . '" alt="Santee"/>' .
			'<area shape="rect" coords="132, 71, 197, 100" href="' . sprintf($urlpattern, 'niobrara') . '" alt="Niobrara"/>' .
			'<area shape="rect" coords="46, 39, 95, 66" href="' . sprintf($urlpattern, 'verdel') . '" target="main" alt="Verdel"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'KnoxCounty';
	}	
	
	function imageMapImage() {
		return 'knox.gif';
	}
	
}