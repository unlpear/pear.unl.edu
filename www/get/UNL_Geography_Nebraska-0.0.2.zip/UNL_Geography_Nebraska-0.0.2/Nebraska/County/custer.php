<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_custer extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_custer()
	{
		$this->_cities = array(
				'anselmo' => 'Anselmo',
				'ansley' => 'Ansley',
				'arnold' => 'Arnold',
				'berwyn' => 'Berwyn',
				'brokenbow' => 'Broken Bow',
				'callaway' => 'Callaway',
				'comstock' => 'Comstock',
				'masoncity' => 'Mason City',
				'merna' => 'Merna',
				'milburn' => 'Milburn',
				'oconto' => 'Oconto',
				'sargent' => 'Sargent',
				'weissert' => 'Weissert',
				'westerville' => 'Westerville',
			);
	}

	function countyName()
	{
		return 'Custer';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="CusterCounty" id="CusterCounty">' .
			'<area shape="rect" coords="272, 194, 390, 222" href="' . sprintf($urlpattern, 'masoncity') . '" alt="Mason City"/>' .
			'<area shape="rect" coords="278, 167, 357, 191" href="' . sprintf($urlpattern, 'ansley') . '" alt="Ansley"/>' .
			'<area shape="rect" coords="227, 144, 308, 166" href="' . sprintf($urlpattern, 'berwyn') . '" alt="Berwyn"/>' .
			'<area shape="rect" coords="329, 123, 412, 156" href="' . sprintf($urlpattern, 'westerville') . '" alt="Westerville"/>' .
			'<area shape="rect" coords="172, 116, 251, 148" href="' . sprintf($urlpattern, 'brokenbow') . '" alt="Broken Bow"/>' .
			'<area shape="rect" coords="119, 218, 208, 252" href="' . sprintf($urlpattern, 'oconto') . '" alt="Oconto"/>' .
			'<area shape="rect" coords="43, 161, 143, 194" href="' . sprintf($urlpattern, 'callaway') . '" alt="Callaway"/>' .
			'<area shape="rect" coords="12, 113, 91, 140" href="' . sprintf($urlpattern, 'arnold') . '" alt="Arnold"/>' .
			'<area shape="rect" coords="235, 92, 336, 122" href="' . sprintf($urlpattern, 'weissert') . '" alt="Weissert"/>' .
			'<area shape="rect" coords="131, 87, 207, 115" href="' . sprintf($urlpattern, 'merna') . '" alt="Merna"/>' .
			'<area shape="rect" coords="72, 31, 169, 65" href="' . sprintf($urlpattern, 'anselmo') . '" alt="Anselmo"/>' .
			'<area shape="rect" coords="309, 61, 408, 87" href="' . sprintf($urlpattern, 'comstock') . '" alt="Comstock"/>' .
			'<area shape="rect" coords="264, 20, 361, 55" href="' . sprintf($urlpattern, 'sargent') . '" alt="Sargent"/>' .
			'<area shape="rect" coords="133, 2, 220, 31" href="' . sprintf($urlpattern, 'milburn') . '" alt="Milburn"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'CusterCounty';
	}	
	
	function imageMapImage() {
		return 'custer.gif';
	}
	
}