<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_seward extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_seward()
	{
		$this->_cities = array(
			'beavercrossing' => 'Beaver Crossing',
			'bee' => 'Bee',
			'cordova' => 'Cordova',
			'garland' => 'Garland',
			'goehner' => 'Goehner',
			'milford' => 'Milford',
			'pleasantdale' => 'Pleasant Dale',
			'seward' => 'Seward',
			'staplehurst' => 'Staplehurst',
			'tamora' => 'Tamora',
			'utica' => 'Utica',
		);
	}

	function countyName()
	{
		return 'Seward';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="SewardCounty" id="SewardCounty">' .
			'<area shape="rect" coords="244, 178, 369, 215" href="' . sprintf($urlpattern, 'pleasantdale') . '" alt="Pleasant Dale" />' .
			'<area shape="rect" coords="211, 211, 297, 251" href="' . sprintf($urlpattern, 'milford') . '" alt="Milford" />' .
			'<area shape="rect" coords="0, 246, 78, 278" href="' . sprintf($urlpattern, 'cordova') . '" alt="Cordova" />' .
			'<area shape="rect" coords="7, 198, 150, 231" href="' . sprintf($urlpattern, 'beavercrossing') . '" alt="Beaver Crossing" />' .
			'<area shape="rect" coords="85, 153, 166, 185" href="' . sprintf($urlpattern, 'goehner') . '" alt="Goehner" />' .
			'<area shape="rect" coords="1, 99, 55, 133" href="' . sprintf($urlpattern, 'utica') . '" alt="Utica" />' .
			'<area shape="rect" coords="78, 102, 157, 140" href="' . sprintf($urlpattern, 'tamora') . '" alt="Tamora" />' .
			'<area shape="rect" coords="181, 89, 257, 126" href="' . sprintf($urlpattern, 'seward') . '" alt="Seward" />' .
			'<area shape="rect" coords="269, 62, 354, 99" href="' . sprintf($urlpattern, 'garland') . '" alt="Garland" />' .
			'<area shape="rect" coords="105, 40, 219, 75" href="' . sprintf($urlpattern, 'staplehurst') . '" alt="Staplehurst" />' .
			'<area shape="rect" coords="231, 16, 274, 49" href="' . sprintf($urlpattern, 'bee') . '" alt="Bee" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'SewardCounty';
	}	
	
	function imageMapImage() {
		return 'seward.gif';
	}
	
}