<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_butler extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_butler()
	{
		$this->_cities = array(
				'abie' => 'Abie',
				'bellwood' => 'Bellwood',
				'brainard' => 'Brainard',
				'bruno' => 'Bruno',
				'davidcity' => 'David City',
				'dwight' => 'Dwight',
				'garrison' => 'Garrison',
				'linwood' => 'Linwood',
				'octavia' => 'Octavia',
				'risingcity' => 'Rising City',
				'surprise' => 'Surprise',
				'ulysses' => 'Ulysses',
			);
	}

	function countyName()
	{
		return 'Butler';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="ButlerCounty" id="ButlerCounty">' .
			'<area shape="rect" coords="237, 259, 304, 296" href="' . sprintf($urlpattern, 'dwight') . '" alt="Dwight" />' .
			'<area shape="rect" coords="94, 268, 169, 305" href="' . sprintf($urlpattern, 'ulysses') . '" alt="Ulysses" />' .
			'<area shape="rect" coords="10, 237, 83, 279" href="' . sprintf($urlpattern, 'surprise') . '" alt="Surprise" />' .
			'<area shape="rect" coords="239, 180, 320, 221" href="' . sprintf($urlpattern, 'brainard') . '" alt="Brainard" />' .
			'<area shape="rect" coords="117, 192, 199, 228" href="' . sprintf($urlpattern, 'garrison') . '" alt="Garrison" />' .
			'<area shape="rect" coords="15, 173, 107, 206" href="' . sprintf($urlpattern, 'risingcity') . '" alt="Rising City" />' .
			'<area shape="rect" coords="283, 111, 346, 143" href="' . sprintf($urlpattern, 'bruno') . '" alt="Bruno" />' .
			'<area shape="rect" coords="145, 131, 236, 166" href="' . sprintf($urlpattern, 'davidcity') . '" alt="David City" />' .
			'<area shape="rect" coords="59, 66, 154, 101" href="' . sprintf($urlpattern, 'bellwood') . '" alt="Bellwood" />' .
			'<area shape="rect" coords="201, 64, 275, 93" href="' . sprintf($urlpattern, 'octavia') . '" alt="Octavia" />' .
			'<area shape="rect" coords="300, 75, 346, 104" href="' . sprintf($urlpattern, 'abie') . '" alt="Abie" />' .
			'<area shape="rect" coords="286, 22, 355, 55" href="' . sprintf($urlpattern, 'linwood') . '" alt="Linwood" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'ButlerCounty';
	}	
	
	function imageMapImage() {
		return 'butler.gif';
	}
	
}