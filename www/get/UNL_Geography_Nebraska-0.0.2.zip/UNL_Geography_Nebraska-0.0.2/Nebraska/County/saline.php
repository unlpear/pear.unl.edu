<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_saline extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_saline()
	{
		$this->_cities = array(
			'crete' => 'Crete',
			'dewitt' => 'DeWitt',
			'dorchester' => 'Dorchester',
			'friend' => 'Friend',
			'swanton' => 'Swanton',
			'tobias' => 'Tobias',
			'western' => 'Western',
			'wilber' => 'Wilber',
		);
	}

	function countyName()
	{
		return 'Saline';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="SalineCounty" id="SalineCounty">' .
			'<area shape="rect" coords="301, 222, 369, 260" href="' . sprintf($urlpattern, 'dewitt') . '" alt="DeWitt" />' .
			'<area shape="rect" coords="295, 150, 363, 189" href="' . sprintf($urlpattern, 'wilber') . '" alt="Wilber" />' .
			'<area shape="rect" coords="192, 238, 279, 273" href="' . sprintf($urlpattern, 'swanton') . '" alt="Swanton" />' .
			'<area shape="rect" coords="94, 219, 180, 262" href="' . sprintf($urlpattern, 'western') . '" alt="Western" />' .
			'<area shape="rect" coords="4, 196, 67, 241" href="' . sprintf($urlpattern, 'tobias') . '" alt="Tobias" />' .
			'<area shape="rect" coords="296, 35, 363, 74" href="' . sprintf($urlpattern, 'crete') . '" alt="Crete" />' .
			'<area shape="rect" coords="152, 22, 259, 57" href="' . sprintf($urlpattern, 'dorchester') . '" alt="Dorchester" />' .
			'<area shape="rect" coords="37, 18, 101, 54" href="' . sprintf($urlpattern, 'friend') . '" alt="Friend" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'SalineCounty';
	}	
	
	function imageMapImage() {
		return 'saline.gif';
	}
	
}