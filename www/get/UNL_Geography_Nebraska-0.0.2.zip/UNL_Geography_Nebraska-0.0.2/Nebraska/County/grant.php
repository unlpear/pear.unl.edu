<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_grant extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_grant()
	{
		$this->_cities = array(
			'ashby' => 'Ashby',
			'hyannis' => 'Hyannis',
			'whitman' => 'Whitman',
		);
	}

	function countyName()
	{
		return 'Grant';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="GrantCounty" id="GrantCounty">' .
			'<area shape="rect" coords="315, 26, 402, 77" href="' . sprintf($urlpattern, 'whitman') . '" alt="Whitman"/>' .
			'<area shape="rect" coords="192, 52, 287, 85" href="' . sprintf($urlpattern, 'hyannis') . '" alt="Hyannis"/>' .
			'<area shape="rect" coords="80, 36, 163, 77" href="' . sprintf($urlpattern, 'ashby') . '" alt="Ashby"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'GrantCounty';
	}	
	
	function imageMapImage() {
		return 'grant.gif';
	}
	
}