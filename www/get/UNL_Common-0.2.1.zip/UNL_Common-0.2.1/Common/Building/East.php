<?php
/**
* @author Brett Bieber
* @package UNL_Common
* Created on Sep 27, 2005
*/

/**
 * Class which can retrieve the buildings and codes for East Campus
 * 
 * @package UNL_Common
 */
class UNL_Common_Building_East
{
	var $codes = array();
	
	/**
	 * Constructor connects to database and loads codes and names.
	 * @return bool False on error.
	 */
	function UNL_Common_Building_East()
	{
		$link = mysql_connect('crusader.unl.edu', 'unl_common');
		if (!$link) {
			return false;
		} else {
			mysql_select_db('unl_common');
			$query = 'SELECT * FROM building_east';
			$result = mysql_query($query);
			while ($bldg = mysql_fetch_assoc($result)) {
				$this->codes[(string)$bldg['code']]=$bldg['name'];
			}
			mysql_close($link);
		}
	}
}
