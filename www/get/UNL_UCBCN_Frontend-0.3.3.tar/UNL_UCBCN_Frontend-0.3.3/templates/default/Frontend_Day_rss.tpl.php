<?php
	/**
	 * This sets up the format for the RSS
	 */
	UNL_UCBCN::outputTemplate('UNL_UCBCN_EventListing','EventListing_rss');
	UNL_UCBCN::displayRegion($this->output); ?>