#!/usr/bin/env php
<?php

$dir = getcwd();
chdir(dirname(__FILE__));
require_once 'UNL/TidyTemplate.php';

if (!@$_SERVER['argv'][1]) {
    PEAR::raiseError("\nERROR: UNL TidyTemplate usage:\n./tidytemplate.sh *.shtml\n\n", null, PEAR_ERROR_DIE);
    exit;
}

chdir($dir);
$tidytemplate = new UNL_TidyTemplate();

foreach ($_SERVER['argv'] as $param) {
	$tidytemplate->tidyLocalFiles($param);
}

$results = array_count_values($tidytemplate->files);

echo 'Template files found: '.count($tidytemplate->files)."\n";

if (isset($results[1])) {
	echo 'Valid pages: '.$results[1]."\n";
}
if (isset($results[0])) {
	echo 'Invalid pages: '.$results[0]."\n";
}

echo 'Fixed files: '.count($tidytemplate->fixed)."\n";
foreach ($tidytemplate->fixed as $fixed) {
	echo $fixed."\n";
}

