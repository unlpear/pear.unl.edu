<?php
/**
 * This package generates a table of css samples of all css selectors in a css file.
 * 
 * @created		2006-04-20
 * @author		Brett Bieber <brett.bieber@gmail.com>
 * @package		UNL_HTML_CSS_Sampler
 */

require_once 'HTML/CSS.php';
require_once 'HTML/Table.php';

class UNL_HTML_CSS_Sampler
{
	
	var $css;
	var $table;
	var $selectors;
	var $css_options;
	var $table_options;
	
	function __construct($css_options,$table_options)
	{
		$this->css_options = $css_options;
		$this->table_options = $table_options;
	}
	
	function Sampler($css_options=array('filename'=>''),$table_options=array('cellspacing="0"'))
	{
		return parent::__construct($css_options,$table_options);
	}
	
	function run()
	{
		$this->parseCSS();
		$this->buildSampleTable();
	}
	
	function parseCSS()
	{
		$this->css = new HTML_CSS($this->css_options);
	}
	
	function buildSampleTable()
	{
		$usedSelectors = array();
		$this->table = new HTML_Table($this->table_options);
		$this->table->addRow(array('Selector Name','Usage','Sample'),NULL,'TH');
		foreach ($this->css->toArray() as $selectors=>$attributes) {
			// Remove whitespace
			$selectors = str_replace(' ','',$selectors);
			// Get array of all the selectors
			$selectors = explode(',',$selectors);
			foreach($selectors as $selector) {
				$class = substr($selector,1);
				if (!empty($selector) && !empty($class) && strpos($class,':')===false && strpos($selector,'#')===false) {
					if (!in_array($selector,$usedSelectors)) {
						$usedSelectors[] = $selector;
						$sampletext = "The quick brown fox jumped over the lazy dog's back.";
						if (substr_count($selector,'.')==0) {
							$example = "<$selector>$sampletext</$selector>\n";
							$example .=	"<$selector>\n\t<a href='{$_SERVER['PHP_SELF']}'>visited link</a>,\n\t<a href=''>unvisited link</a>\n</$selector>\n";
						} else {
							$example = 	"<div class='$class'>$sampletext</div>\n";
							$example .=	"<a class='$class' href='{$_SERVER['PHP_SELF']}'>visited link</a>,\n\t<a class='$class' href=''>unvisited link</a>";
						}
						$example .= "<div class='vsource'><a href='#' onclick='return showHide(\"$selector\")'>View source+</a><div style='display:none;' id='$selector'><code><pre>".htmlentities($example)."</pre></code></div></div>";
						$this->table->addrow(array($selector,'',"<div class='stylewrap'>$example</div>"));
					}
				}
			}
		}
	}
	
	function toHtml()
	{
		return $this->table->toHtml();
	}
	
}
?>