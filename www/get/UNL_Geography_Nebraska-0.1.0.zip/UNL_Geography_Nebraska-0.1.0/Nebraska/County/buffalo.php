<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_buffalo extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_buffalo()
	{
		$this->_cities = array(
				'amherst' => 'Amherst',
				'elmcreek' => 'Elm Creek',
				'gibbon' => 'Gibbon',
				'kearney' => 'Kearney',
				'miller' => 'Miller',
				'odessa' => 'Odessa',
				'pleasanton' => 'Pleasanton',
				'poole' => 'Poole',
				'ravenna' => 'Ravenna',
				'riverdale' => 'Riverdale',
				'shelton' => 'Shelton',
			);
	}

	function countyName()
	{
		return 'Buffalo';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="BuffaloCounty" id="BuffaloCounty">' .
			'<area shape="rect" coords="395, 153, 458, 187" href="' . sprintf($urlpattern, 'shelton') . '" alt="Shelton"/>' .
			'<area shape="rect" coords="344, 172, 401, 208" href="' . sprintf($urlpattern, 'gibbon') . '" alt="Gibbon"/>' .
			'<area shape="rect" coords="322, 3, 403, 30" href="' . sprintf($urlpattern, 'ravenna') . '" alt="Ravenna"/>' .
			'<area shape="rect" coords="272, 27, 324, 59" href="' . sprintf($urlpattern, 'poole') . '" alt="Poole"/>' .
			'<area shape="rect" coords="178, 46, 269, 82" href="' . sprintf($urlpattern, 'pleasanton') . '" alt="Pleasanton"/>' .
			'<area shape="rect" coords="185, 198, 255, 230" href="' . sprintf($urlpattern, 'kearney') . '" alt="Kearney"/>' .
			'<area shape="rect" coords="128, 148, 211, 179" href="' . sprintf($urlpattern, 'riverdale') . '" alt="Riverdale"/>' .
			'<area shape="rect" coords="84, 202, 147, 236" href="' . sprintf($urlpattern, 'odessa') . '" alt="Odessa"/>' .
			'<area shape="rect" coords="5, 190, 76, 227" href="' . sprintf($urlpattern, 'elmcreek') . '" alt="Elm Creek"/>' .
			'<area shape="rect" coords="71, 117, 137, 151" href="' . sprintf($urlpattern, 'amherst') . '" alt="Amherst"/>' .
			'<area shape="rect" coords="5, 60, 59, 96" href="' . sprintf($urlpattern, 'miller') . '" alt="Miller"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'BuffaloCounty';
	}	
	
	function imageMapImage() {
		return 'buffalo.gif';
	}
	
}