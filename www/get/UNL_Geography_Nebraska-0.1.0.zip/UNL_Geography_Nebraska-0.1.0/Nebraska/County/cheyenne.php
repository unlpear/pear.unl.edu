<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_cheyenne extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_cheyenne()
	{
		$this->_cities = array(
				'dalton' => 'Dalton',
				'gurley' => 'Gurley',
				'lodgepole' => 'Lodgepole',
				'potter' => 'Potter',
				'sidney' => 'Sidney',
				'sunol' => 'Sunol',
			);
	}

	function countyName()
	{
		return 'Cheyenne';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="CheyenneCounty" id="CheyenneCounty">' .
			'<area shape="rect" coords="311, 153, 392, 182" href="' . sprintf($urlpattern, 'lodgepole') . '" alt="Lodgepole"/>' .
			'<area shape="rect" coords="274, 121, 328, 154" href="' . sprintf($urlpattern, 'sunol') . '" alt="Sunol"/>' .
			'<area shape="rect" coords="168, 141, 232, 180" href="' . sprintf($urlpattern, 'sidney') . '" alt="Sidney"/>' .
			'<area shape="rect" coords="8, 104, 70, 142" href="' . sprintf($urlpattern, 'potter') . '" alt="Potter"/>' .
			'<area shape="rect" coords="180, 56, 242, 89" href="' . sprintf($urlpattern, 'gurley') . '" alt="Gurley"/>' .
			'<area shape="rect" coords="179, 11, 243, 40" href="' . sprintf($urlpattern, 'dalton') . '" alt="Dalton"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'CheyenneCounty';
	}	
	
	function imageMapImage() {
		return 'cheyenne.gif';
	}
	
}