<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_cuming extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_cuming()
	{
		$this->_cities = array(
				'bancroft' => 'Bancroft',
				'beemer' => 'Beemer',
				'westpoint' => 'West Point',
				'wisner' => 'Wisner',
			);
	}

	function countyName()
	{
		return 'Cuming';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="CumingCounty" id="CumingCounty">' .
			'<area shape="rect" coords="270, 49, 367, 80" href="' . sprintf($urlpattern, 'bancroft') . '" alt="Bancroft"/>' .
			'<area shape="rect" coords="242, 190, 343, 222" href="' . sprintf($urlpattern, 'westpoint') . '" alt="West Point"/>' .
			'<area shape="rect" coords="156, 110, 238, 141" href="' . sprintf($urlpattern, 'beemer') . '" alt="Beemer"/>' .
			'<area shape="rect" coords="78, 66, 153, 96" href="' . sprintf($urlpattern, 'wisner') . '" alt="Wisner"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'CumingCounty';
	}	
	
	function imageMapImage() {
		return 'cuming.gif';
	}
	
}