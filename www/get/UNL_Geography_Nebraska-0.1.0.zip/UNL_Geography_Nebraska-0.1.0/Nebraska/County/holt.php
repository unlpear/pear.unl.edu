<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_holt extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_holt()
	{
		$this->_cities = array(
			'amella' => 'Amella',
			'atkinson' => 'Atkinson',
			'chambers' => 'Chambers',
			'emmet' => 'Emmet',
			'ewing' => 'Ewing',
			'inman' => 'Inman',
			'oneill' => "O'Neill",
			'page' => 'Page',
			'stuart' => 'Stuart',
		);
	}

	function countyName()
	{
		return 'Holt';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="HoltCounty" id="HoltCounty">' .
			'<area shape="rect" coords="344, 256, 402, 285" href="' . sprintf($urlpattern, 'ewing') . '" alt="Ewing"/>' .
			'<area shape="rect" coords="209, 266, 300, 296" href="' . sprintf($urlpattern, 'chambers') . '" alt="Chambers"/>' .
			'<area shape="rect" coords="118, 263, 182, 295" href="' . sprintf($urlpattern, 'amella') . '" alt="Amella"/>' .
			'<area shape="rect" coords="340, 193, 400, 220" href="' . sprintf($urlpattern, 'page') . '" alt="Page"/>' .
			'<area shape="rect" coords="281, 207, 337, 237" href="' . sprintf($urlpattern, 'inman') . '" alt="Inman"/>' .
			'<area shape="rect" coords="227, 171, 289, 206" href="' . sprintf($urlpattern, 'oneill') . '" alt="O\'Neill"/>' .
			'<area shape="rect" coords="165, 166, 223, 199" href="' . sprintf($urlpattern, 'emmet') . '" alt="Emmet"/>' .
			'<area shape="rect" coords="91, 144, 166, 177" href="' . sprintf($urlpattern, 'atkinson') . '" alt="Atkinson"/>' .
			'<area shape="rect" coords="33, 118, 92, 153" href="' . sprintf($urlpattern, 'stuart') . '" alt="Stuart"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'HoltCounty';
	}	
	
	function imageMapImage() {
		return 'holt.gif';
	}
	
}