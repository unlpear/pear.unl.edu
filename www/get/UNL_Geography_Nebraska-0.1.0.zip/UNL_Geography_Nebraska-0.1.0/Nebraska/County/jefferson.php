<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_jefferson extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_jefferson()
	{
		$this->_cities = array(
			'daykin' => 'Daykin',
			'diller' => 'Diller',
			'endicott' => 'Endicott',
			'fairbury' => 'Fairbury',
			'harbine' => 'Harbine',
			'jansen' => 'Jansen',
			'plymouth' => 'Plymouth',
			'reynolds' => 'Reynolds',
			'steelecity' => 'Steele City',
		);
	}

	function countyName()
	{
		return 'Jefferson';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="JeffersonCounty" id="JeffersonCounty">' .
			'<area shape="rect" coords="216, 215, 310, 247" href="' . sprintf($urlpattern, 'steelecity') . '" alt="Steele City" />' .
			'<area shape="rect" coords="280, 157, 340, 192" href="' . sprintf($urlpattern, 'diller') . '" alt="Diller" />' .
			'<area shape="rect" coords="167, 180, 244, 212" href="' . sprintf($urlpattern, 'endicott') . '" alt="Endicott" />' .
			'<area shape="rect" coords="8, 194, 86, 233" href="' . sprintf($urlpattern, 'reynolds') . '" alt="Reynolds" />' .
			'<area shape="rect" coords="108, 135, 186, 171" href="' . sprintf($urlpattern, 'fairbury') . '" alt="Fairbury" />' .
			'<area shape="rect" coords="262, 100, 331, 133" href="' . sprintf($urlpattern, 'harbine') . '" alt="Harbine" />' .
			'<area shape="rect" coords="188, 100, 250, 135" href="' . sprintf($urlpattern, 'jansen') . '" alt="Jansen" />' .
			'<area shape="rect" coords="248, 20, 332, 51" href="' . sprintf($urlpattern, 'plymouth') . '" alt="Plymouth" />' .
			'<area shape="rect" coords="27, 2, 89, 33" href="' . sprintf($urlpattern, 'daykin') . '" alt="Daykin" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'JeffersonCounty';
	}	
	
	function imageMapImage() {
		return 'jefferson.gif';
	}
	
}