<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_dixon extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_dixon()
	{
		$this->_cities = array(
				'allen' => 'Allen',
				'concord' => 'Concord',
				'dixon' => 'Dixon',
				'martinsburg' => 'Martinsburg',
				'maskell' => 'Maskell',
				'newcastle' => 'Newcastle',
				'ponca' => 'Ponca',
				'wakefield' => 'Wakefield',
				'waterbury' => 'Waterbury',
			);
	}

	function countyName()
	{
		return 'Dixon';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="DixonCounty" id="DixonCounty">' .
			'<area shape="rect" coords="83, 352, 171, 381" href="' . sprintf($urlpattern, 'wakefield') . '" alt="Wakefield"/>' .
			'<area shape="rect" coords="16, 288, 93, 318" href="' . sprintf($urlpattern, 'concord') . '" alt="Concord"/>' .
			'<area shape="rect" coords="13, 247, 66, 278" href="' . sprintf($urlpattern, 'dixon') . '" alt="Dixon"/>' .
			'<area shape="rect" coords="111, 246, 168, 277" href="' . sprintf($urlpattern, 'allen') . '" alt="Allen"/>' .
			'<area shape="rect" coords="146, 217, 233, 248" href="' . sprintf($urlpattern, 'waterbury') . '" alt="Waterbury"/>' .
			'<area shape="rect" coords="94, 183, 201, 209" href="' . sprintf($urlpattern, 'martinsburg') . '" alt="Martinsburg"/>' .
			'<area shape="rect" coords="186, 147, 250, 173" href="' . sprintf($urlpattern, 'ponca') . '" alt="Ponca"/>' .
			'<area shape="rect" coords="93, 89, 184, 119" href="' . sprintf($urlpattern, 'newcastle') . '" alt="Newcastle"/>' .
			'<area shape="rect" coords="20, 61, 87, 92" href="' . sprintf($urlpattern, 'maskell') . '" alt="Maskell"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'DixonCounty';
	}	
	
	function imageMapImage() {
		return 'dixon.gif';
	}
	
}