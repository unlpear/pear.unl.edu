<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_pawnee extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_pawnee()
	{
		$this->_cities = array(
			'burchard' => 'Burchard',
			'dubois' => 'DuBois',
			'lewiston' => 'Lewiston',
			'pawneecity' => 'Pawnee City',
			'steinauer' => 'Steinauer',
			'tablerock' => 'Table Rock',
		);
	}

	function countyName()
	{
		return 'Pawnee';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="PawneeCounty" id="PawneeCounty">' .
			'<area shape="rect" coords="304, 164, 368, 200" href="' . sprintf($urlpattern, 'dubois') . '" alt="DuBois" />' .
			'<area shape="rect" coords="202, 100, 307, 139" href="' . sprintf($urlpattern, 'pawneecity') . '" alt="Pawnee City" />' .
			'<area shape="rect" coords="247, 48, 357, 84" href="' . sprintf($urlpattern, 'tablerock') . '" alt="Table Rock" />' .
			'<area shape="rect" coords="141, 23, 232, 58" href="' . sprintf($urlpattern, 'steinauer') . '" alt="Steinauer" />' .
			'<area shape="rect" coords="46, 84, 142, 125" href="' . sprintf($urlpattern, 'burchard') . '" alt="Burchard" />' .
			'<area shape="rect" coords="7, 6, 93, 48" href="' . sprintf($urlpattern, 'lewiston') . '" alt="Lewiston" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'PawneeCounty';
	}	
	
	function imageMapImage() {
		return 'pawnee.gif';
	}
	
}