<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_scottsbluff extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_scottsbluff()
	{
		$this->_cities = array(
			'henry' => 'Henry',
			'lyman' => 'Lyman',
			'mcgrew' => 'McGrew',
			'melbeta' => 'Melbeta',
			'minatare' => 'Minatara',
			'mitchell' => 'Mitchell',
			'morrill' => 'Morrill',
			'scottsbluff-gering' => 'Scottsbluff-Gering',
			'terrytown' => 'Terrytown',
		);
	}

	function countyName()
	{
		return 'Scotts Bluff';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="ScottsBluffCounty" id="ScottsBluffCounty">' .
			'<area shape="rect" coords="339, 149, 409, 185" href="' . sprintf($urlpattern, 'mcgrew') . '" alt="" />' .
			'<area shape="rect" coords="262, 135, 329, 161" href="' . sprintf($urlpattern, 'melbeta') . '" alt="" />' .
			'<area shape="rect" coords="323, 105, 412, 132" href="' . sprintf($urlpattern, 'minatare') . '" alt="" />' .
			'<area shape="rect" coords="184, 110, 251, 137" href="' . sprintf($urlpattern, 'scottsbluff-gering') . '" alt="" />' .
			'<area shape="rect" coords="224, 91, 307, 110" href="' . sprintf($urlpattern, 'terrytown') . '" alt="" />' .
			'<area shape="rect" coords="148, 63, 242, 91" href="' . sprintf($urlpattern, 'scottsbluff-gering') . '" alt="" />' .
			'<area shape="rect" coords="137, 28, 231, 53" href="' . sprintf($urlpattern, 'mitchell') . '" alt="" />' .
			'<area shape="rect" coords="1, 50, 56, 84" href="' . sprintf($urlpattern, 'lyman') . '" alt="" />' .
			'<area shape="rect" coords="48, 21, 114, 49" href="' . sprintf($urlpattern, 'morrill') . '" alt="" />' .
			'<area shape="rect" coords="0, 0, 50, 24" href="' . sprintf($urlpattern, 'henry') . '" alt="" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'ScottsBluffCounty';
	}	
	
	function imageMapImage() {
		return 'scottsbluff.gif';
	}
	
}