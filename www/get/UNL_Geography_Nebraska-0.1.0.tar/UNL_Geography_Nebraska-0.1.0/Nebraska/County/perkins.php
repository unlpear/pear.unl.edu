<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_perkins extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_perkins()
	{
		$this->_cities = array(
			'brandon' => 'Brandon',
			'elsie' => 'Elsie',
			'grainton' => 'Grainton',
			'grant' => 'Grant',
			'madrid' => 'Madrid',
			'venango' => 'Venango',
		);
	}

	function countyName()
	{
		return 'Perkins';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="PerkinsCounty" id="PerkinsCounty">' .
			'<area shape="rect" coords="309, 87, 393, 122" href="' . sprintf($urlpattern, 'grainton') . '" alt="Grainton" />' .
			'<area shape="rect" coords="295, 57, 353, 91" href="' . sprintf($urlpattern, 'elsie') . '" alt="Elsie" />' .
			'<area shape="rect" coords="211, 53, 283, 91" href="' . sprintf($urlpattern, 'madrid') . '" alt="Madrid" />' .
			'<area shape="rect" coords="128, 56, 191, 92" href="' . sprintf($urlpattern, 'grant') . '" alt="Grant" />' .
			'<area shape="rect" coords="32, 72, 118, 110" href="' . sprintf($urlpattern, 'brandon') . '" alt="Brandon" />' .
			'<area shape="rect" coords="3, 109, 95, 135" href="' . sprintf($urlpattern, 'venango') . '" alt="Venango" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'PerkinsCounty';
	}	
	
	function imageMapImage() {
		return 'perkins.gif';
	}
	
}