<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_harlan extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_harlan()
	{
		$this->_cities = array(
			'alma' => 'Alma',
			'huntley' => 'Huntley',
			'orleans' => 'Orleans',
			'ragan' => 'Ragan',
			'republicancity' => 'Republican City',
			'stamford' => 'Stamford',
		);
	}

	function countyName()
	{
		return 'Harlan';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="HarlanCounty" id="HarlanCounty">' .
			'<area shape="rect" coords="230, 197, 366, 232" href="' . sprintf($urlpattern, 'republicancity') . '" alt="Republican City"/>' .
			'<area shape="rect" coords="191, 177, 244, 211" href="' . sprintf($urlpattern, 'alma') . '" alt="Alma"/>' .
			'<area shape="rect" coords="104, 148, 183, 189" href="' . sprintf($urlpattern, 'orleans') . '" alt="Orleans"/>' .
			'<area shape="rect" coords="5, 151, 90, 193" href="' . sprintf($urlpattern, 'stamford') . '" alt="Stamford"/>' .
			'<area shape="rect" coords="239, 89, 325, 125" href="' . sprintf($urlpattern, 'huntley') . '" alt="Huntley"/>' .
			'<area shape="rect" coords="238, 10, 316, 45" href="' . sprintf($urlpattern, 'ragan') . '" alt="Ragan"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'HarlanCounty';
	}	
	
	function imageMapImage() {
		return 'harlan.gif';
	}
	
}