<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_kimball extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_kimball()
	{
		$this->_cities = array(
			'bushnell' => 'Bushnell',
			'dix' => 'Dix',
			'kimball' => 'Kimball',
		);
	}

	function countyName()
	{
		return 'Kimball';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="KimballCounty" id="KimballCounty">' .
			'<area shape="rect" coords="316, 89, 359, 126" href="' . sprintf($urlpattern, 'dix') . '" alt="Dix"/>' .
			'<area shape="rect" coords="201, 84, 272, 126" href="' . sprintf($urlpattern, 'kimball') . '" alt="Kimball"/>' .
			'<area shape="rect" coords="66, 88, 139, 121" href="' . sprintf($urlpattern, 'bushnell') . '" alt="Bushnell"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'KimballCounty';
	}	
	
	function imageMapImage() {
		return 'kimball.gif';
	}
	
}