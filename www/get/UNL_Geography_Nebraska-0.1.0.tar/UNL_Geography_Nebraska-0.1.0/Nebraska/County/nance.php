<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_nance extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_nance()
	{
		$this->_cities = array(
			'belgrade' => 'Belgrade',
			'fullerton' => 'Fullerton',
			'genoa' => 'Genoa',
		);
	}

	function countyName()
	{
		return 'Nance';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="NanceCounty" id="NanceCounty">' .
			'<area shape="rect" coords="230, 106, 329, 137" href="' . sprintf($urlpattern, 'fullerton') . '" alt="Fullerton" />' .
			'<area shape="rect" coords="364, 51, 437, 76" href="' . sprintf($urlpattern, 'genoa') . '" alt="Genoa" />' .
			'<area shape="rect" coords="167, 25, 255, 57" href="' . sprintf($urlpattern, 'belgrade') . '" alt="Belgrade" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'NanceCounty';
	}	
	
	function imageMapImage() {
		return 'nance.gif';
	}
	
}