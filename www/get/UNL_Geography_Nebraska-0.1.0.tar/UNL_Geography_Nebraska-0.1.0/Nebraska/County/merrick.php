<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_merrick extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_merrick()
	{
		$this->_cities = array(
			'archer' => 'Archer',
			'centralcity' => 'Central City',
			'chapman' => 'Chapman',
			'clarks' => 'Clarks',
			'palmer' => 'Palmer',
			'silvercreek' => 'Silver Creek',
		);
	}

	function countyName()
	{
		return 'Merrick';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="MerrickCounty" id="MerrickCounty">' .
			'<area shape="rect" coords="385, 23, 460, 63" href="' . sprintf($urlpattern, 'silvercreek') . '" alt="Silver Creek" />' .
			'<area shape="rect" coords="264, 100, 333, 129" href="' . sprintf($urlpattern, 'clarks') . '" alt="Clarks" />' .
			'<area shape="rect" coords="138, 165, 238, 201" href="' . sprintf($urlpattern, 'centralcity') . '" alt="Central City" />' .
			'<area shape="rect" coords="51, 228, 125, 259" href="' . sprintf($urlpattern, 'chapman') . '" alt="Chapman" />' .
			'<area shape="rect" coords="3, 93, 61, 131" href="' . sprintf($urlpattern, 'palmer') . '" alt="Palmer" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'MerrickCounty';
	}	
	
	function imageMapImage() {
		return 'merrick.gif';
	}
	
}