<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_morrill extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_morrill()
	{
		$this->_cities = array(
			'angora' => 'Angora',
			'bayard' => 'Bayard',
			'bridgeport' => 'Bridgeport',
			'broadwater' => 'Broadwater',
		);
	}

	function countyName()
	{
		return 'Morrill';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="MorrillCounty" id="MorrillCounty">' .
			'<area shape="rect" coords="215, 200, 314, 242" href="' . sprintf($urlpattern, 'broadwater') . '" alt="Broadwater" />' .
			'<area shape="rect" coords="93, 162, 186, 200" href="' . sprintf($urlpattern, 'bridgeport') . '" alt="Bridgeport" />' .
			'<area shape="rect" coords="4, 122, 63, 154" href="' . sprintf($urlpattern, 'bayard') . '" alt="Bayard" />' .
			'<area shape="rect" coords="89, 74, 149, 105" href="' . sprintf($urlpattern, 'angora') . '" alt="Angora" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'MorrillCounty';
	}	
	
	function imageMapImage() {
		return 'morrill.gif';
	}
	
}