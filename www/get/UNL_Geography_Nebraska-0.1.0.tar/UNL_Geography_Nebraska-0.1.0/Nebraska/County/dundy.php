<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_dundy extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_dundy()
	{
		$this->_cities = array(
			'benkelman' => 'Benkelman',
			'haigler' => 'Haigler',
			'max' => 'Max',
			'parks' => 'Parks',
		);
	}

	function countyName()
	{
		return 'Dundy';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="DundyCounty" id="DundyCounty">' .
			'<area shape="rect" coords="316, 94, 367, 136" href="' . sprintf($urlpattern, 'max') . '" alt="Max" />' .
			'<area shape="rect" coords="215, 129, 324, 170" href="' . sprintf($urlpattern, 'benkelman') . '" alt="Benkelman" />' .
			'<area shape="rect" coords="139, 137, 206, 176" href="' . sprintf($urlpattern, 'parks') . '" alt="Parks" />' .
			'<area shape="rect" coords="23, 149, 105, 186" href="' . sprintf($urlpattern, 'haigler') . '" alt="Haigler" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'DundyCounty';
	}	
	
	function imageMapImage() {
		return 'dundy.gif';
	}
	
}