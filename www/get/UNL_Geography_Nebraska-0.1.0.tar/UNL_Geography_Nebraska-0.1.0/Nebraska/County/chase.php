<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_chase extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_chase()
	{
		$this->_cities = array(
				'champion' => 'Champion',
				'enders' => 'Enders',
				'imperial' => 'Imperial',
				'lamar' => 'Lamar',
				'wauneta' => 'Wauneta',
			);
	}

	function countyName()
	{
		return 'Chase';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="ChaseCounty" id="ChaseCounty">' .
			'<area shape="rect" coords="314, 154, 398, 189" href="' . sprintf($urlpattern, 'wauneta') . '" alt="Wauneta"/>' .
			'<area shape="rect" coords="254, 118, 327, 150" href="' . sprintf($urlpattern, 'enders') . '" alt="Enders"/>' .
			'<area shape="rect" coords="190, 80, 270, 117" href="' . sprintf($urlpattern, 'imperial') . '" alt="Imperial"/>' .
			'<area shape="rect" coords="130, 118, 222, 157" href="' . sprintf($urlpattern, 'champion') . '" alt="Champion"/>' .
			'<area shape="rect" coords="12, 62, 77, 100" href="' . sprintf($urlpattern, 'lamar') . '" alt="Lamar"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'ChaseCounty';
	}	
	
	function imageMapImage() {
		return 'chase.gif';
	}
	
}