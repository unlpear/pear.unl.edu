<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_frontier extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_frontier()
	{
		$this->_cities = array(
			'curtis' => 'Curtis',
			'eustis' => 'Eustis',
			'maywood' => 'Maywood',
			'moorefield' => 'Moorefield',
			'stockville' => 'Stockville',
		);
	}

	function countyName()
	{
		return 'Frontier';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="FrontierCounty" id="FrontierCounty">' .
			'<area shape="rect" coords="371, 18, 443, 52" href="' . sprintf($urlpattern, 'eustis') . '" alt="Eustis"/>' .
			'<area shape="rect" coords="170, 89, 280, 124" href="' . sprintf($urlpattern, 'stockville') . '" alt="Stockville"/>' .
			'<area shape="rect" coords="157, 4, 266, 38" href="' . sprintf($urlpattern, 'moorefield') . '" alt="Moorefield"/>' .
			'<area shape="rect" coords="110, 32, 177, 65" href="' . sprintf($urlpattern, 'curtis') . '" alt="Curtis"/>' .
			'<area shape="rect" coords="42, 3, 134, 37" href="' . sprintf($urlpattern, 'maywood') . '" alt="Maywood"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'FrontierCounty';
	}	
	
	function imageMapImage() {
		return 'frontier.gif';
	}
	
}