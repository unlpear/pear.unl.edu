<?php
/**
 * This PEAR Auth container is intended for authentication against a
 * Lotus Notes LDAP directory.
 * 
 * This is the PEAR Auth LDAP container Modified by Brett Bieber:
 * changed PEAR_ERROR_DIE to PEAR_ERROR_RETURN for graceful exits on bind errors
 * 
 * @package Auth_Container_LotusNotes
 */


require_once 'Auth/Container/LDAP.php';

class Auth_Container_LotusNotes extends Auth_Container_LDAP
{
	/**
     * Connect to the LDAP server using the global options
     *
     * @access private
     * @return object  Returns a PEAR error object if an error occurs.
     */
    function _connect()
    {
        // connect
        if (isset($this->options['url']) && $this->options['url'] != '') {
            $this->_debug('Connecting with URL', __LINE__);
            $conn_params = array($this->options['url']);
        } else {
            $this->_debug('Connecting with host:port', __LINE__);
            $conn_params = array($this->options['host'], $this->options['port']);
        }

        if(($this->conn_id = @call_user_func_array('ldap_connect', $conn_params)) === false) {
            return PEAR::raiseError('Auth_Container_LDAP: Could not connect to server.', 41, PEAR_ERROR_DIE);
        }
        $this->_debug('Successfully connected to server', __LINE__);

        // try switchig to LDAPv3
        $ver = 0;
        if(@ldap_get_option($this->conn_id, LDAP_OPT_PROTOCOL_VERSION, $ver) && $ver >= 2) {
            $this->_debug('Switching to LDAPv3', __LINE__);
            @ldap_set_option($this->conn_id, LDAP_OPT_PROTOCOL_VERSION, 3);
        }

        // bind with credentials or anonymously
        if($this->options['binddn'] && $this->options['bindpw']) {
            $this->_debug('Binding with credentials', __LINE__);
            $bind_params = array($this->conn_id, $this->options['binddn'], $this->options['bindpw']);
        } else {
            $this->_debug('Binding anonymously', __LINE__);
            $bind_params = array($this->conn_id);
        }
        
        // bind for searching
        if ((@call_user_func_array('ldap_bind', $bind_params)) == false) {
            $this->_debug();
            $this->_disconnect();
            return PEAR::raiseError('Auth_Container_LDAP: Could not bind to LDAP server.', 41, PEAR_ERROR_RETURN);
        }
        $this->_debug('Binding was successful', __LINE__);
    }	
}

