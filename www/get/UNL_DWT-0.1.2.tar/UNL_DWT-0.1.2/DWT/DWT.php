<?php
/**
 * This package is intended to create PHP Class files (Objects) from Dreamweaver template (.dwt) files.
 * It allows designers to create a standalone Dreamweaver template for the website design, and developers
 * to use that design in php pages without interference.
 *
 * Similar to the way DB_DataObject works, the DWT package uses a Generator to scan a .dwt file for editable
 * regions and creates an appropriately named class for that .dwt file with member variables for each region.
 *
 * Once the objects have been generated, you can render a html page from the template.
 * 
 * $page = new UNL_DWT::factory('Template_style1');
 * $page->pagetitle = "Contact Information";
 * $page->maincontent = "Contact us by telephone at 111-222-3333.";
 * echo $page->toHtml();
 *
 * Parts of this package are modeled on (borrowed from) the PEAR package DB_DataObject.
 *
 * @author Brett Bieber
 * @created 01/18/2006
 */
 ini_set('include_path',ini_get('include_path').':/Library/WebServer/Documents/pear.unl.edu/:/Library/WebServer/pear.unl.edu/:/Library/WebServer/pear.unl.edu/UNL_DWT/DWT/');
/**
 * Obtain the PEAR class so it can be extended from
 */
 require_once 'PEAR.php';

/**
 * The code returned by many methods upon success
 */
 define('UNL_DWT_OK', 1);

/**
 * Unkown error
 */
 define('UNL_DWT_ERROR', -1);

/**
 * An identifier in the query refers to a non-existant object
 */
 define('UNL_DWT_ERROR_NOT_FOUND', -4);

class UNL_DWT
{
	var $__template;
	
	/**
     * Run-time configuration options
     *
     * @var array
     * @see UNL_DWT::setOption()
     */
    var $options = array(
        'debug' => 0,
    );
	
	function UNL_DWT()
	{
		$this->__constructor();
	}
	
	function __constructor()
	{
		
	}
	
	function toHtml()
	{
		$options = &PEAR::getStaticProperty('UNL_DWT','options');
		if (!isset($this->__template)) {
			return "";
		}
		/*
		More Options for this method:
			Extend this to automatically generate the .tpl files and cache.
			Check for a cached copy of the template file.
			Connect to a template server and get the latest template copy.
			
			Ex: $p = file_get_contents("http://pear.unl.edu/UNL/Templates/server.php?template=".$this->__template);
		*/
		$p = file_get_contents($options['tpl_location'].$this->__template);
		$regions = get_object_vars($this);
		return $this->replaceRegions($p,$regions);
	}
	
	/**
	* Replaces region tags within a template file wth their contents.
	* @param $p string Page with DW Region tags.
	* @param $regions array of vars with strings of content to replace.
	*/
	function replaceRegions($p,$regions)
	{
		UNL_DWT::debug('Replacing regions.','replaceRegions',5);
		foreach ($regions as $region=>$value) {
			/* Replace the region with the replacement text */
			if (strpos($p,"<!--"." TemplateBeginEditable name=\"{$region}\" -->")) {
				$p = str_replace(UNL_DWT_between("<!--"." TemplateBeginEditable name=\"{$region}\" -->","<!--"." TemplateEndEditable -->",$p),$value,$p);
				UNL_DWT::debug("$region is replaced with $value.",'replaceRegions',5);
			} elseif(strpos($p,"<!--"." InstanceBeginEditable name=\"{$region}\" -->")) {
				$p = str_replace(UNL_DWT_between("<!--"." InstanceBeginEditable name=\"{$region}\" -->","<!--"." InstanceEndEditable -->",$p),$value,$p);
				UNL_DWT::debug("$region is replaced with $value.",'replaceRegions',5);
			} else {
				UNL_DWT::debug("Could not find region $region!",'replaceRegions',3);
			}	
		}
		return $p;
	}
	
	
	/**
	* Create a new UNL_DWT object for the specified layout type
	*
	* @param string $type     the template type (eg "fixed")
	* @param array  $options  an associative array of option names and values
	*
	* @return object  a new UNL_DWT.  A UNL_DWT_Error object on failure.
	*
	* @see UNL_DWT_common::setOption()
	*/
	function &factory($type, $coptions = false) {
		$options = &PEAR::getStaticProperty('UNL_DWT','options');
		
		include_once $options['class_location']."{$type}.php";
		
		if (!is_array($coptions)) {
			$coptions = array();
		}
		
		$classname = $options['class_prefix'].$type;
		
		if (!class_exists($classname)) {
			$tmp = PEAR::raiseError(null, UNL_DWT_ERROR_NOT_FOUND, null, null,
			"Unable to include the {$options['class_location']}{$type}.php file.",
			'UNL_DWT_Error', true);
			return $tmp;
		}
		
		@$obj =& new $classname;
		
		foreach ($coptions as $option => $value) {
			$test = $obj->setOption($option, $value);
			if (UNL_DWT::isError($test)) {
				return $test;
			}
		}
		
		return $obj;
	}
	
	/**
	* Sets options.
	*
	*
	*/
	function setOption($option, $value)
    {
        if (isset($this->options[$option])) {
            $this->options[$option] = $value;
			return UNL_DWT_OK;
        }
		return PEAR::raiseError("unknown option $option");
    }
	
	/**
	* Determines if a variable is a UNL_DWT_Error object
	*
	* @param mixed $value  the variable to check
	*
	* @return bool  whether $value is UNL_DWT_Error object
	*/
	function isError($value)
	{
		return is_a($value, 'UNL_DWT_Error');
	}
	
	/* ----------------------- Debugger ------------------ */

    /**
     * Debugger. - use this in your extended classes to output debugging information.
     *
     * Uses UNL_DWT::debugLevel(x) to turn it on
     *
     * @param    string $message - message to output
     * @param    string $logtype - bold at start
     * @param    string $level   - output level
     * @access   public
     * @return   none
     */
    function debug($message, $logtype = 0, $level = 1)
    {
        if (empty($this->options['debug'])  || 
            (is_numeric($this->options['debug']) &&  $this->options['debug'] < $level)) {
            return;
        }
        // this is a bit flaky due to php's wonderfull class passing around crap..
        // but it's about as good as it gets..
        $class = (isset($this) && is_a($this,'UNL_DWT')) ? get_class($this) : 'UNL_DWT';
        
        if (!is_string($message)) {
            $message = print_r($message,true);
        }
        if (!is_numeric( $this->options['debug']) && is_callable( $this->options['debug'])) {
            return call_user_func($this->options['debug'], $class, $message, $logtype, $level);
        }
        
        if (!ini_get('html_errors')) {
            echo "$class   : $logtype       : $message\n";
            flush();
            return;
        }
        if (!is_string($message)) {
            $message = print_r($message,true);
        }
        $colorize = ($logtype == 'ERROR') ? '<font color="red">' : '<font>';
        echo "<code>{$colorize}<strong>$class: $logtype:</strong> ". nl2br(htmlspecialchars($message)) . "</font></code><br />\n";
        flush();
    }

	/**
     * sets and returns debug level
     * eg. UNL_DWT::debugLevel(4);
     *
     * @param   int     $v  level
     * @access  public
     * @return  none
     */
    function debugLevel($v = null)
    {
        if ($v !== null) {
            $r = isset($this->options['debug']) ? $this->options['debug'] : 0;
            $this->options['debug']  = $v;
            return $r;
        }
        return isset($this->options['debug']) ? $this->options['debug'] : 0;
    }
	
    // {{{ errorMessage()

    /**
     * Return a textual error message for a UNL_DWT error code
     *
     * @param integer $value  the UNL_DWT error code
     *
     * @return string  the error message or false if the error code was
     *                  not recognized
     */
    function errorMessage($value)
    {
        static $errorMessages;
        if (!isset($errorMessages)) {
            $errorMessages = array(
                UNL_DWT_ERROR                    => 'unknown error',
                UNL_DWT_ERROR_NOT_FOUND          => 'not found',
                UNL_DWT_OK                       => 'no error',
            );
        }

        if (UNL_DWT::isError($value)) {
            $value = $value->getCode();
        }

        return isset($errorMessages[$value]) ? $errorMessages[$value]
                     : $errorMessages[UNL_DWT_ERROR];
    }
	// }}}
}

/**
 * UNL_DWT_Error implements a class for reporting template error
 * messages
 * Modified from Stig Bakken <ssb@php.net>'s DB_Error class for http://pear.php.net/package/DB
 *
 */
 if (!class_exists('UNL_DWT_Error')) {
	 class UNL_DWT_Error extends PEAR_Error
	 {
		// {{{ constructor
	
		/**
		* DB_Error constructor
		*
		* @param mixed $code       UNL_DWT error code, or string with error message
		* @param int   $mode       what "error mode" to operate in
		* @param int   $level      what error level to use for $mode &
		*                           PEAR_ERROR_TRIGGER
		* @param mixed $debuginfo  additional debug info, such as the last query
		*
		* @see PEAR_Error
		*/
		function UNL_DWT_Error($code = UNL_DWT_ERROR, $mode = PEAR_ERROR_RETURN,
						$level = E_USER_NOTICE, $debuginfo = null)     {
			if (is_int($code)) {
				$this->PEAR_Error('UNL DWT Error: ' . UNL_DWT::errorMessage($code), $code,
				$mode, $level, $debuginfo);
			} else {
				$this->PEAR_Error("UNL DWT Error: $code", UNL_DWT_ERROR,
				$mode, $level, $debuginfo);
			}
		}
		// }}}
	 }
 }
 if (!function_exists("UNL_DWT_between")) {
function UNL_DWT_between($start,$end,$p) {
	if (!empty($start) && strpos($p,$start)!=false) {
		$p = substr($p,strpos($p,$start)+strlen($start));
	}
	if (strpos($p,$end)!=false) {
		$p = substr($p,0,strpos($p,$end));
	}
	return $p;
}
}