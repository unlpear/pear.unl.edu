<?php
/**
* @author Brett Bieber
* Created on Sep 27, 2005
*/
require_once 'UNL/Common/Building.php';
require_once 'HTML/QuickForm.php';
$bldgs = new UNL_Common_Building();
$form =& new HTML_QuickForm();
$form->addElement('select','buildings','Buildings',$bldgs->codes);
echo $form->toHtml();
?>
