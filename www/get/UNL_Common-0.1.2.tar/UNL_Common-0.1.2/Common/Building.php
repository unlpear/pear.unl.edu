<?php
/**
* @author Brett Bieber
* Created on Sep 27, 2005
*/
require 'UNL/Common/Building/City.php';
require 'UNL/Common/Building/East.php';
class UNL_Common_Building {
	var $codes = array();
	function UNL_Common_Building()
	{
		$east = new UNL_Common_Building_East();
		$city = new UNL_Common_Building_City();
		$this->codes = array_merge($east->codes,$city->codes);
		array_multisort($this->codes,SORT_ASC);
	}
	
	/**
	* Return all the codes
	*
	* @access  public
	* @return  array   all codes as associative array
	*/
	function getAllCodes()
	{
		return $this->codes;
	}
}

?>
