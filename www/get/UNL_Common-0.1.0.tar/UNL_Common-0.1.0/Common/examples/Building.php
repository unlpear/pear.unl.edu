<?php
/**
* @author Brett Bieber
* Created on Sep 27, 2005
*/
//ini_set('include_path', '/Users/bbieber/Documents/workspace' . PATH_SEPARATOR . ini_get('include_path'));
include('UNL/Common/Building.php');
include('HTML/QuickForm.php');
$bldgs = new UNL_Common_Building();

$form =& new HTML_QuickForm();
$bldg_el = HTML_QuickForm::createElement('select','buildings','Buildings',$bldgs->codes);
$form->addElement($bldg_el);
echo $form->toHtml();
?>
