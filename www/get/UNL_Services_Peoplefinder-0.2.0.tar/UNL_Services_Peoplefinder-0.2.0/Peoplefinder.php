<?php
/**
 * Package which connects to the peoplefinder services to get information about UNL people.
 *
 * 
 * @author Brett Bieber
 * @package UNL_Services_Peoplefinder
 */

class UNL_Services_Peoplefinder
{
    
    /**
     * returns the name for a given uid
     *
     * @param string $uid
     * @return string|false
     */
    function getFullName($uid)
    {
        if ($vcard = UNL_Services_Peoplefinder::getVCard($uid)) {
            $matches = array();
            preg_match_all('/FN:(.*)/',$vcard, $matches);
            if (isset($matches[1][0])) {
                return $matches[1][0];
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    
    /**
     * returns the email address for the given uid
     *
     * @param string $uid
     * @return string|false
     */
    function getEmail($uid)
    {
        if ($hcard = UNL_Services_Peoplefinder::getHCard($uid)) {
            $matches = array();
            preg_match_all('/mailto:([^\'\"]*)/',$hcard, $matches);
            if (isset($matches[1][0])) {
                return $matches[1][0];
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    
    /**
     * Gets an hcard for the uid given.
     *
     * @param string $uid
     * @return string|false
     */
    function getHCard($uid)
    {
        if ($hcard = file_get_contents('http://ucommxsrv1.unl.edu/peoplefinder/hcards/'.$uid)) {
            return $hcard;
        } else {
            return false;
        }
    }
    
    /**
     * Gets a vcard for the given uid.
     *
     * @param string $uid
     * @return string|false
     */
    function getVCard($uid)
    {
        if ($vcard = file_get_contents('http://ucommxsrv1.unl.edu/peoplefinder/vcards/'.$uid)) {
            return $vcard;
        } else {
            return false;
        }
    }
}

?>