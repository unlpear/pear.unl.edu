<?php
/**
 * no output !
 */