<?php
require_once 'UNL/Services/Peoplefinder.php';
$uid = 'bbieber2';
echo 'The email address for '.$uid.' is '.UNL_Services_Peoplefinder::getEmail($uid);

?>