<?php
/**
 * Package which connects to the peoplefinder services to get info.
 *
 * 
 * 
 * @package UNL_Services_Peoplefinder
 */

class UNL_Services_Peoplefinder
{
    
    /**
     * returns the name for a given uid
     *
     * @param string $uid
     */
    function getFullName($uid)
    {
        /**
         * @todo make it work!
         */
        return false;
    }
    
    /**
     * returns the email address for the given uid
     *
     * @param unknown_type $uid
     */
    function getEmail($uid)
    {
        if ($hcard = UNL_Services_Peoplefinder::getHCard($uid)) {
            $matches = array();
            preg_match_all('/mailto:([^\'\"]*)/',$hcard, $matches);
            if (isset($matches[1][0])) {
                return $matches[1][0];
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    
    function getHCard($uid)
    {
        if ($hcard = file_get_contents('http://ucommxsrv1.unl.edu/peoplefinder/hcards/'.$uid)) {
            return $hcard;
        } else {
            return false;
        }
    }
    
    function getVCard($uid)
    {
        if ($vcard = file_get_contents('http://ucommxsrv1.unl.edu/peoplefinder/vcards/'.$uid)) {
            return $vcard;
        } else {
            return false;
        }
    }
}

?>