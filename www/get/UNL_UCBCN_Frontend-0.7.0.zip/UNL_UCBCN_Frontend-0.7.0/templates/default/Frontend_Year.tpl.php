<h1 class="year_main"><?php echo $this->year; ?></h1>
<div class="year_cal">
<table>
<tr>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[0]); ?>
</td>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[1]); ?>
</td>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[2]); ?>
</td>
</tr>
<tr>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[3]); ?>
</td>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[4]); ?>
</td>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[5]); ?>
</td>
</tr>
<tr>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[6]); ?>
</td>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[7]); ?>
</td>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[8]); ?>
</td>
</tr>
<tr>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[9]); ?>
</td>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[10]); ?>
</td>
<td>
<?php UNL_UCBCN::displayRegion($this->monthwidgets[11]); ?>
</td>
</tr>
</table>
</div>