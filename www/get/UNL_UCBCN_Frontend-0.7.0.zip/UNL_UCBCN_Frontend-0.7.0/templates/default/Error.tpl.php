<h3>Error</h3>
<p><?php echo $this->message; ?></p>