<?php
/**
 * This package houses and returns spatial data for the UNL Campus.
 * 
 * Initially we only have latitude and longitude for a few buildings on campus.
 * 
 * 
 * @author Brett Bieber
 * @package UNL_Geography_SpatialData_Campus
 */
require 'UNL/Common/Building.php';

class UNL_Geography_SpatialData_Campus
{
	var $bldgs;
	
	function __construct()
	{
		$this->bldgs = new UNL_Common_Building();
	}
	
	function UNL_Geography_SpatialData_Campus()
	{
		return parent::__construct();
	}
	
	/**
	 * Returns the geographical coordinates for a building.
	 * 
	 * @param string $code Building Code for the building you want coordinates of.
	 * @return Associative array of coordinates lat and lon. false on error. 
	 */
	function getGeoCoordinates($code)
	{
		if (isset($this->bldgs->codes[$code])) {
			// Code is valid, find the geo coordinates.
			$link = mysql_connect('crusader.unl.edu', 'unl_common');
			if (!$link) {
				return false;
			} else {
				mysql_select_db('unl_common');
				$query = 'SELECT lat,lon FROM campus_spatialdata WHERE code = \''.$code.'\';';
				$result = mysql_query($query) or die('Query failed: ' . mysql_error());
				if (mysql_num_rows($result) == 1) {
					while ($coords = mysql_fetch_assoc($result)) {
						return array(	'lat'=>$coords['lat'],
										'lon'=>$coords['lon']);
					}
				} else {
					return false;
				}
				mysql_close($link);
			}
		} else {
			return false;
		}
	}
}

?>