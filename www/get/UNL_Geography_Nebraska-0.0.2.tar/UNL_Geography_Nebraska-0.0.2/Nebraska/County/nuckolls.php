<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_nuckolls extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_nuckolls()
	{
		$this->_cities = array(
			'hardy' => 'Hardy',
			'lawrence' => 'Lawrence',
			'nelson' => 'Nelson',
			'nora' => 'Nora',
			'oak' => 'Oak',
			'ruskin' => 'Ruskin',
			'superior' => 'Superior',
		);
	}

	function countyName()
	{
		return 'Nuckolls';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="NuckollsCounty" id="NuckollsCounty">' .
			'<area shape="rect" coords="261, 266, 331, 299" href="' . sprintf($urlpattern, 'hardy') . '" alt="Hardy" />' .
			'<area shape="rect" coords="131, 255, 219, 297" href="' . sprintf($urlpattern, 'superior') . '" alt="Superior" />' .
			'<area shape="rect" coords="318, 149, 384, 189" href="' . sprintf($urlpattern, 'ruskin') . '" alt="Ruskin" />' .
			'<area shape="rect" coords="224, 133, 292, 175" href="' . sprintf($urlpattern, 'nora') . '" alt="Nora" />' .
			'<area shape="rect" coords="292, 70, 348, 111" href="' . sprintf($urlpattern, 'oak') . '" alt="Oak" />' .
			'<area shape="rect" coords="142, 104, 217, 142" href="' . sprintf($urlpattern, 'nelson') . '" alt="Nelson" />' .
			'<area shape="rect" coords="5, 27, 96, 66" href="' . sprintf($urlpattern, 'lawrence') . '" alt="Lawrence" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'NuckollsCounty';
	}	
	
	function imageMapImage() {
		return 'nuckolls.gif';
	}
	
}