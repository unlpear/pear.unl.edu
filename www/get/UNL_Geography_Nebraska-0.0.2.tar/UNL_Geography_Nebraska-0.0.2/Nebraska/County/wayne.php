<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_wayne extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_wayne()
	{
		$this->_cities = array(
			'carroll' => 'Carroll',
			'hoskins' => 'Hoskins',
			'sholes' => 'Sholes',
			'wayne' => 'Wayne',
			'winside' => 'Winside',
		);
	}

	function countyName()
	{
		return 'Wayne';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="WayneCounty" id="WayneCounty">' .
			'<area shape="rect" coords="9, 160, 82, 194" href="' . sprintf($urlpattern, 'hoskins') . '" alt="Hoskins" />' .
			'<area shape="rect" coords="110, 112, 184, 141" href="' . sprintf($urlpattern, 'winside') . '" alt="Winside" />' .
			'<area shape="rect" coords="232, 68, 309, 98" href="' . sprintf($urlpattern, 'wayne') . '" alt="Wayne" />' .
			'<area shape="rect" coords="98, 40, 177, 69" href="' . sprintf($urlpattern, 'carroll') . '" alt="Carroll" />' .
			'<area shape="rect" coords="23, 9, 91, 40" href="' . sprintf($urlpattern, 'sholes') . '" alt="Sholes" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'WayneCounty';
	}	
	
	function imageMapImage() {
		return 'wayne.gif';
	}
	
}