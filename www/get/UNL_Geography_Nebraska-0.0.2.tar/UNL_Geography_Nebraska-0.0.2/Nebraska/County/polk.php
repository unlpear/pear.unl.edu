<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_polk extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_polk()
	{
		$this->_cities = array(
			'osceola' => 'Osceola',
			'polk' => 'Polk',
			'shelby' => 'Shelby',
			'stromsburg' => 'Stromsburg',
		);
	}

	function countyName()
	{
		return 'Polk';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="PolkCounty" id="PolkCounty">' .
			'<area shape="rect" coords="308, 145, 383, 182" href="' . sprintf($urlpattern, 'shelby') . '" alt="Shelby" />' .
			'<area shape="rect" coords="193, 156, 281, 192" href="' . sprintf($urlpattern, 'osceola') . '" alt="Osceola" />' .
			'<area shape="rect" coords="139, 212, 258, 246" href="' . sprintf($urlpattern, 'stromsburg') . '" alt="Stromsburg" />' .
			'<area shape="rect" coords="18, 248, 70, 281" href="' . sprintf($urlpattern, 'polk') . '" alt="Polk" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'PolkCounty';
	}	
	
	function imageMapImage() {
		return 'polk.gif';
	}
	
}