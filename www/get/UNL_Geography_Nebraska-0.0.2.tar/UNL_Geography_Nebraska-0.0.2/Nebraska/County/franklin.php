<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_franklin extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_franklin()
	{
		$this->_cities = array(
			'bloomington' => 'Bloomington',
			'campbell' => 'Campbell',
			'franklin' => 'Franklin',
			'hildreth' => 'Hildreth',
			'naponee' => 'Naponee',
			'riverton' => 'Riverton',
			'upland' => 'Upland',
		);
	}

	function countyName()
	{
		return 'Franklin';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="FranklinCounty" id="FranklinCounty">' .
			'<area shape="rect" coords="281, 187, 368, 220" href="' . sprintf($urlpattern, 'riverton') . '" alt="Riverton"/>' .
			'<area shape="rect" coords="170, 184, 254, 214" href="' . sprintf($urlpattern, 'franklin') . '" alt="Franklin"/>' .
			'<area shape="rect" coords="82, 200, 167, 234" href="' . sprintf($urlpattern, 'bloomington') . '" alt="Bloomington"/>' .
			'<area shape="rect" coords="4, 195, 79, 236" href="' . sprintf($urlpattern, 'naponee') . '" alt="Naponee"/>' .
			'<area shape="rect" coords="275, 28, 368, 58" href="' . sprintf($urlpattern, 'campbell') . '" alt="Campbell"/>' .
			'<area shape="rect" coords="184, 17, 257, 52" href="' . sprintf($urlpattern, 'upland') . '" alt="Upland"/>' .
			'<area shape="rect" coords="65, 1, 150, 41" href="' . sprintf($urlpattern, 'hildreth') . '" alt="Hildreth"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'FranklinCounty';
	}	
	
	function imageMapImage() {
		return 'franklin.gif';
	}
	
}