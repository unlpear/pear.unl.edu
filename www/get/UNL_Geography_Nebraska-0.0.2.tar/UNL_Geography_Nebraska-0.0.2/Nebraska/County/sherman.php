<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_sherman extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_sherman()
	{
		$this->_cities = array(
			'ashton' => 'Ashton',
			'hazard' => 'Hazard',
			'litchfield' => 'Litchfield',
			'loupcity' => 'Loup City',
			'rockville' => 'Rockville',
		);
	}

	function countyName()
	{
		return 'Sherman';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="ShermanCounty" id="ShermanCounty">' .
			'<area shape="rect" coords="5, 176, 76, 214" href="' . sprintf($urlpattern, 'litchfield') . '" alt="Litchfield" />' .
			'<area shape="rect" coords="73, 225, 133, 260" href="' . sprintf($urlpattern, 'hazard') . '" alt="Hazard" />' .
			'<area shape="rect" coords="252, 206, 330, 242" href="' . sprintf($urlpattern, 'rockville') . '" alt="Rockville" />' .
			'<area shape="rect" coords="285, 112, 345, 143" href="' . sprintf($urlpattern, 'ashton') . '" alt="Ashton" />' .
			'<area shape="rect" coords="143, 85, 222, 123" href="' . sprintf($urlpattern, 'loupcity') . '" alt="Loup City" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'ShermanCounty';
	}	
	
	function imageMapImage() {
		return 'sherman.gif';
	}
	
}