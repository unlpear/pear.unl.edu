<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_gage extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_gage()
	{
		$this->_cities = array(
			'adams' => 'Adams',
			'barneston' => 'Barneston',
			'beatrice' => 'Beatrice',
			'bluesprings' => 'Blue Springs',
			'clatonia' => 'Clatonia',
			'filley' => 'Filley',
			'liberty' => 'Liberty',
			'odell' => 'Odell',
			'pickrell' => 'Pickrell',
			'virginia' => 'Virginia',
			'wymore' => 'Wymore',
		);
	}

	function countyName()
	{
		return 'Gage';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="GageCounty" id="GageCounty">' .
			'<area shape="rect" coords="191, 311, 273, 345" href="' . sprintf($urlpattern, 'barneston') . '" alt="Barneston" />' .
			'<area shape="rect" coords="54, 303, 108, 334" href="' . sprintf($urlpattern, 'odell') . '" alt="Odell" />' .
			'<area shape="rect" coords="247, 279, 311, 310" href="' . sprintf($urlpattern, 'liberty') . '" alt="Liberty" />' .
			'<area shape="rect" coords="120, 267, 228, 296" href="' . sprintf($urlpattern, 'wymore') . '" alt="Wymore" />' .
			'<area shape="rect" coords="119, 237, 225, 265" href="' . sprintf($urlpattern, 'bluesprings') . '" alt="Blue Springs" />' .
			'<area shape="rect" coords="245, 180, 309, 214" href="' . sprintf($urlpattern, 'virginia') . '" alt="Virginia" />' .
			'<area shape="rect" coords="231, 141, 288, 172" href="' . sprintf($urlpattern, 'filley') . '" alt="Filley" />' .
			'<area shape="rect" coords="83, 155, 156, 190" href="' . sprintf($urlpattern, 'beatrice') . '" alt="Beatrice" />' .
			'<area shape="rect" coords="242, 35, 304, 71" href="' . sprintf($urlpattern, 'adams') . '" alt="Adams" />' .
			'<area shape="rect" coords="98, 82, 169, 111" href="' . sprintf($urlpattern, 'pickrell') . '" alt="Pickrell" />' .
			'<area shape="rect" coords="108, 9, 189, 40" href="' . sprintf($urlpattern, 'cortland') . '" alt="Cortland" />' .
			'<area shape="rect" coords="15, 24, 89, 55" href="' . sprintf($urlpattern, 'clatonia') . '" alt="Clatonia" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'GageCounty';
	}	
	
	function imageMapImage() {
		return 'gage.gif';
	}
	
}