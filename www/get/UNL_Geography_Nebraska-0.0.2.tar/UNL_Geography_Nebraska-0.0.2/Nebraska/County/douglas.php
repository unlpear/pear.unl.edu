<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_douglas extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_douglas()
	{
		$this->_cities = array(
			'bennington' => 'Bennington',
			'boystown' => 'Boys Town',
			'elkhorn' => 'Elkhorn',
			'omaha' => 'Omaha',
			'ralston' => 'Ralston',
			'valley' => 'Valley',
			'venice' => 'Venice',
			'waterloo' => 'Waterloo',
		);
	}

	function countyName()
	{
		return 'Douglas';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="DouglasCounty" id="DouglasCounty">' .
			'<area shape="rect" coords="67, 47, 138, 77" href="' . sprintf($urlpattern, 'valley') . '" alt="Valley" />' .
			'<area shape="rect" coords="99, 80, 189, 118" href="' . sprintf($urlpattern, 'waterloo') . '" alt="Waterloo" />' .
			'<area shape="rect" coords="325, 140, 406, 172" href="' . sprintf($urlpattern, 'ralston') . '" alt="Ralston" />' .
			'<area shape="rect" coords="278, 96, 384, 123" href="' . sprintf($urlpattern, 'boystown') . '" alt="Boys Town" />' .
			'<area shape="rect" coords="189, 80, 278, 106" href="' . sprintf($urlpattern, 'elkhorn') . '" alt="Elkhorn" />' .
			'<area shape="rect" coords="358, 64, 422, 96" href="' . sprintf($urlpattern, 'omaha') . '" alt="Omaha" />' .
			'<area shape="rect" coords="212, 1, 323, 38" href="' . sprintf($urlpattern, 'bennington') . '" alt="Bennington" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'DouglasCounty';
	}	
	
	function imageMapImage() {
		return 'douglas.gif';
	}
	
}