<?php
/**
 * This file parses the configuration and connection details for the artists and sculptures databases.
 * 
 * @package UNL_Common_Arists
 * @author bbieber
 */
require_once 'DB/DataObject.php';
$dbconfig = parse_ini_file('@DATA_DIR@/UNL_Common_Artists/dataobject.ini', true);
// To update DB_DataObject files: @PHP_BIN@ @PHP_DIR@/DB/DataObject/createTables.php @DATA_DIR@UNL_Common_Artists/dataobject.ini
// Load database settings
foreach( $dbconfig as $class => $values ) {
	$options = &PEAR::getStaticProperty($class, 'options');
	$options = $values;
}
?>