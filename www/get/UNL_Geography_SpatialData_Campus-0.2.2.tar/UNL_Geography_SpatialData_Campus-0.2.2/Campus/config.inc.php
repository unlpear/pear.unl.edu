<?php
// To update DB_DataObject files: /usr/local/php/bin/php /usr/local/php/lib/php/DB/DataObject/createTables.php Campus/dataobject.ini
require_once 'DB/DataObject.php';
$dbconfig = parse_ini_file('/Users/bbieber/Documents/workspace/UNL_Geography_SpatialData_Campus/Campus/dataobject.ini', true);

// Load database settings
foreach( $dbconfig as $class => $values ) {
	$options = &PEAR::getStaticProperty($class, 'options');
	$options = $values;
}