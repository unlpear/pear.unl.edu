<?php

/**
 * This class holds all the events for the list.
 * 
 */
class UNL_UCBCN_EventListing
{
	var $status;
	// Array of UNL_UCBCN_Event or UNL_UCBCN_EventInstance objects for this listing.
	var $events = array();
	
	function __construct()
	{
		
	}
}
