<?php
/**
 * Pearified version of Aaron Axelsen's iTunes U authentication class.
 * 
 * @package UNL_iTunesU
 * @author  Aaron Axelsen <axelsena@uww.edu>
 * @author  Brett Bieber <brett.bieber@gmail.com>
 *
 * ############################################## 
 * #
 * # iTunes Authentication Class
 * # URL: http://omega1.uww.edu/itunesu
 * # Version: 1.1 - 3/27/2007
 * #
 * # Written by Aaron Axelsen - axelsena@uww.edu
 * # University of Wisconsin - Whitewater
 * #
 * # Class based on the Apple provided ITunesU.pl 
 * # example script.
 * #
 * ##############################################
 * 
 */

/**
 * This class handles authentication with an iTunes U presence.
 * 
 * Instantiate with an associative array of the member variables then invokeAction()
 * 
 * <example>
 * $options = array('sharedSecret'=>'...','anonymousCredential'=>'...',...);
 * $u = new UNL_iTunesU($options);
 * $u->setUser('anonymous', 'anonymous', 'anonymous', '1234567');
 * $u->addAnonymousCredential();
 * $u->invokeAction();
 * exit();
 * </example>
 * 
 * 
 * @package UNL_iTunesU
 * @author  Aaron Axelsen <axelsena@uww.edu>
 * @author  Brett Bieber <brett.bieber@gmail.com>
 */
class UNL_iTunesU {

    /**
     * https://deimos.apple.com/WebObjects/Core.woa/Browse/example.edu
     *
     * @var string
     */
    public $siteURL;
    
    /**
     * https://www.example.edu/cgi-bin/itunesu
     * 
     * @var string
     */
    public $directSiteURL;
    
    /**
     * /abc1234
     * 
     * @var string
     */
    public $debugSuffix;
    
    /**
     * STRINGOFTHIRTYTWOLETTERSORDIGITS
     *
     * @var string
     */
    public $sharedSecret;
    
    /**
     * Administrator@urn:mace:itunesu.com:sites:example.edu
     *
     * @var string
     */
    public $administratorCredential;
    
    /**
     * Student@urn:mace:itunesu.com:sites:example.edu
     * 
     * @var string
     */
    public $studentCredential;
    
    /**
     * Instructor@urn:mace:itunesu.com:sites:example.edu
     *
     * @var string
     */
    public $instructorCredential;
    
    /**
     * Unauthenticated@urn:mace:itunesu.com:sites:example.edu
     *
     * @var string
     */
    public $anonymousCredential;
    
    /**
     * Array of credentials applied for the current user
     * 
     * @var array
     */
    public $credentials = array();
    
    /**
     * Create iTunes Object
     */
    public function __construct(array $options = array())
    {
          $this->setDebug(false);
          $this->setOptions($options);
          // Set domain
          $this->setDomain();
    }
    
    /**
     * This function sets parameters for this class.
     * 
     * @param array $options an associative array of options to set.
     */
    public function setOptions(array $options)
    {
        foreach ($options as $option=>$val) {
            if (property_exists($this, $option)) {
                $this->$option = $val;
            } else {
                echo 'Warning: Trying to set unkown option ['.$option.'] for object '.get_class($this)."\n";
            }
        }
    }

    /**
     * Add's admin credentials for a given user
     */
    public function addAdminCredentials()
    {
        $this->addCredentials($this->administratorCredential);
    }

    /**
     * Add Student Credential for a given course
     */
    public function addStudentCredential($unique)
    {
        $this->addCredentials($this->studentCredential.":$unique");
    }
    
    /**
     * Add anonymous credential for a unauthenticated access
     */
    public function addAnonymousCredential()
    {
        $this->addCredentials($this->anonymousCredential);
    }

    /**
     * Add Instructor Credential for a given course
     */
    public function addInstructorCredential($unique)
    {
        $this->addCredentials($this->instructorCredential.":$unique");
    }

    /**
     * Set User Information
     * 
     * @param string $name   Name of user 'John Doe'
     * @param string $email  User email address 'jdoe@example.edu'
     * @param string $netid  Net id, or unique id 'jdoe2'
     * @param string $userid User id 'jdoe2'
     */
    public function setUser($name, $email, $netid, $userid)
    {
        $this->name   = $name;
        $this->email  = $email;
        $this->netid  = $netid;
        $this->userid = $userid;
        return true;
    }

    /**
     * Set the Domain
     *
     * Takes the siteURL and splits off the destination, hostname and action path.    
     */
    private function setDomain()
    {
        $tmpArray = split("/",$this->siteURL);
        $this->siteDomain = $tmpArray[sizeof($tmpArray)-1];
        $this->actionPath = preg_replace("/https:\/\/(.+?)\/.*/",'$1',$this->siteURL); 
        $pattern = "/https:\/\/".$this->actionPath."(.*)/";
        $this->hostName = preg_replace($pattern,'$1',$this->siteURL);
        $this->destination = $this->siteDomain;
        return true;
    }

    /**
     * Set the Handle
     *
     * Takes the handle as input and forms the get upload url string
     * This is needed for using the API to upload files directly to iTunes U
     * 
     * @param string $handleIn
     */
    public function setHandle($handleIn) {
        $this->handle = $handleIn;
        $this->getUploadUrl = "http://deimos.apple.com/WebObjects/Core.woa/API/GetUploadURL/".$this->siteDomain.'.'.$this->handle;
        return true;
    }

    /**
     * Get Identity String
     *
     * Combine user identity information into an appropriately formatted string.
     * take the arguments passed into the function copy them to variables
     */
    private function getIdentityString() {
        # wrap the elements into the required delimiters.
        return sprintf('"%s" <%s> (%s) [%s]', $this->name, $this->email, $this->netid, $this->userid);
    }

    /**
     * Add Credentials to Array
     *    
     * Allows to push multiple credientials for a user onto the array
     */
    public function addCredentials($credentials)
    {
        array_push($this->credentials, $credentials);
        return true;
    }

    /**
     * Get Credentials String
     *
     * this is equivalent to join(';', @_); this function is present
     * for consistency with the Java example.
     * concatenates all the passed in credentials into a string
     * with a semicolon delimiting the credentials in the string.
     */
    private function getCredentialsString()
    {
        #make sure that at least one credential is passed in
        if (sizeof($this->credentials) < 1) {
            return false;
        }
        return implode(";", $this->credentials);
    }

    private function getAuthorizationToken()
    {
        # Create a buffer with which to generate the authorization token.
        $buffer = "";

            # create the POST Content and sign it
            $buffer .= "credentials=" . urlencode($this->getCredentialsString());
            $buffer .= "&identity=" . urlencode($this->identity);
            $buffer .= "&time=" . urlencode(mktime());

        # returns a signed message that is sent to the server
        if (function_exists('hash_hmac')) {
            $signature = hash_hmac('SHA256', $buffer, $this->sharedSecret);
        } else {
            require_once 'Message/Message.php';
            $hmac = Message::createHMAC('SHA256', $this->sharedSecret);
            $signature = $hmac->calc($buffer);
        }
        
        
        # append the signature to the POST content
        return sprintf("%s&signature=%s", $buffer, $signature);
    }

    /**
     * Invoke Action
     *
     * Send a request to iTunes U and record the response.
     * Net:HTTPS is used to get better control of the encoding of the POST data
     * as HTTP::Request::Common does not encode parentheses and Java's URLEncoder
     * does.
     */
    public function invokeAction()
    {
        $this->identity = $this->getIdentityString();
        $this->token = $this->getAuthorizationToken();
        
        if (function_exists('curl_init')) {
        
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->generateURL() . '?' . $this->token);
            curl_setopt($ch, CURLOPT_POST, 1);
    
            if (curl_exec($ch)) {
                        // Echo Javascript to clear contents of popup window
                        echo "<script type=\"text/javascript\">
                        <!--
                        document.getElementById('loading').innerHTML = '';
                        -->
                        </script>";
                curl_close($ch);
                return true;
            } else {
                curl_close($ch);
                return false;
            }
        } else {
        	require_once 'HTTP/Request.php';
            $req = &new HTTP_Request($this->generateURL());;
            $req->setMethod(HTTP_REQUEST_METHOD_POST);
            $req->addHeader("Content-Type","application/x-www-form-urlencoded");
            $req->addHeader("charset","UTF-8");
            $req->addRawPostData($this->token, true);
            
            $x = $req->sendRequest();
            
            if (PEAR::isError($x)) {
                echo $x->getMessage();
                // Return false if error
                return false;
            } else {
                echo $req->getResponseBody();
                // Echo Javascript to clear contents of popup window
                echo "<script type=\"text/javascript\">
                <!--
                document.getElementById('loading').innerHTML = '';
                -->
                </script>";
                // Return true if success
                return true;
            }
        }
    }

    /**
     * Auth and Upload File to iTunes U
     *
     * This method is said to not be as heavily tested by apple, so you may have 
     * unexpected results.
     *
     * @param string $fileIn - full system path to the file you desire to upload
     */
    public function uploadFile($fileIn)
    {
        $this->identity = $this->getIdentityString();
        $this->token = $this->getAuthorizationToken();

        // Escape the filename
        $f = escapeshellcmd($fileIn);

        // Contact Apple and Get the Upload URL
        $upUrl = curl_init($this->getUploadUrl.'?'.$this->token);
        curl_setopt($upUrl, CURLOPT_RETURNTRANSFER, true);
        $uploadURL = curl_exec($upUrl);

        $error = curl_error($upUrl);
        $http_code = curl_getinfo($upUrl ,CURLINFO_HTTP_CODE);

        curl_close($upUrl);

        print $http_code;
        print "<br /><br />$uploadURL";
        if ($error) {
           print "<br /><br />$error";
        }

        # Currently not working using php/curl functions.  For now, we are just going to echo a system command .. see below
        #// Push out the designated file to iTunes U
        #// Build Post Fields
        #$postfields = array("file" => "@$fileIn");

        #$pushUrl = curl_init($uploadURL);
        #curl_setopt($pushUrl, CURLOPT_FAILONERROR, 1);
        #curl_setopt($pushUrl, CURLOPT_FOLLOWLOCATION, 1);// allow redirects 
        #curl_setopt($pushUrl, CURLOPT_VERBOSE, 1);
        #curl_setopt($pushUrl, CURLOPT_RETURNTRANSFER, true);
        #curl_setopt($pushUrl, CURLOPT_POST, true);
        #curl_setopt($pushUrl, CURLOPT_POSTFILEDS, $postfields);
        #$output = curl_exec($pushUrl);
        #$error = curl_error($pushUrl);
        #$http_code = curl_getinfo($pushUrl, CURLINFO_HTTP_CODE);

        #curl_close($pushUrl);

        #print "<br/>";
        #print $http_code;
        #print "<br /><br />$output";
        #if ($error) {
        #   print "<br /><br />$error";
        #}

        // Set the php time limit higher so it doesnt time out.
        set_time_limit(1200);

        // System command to initiate curl and upload the file. (Temp until I figure out the php curl commands to do it)
        $command = "curl -S -F file=@$f $uploadURL";
    
        echo "<br/><br/>";
        echo $command;
        exec($command, $result, $error);
        if ($error) {
            echo "I'm busted";
        } else {
            print_r($result);
        }
        echo $command;
    }

    /**
     * Set Debugging
     *
     * Enable/Disable debugging of iTunes U Authentication
     */
    public function setDebug($bool)
    {
        if ($bool) {
            $this->debug = true;
        } else {
            $this->debug = false;
        }
        return true;
    }

    /**
     * Generate Site URL
     *
     * Append debug suffix to end of url if debugging is enabled
     */
    private function generateURL()
    {
        if ($this->debug) {
            return $this->siteURL.$this->debugSuffix;
        } elseif ($this->isHandleSet()) {
            return $this->directSiteURL.'.'.$this->handle;            
        } else {
            return $this->siteURL;
        }
    }

    /**
     * Check to see if the handle is set
     */
    private function isHandleSet()
    {
        if (isset($this->handle)) {
            return true;
        } else {
            return false;
        }
    }
}
?>
