<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<title>UNL_HTML_CSS_Sampler Example Usage</title>
<script type="text/javascript">
function showHide(e)
{
   document.getElementById(e).style.display=(document.getElementById(e).style.display=="block")?"none":"block";
   return false;
}
</script>
<style type="text/css">
	.stylewrap {padding:5px;}
	tr:hover {background-color:#F0F0F0;}
	th {font-size:1.4em;padding:0.2em;}
	td {border-bottom:1px solid #000;padding:0px;margin:0px;}
	.vsource {margin-top:5px;overflow:auto;}
	<?php echo file_get_contents('@doc_dir@/UNL_HTML_CSS_Sampler/examples/sample.css'); ?>
</style>
</head>

<body>
<?php

require_once 'UNL/HTML/CSS/Sampler.php';

// Set up the sampler object.
$css_sampler = new UNL_HTML_CSS_Sampler(	array('filename'=>'@doc_dir@/UNL_HTML_CSS_Sampler/examples/sample.css'),
											array('cellspacing="0"'));

// Run the css parser and build the example table
$css_sampler->run();

// Send the generated sampler to the browser.
echo $css_sampler->toHtml();

?>
</body>
</html>
