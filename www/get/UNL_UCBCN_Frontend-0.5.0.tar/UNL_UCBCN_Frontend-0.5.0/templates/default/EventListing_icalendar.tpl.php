<?php
/**
 * This is the output for an event listing in icalendar format.
 * @package UNL_UCBCN_Frontend
 */
UNL_UCBCN::displayRegion($this->events);
?>