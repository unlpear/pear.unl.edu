<?php
/**
 * The Generator is used to generate UNL_DWT classes and cached .tpl files from
 * Dreamweaver Template files.
 *
 * @author Brett Bieber
 * @created 2006-01-18
 */

require_once('UNL/DWT/DWT.php');

class UNL_DWT_Generator extends UNL_DWT {

	/**
	 * Array of template names.
	 */
	var $templates;
	
	/**
	 * Current template being output
	 */
	var $template;
	
	/**
	 * Assoc array of template region names.
	 * $_regions[$template] = array();
	 */
	var $_regions;
	
	/**
     * class being extended (can be overridden by [UNL_DWT_Generator] extends=xxxx
     *
     * @var    string
     * @access private
     */
    var $_extends = 'UNL_DWT';
	
	/**
     * line to use for require_once('UNL/DWT/DWT.php');
     *
     * @var    string
     * @access private
     */
    var $_extendsFile = 'UNL/DWT/DWT.php';
	
	function start()
	{
		$this->debugLevel(3);
		$this->createTemplateList();
		$this->generateTemplates();
		$this->generateClasses();
	}
	
	/**
	 * Generates .tpl files from .dwt
	 * 
	 */
	function generateTemplates()
	{
		$options = &PEAR::getStaticProperty('UNL_DWT','options');
		$dwt_location = $options['dwt_location'];
        if (!file_exists($options['dwt_location'])) {
            require_once 'System.php';
            System::mkdir(array('-p',$options['dwt_location']));
        }
		if (!file_exists($options['tpl_location'])) {
            require_once 'System.php';
            System::mkdir(array('-p',$options['tpl_location']));
        }
		foreach($this->templates as $this->template) {
			$dwt = file_get_contents($dwt_location.$this->template);
			$dwt = $this->scanRegions($dwt);
			$sanitizedName = $this->sanitizeTemplateName($this->template);
			//Write out the .tpl file?
			if (strpos($options['tpl_location'],'%s') !== false) {
				$outfilename   = sprintf($options['tpl_location'], $sanitizedName);
			} else {
				$outfilename = "{$options['tpl_location']}/{$sanitizedName}.tpl";
			}
			$this->debug("Writing {$sanitizedName} to {$outfilename}",'generateTemplates');
			$fh = fopen($outfilename, "w");
			fputs($fh,$dwt);
			fclose($fh);
		}
	}
	
	/**
	 * Create a list of dwts
	 */
	function createTemplateList()
	{
		$this->templates = array();
		$options = &PEAR::getStaticProperty('UNL_DWT','options');
		$dwt_location = $options['dwt_location'];
		if(is_dir($dwt_location)) {
			$handle = opendir($dwt_location);
			while (false !== ($file = readdir($handle))) {
				if (isset($options['generator_include_regex']) &&
				!preg_match($options['generator_include_regex'],$file)) {
					continue;
				} else if (isset($options['generator_exclude_regex']) &&
				preg_match($options['generator_exclude_regex'],$file)) {
					continue;
				}
				if (substr($file,strlen($file)-4) == '.dwt') {
					$this->debug("Adding {$file} to the list of templates.",'createTemplateList');
					$this->templates[] = $file;
				}
			}
		} else {
			$this->debug("dwt_location is incorrect\n",'createTemplateList',0);
		}
	}
	
	function generateClasses()
	{
		$options = &PEAR::getStaticProperty('UNL_DWT','options');
		
		if ($extends = @$options['extends']) {
            $this->_extends = $extends;
            $this->_extendsFile = $options['extends_location'];
        }
		
		foreach($this->templates as $this->template) {
			$this->classname = $this->generateClassName($this->template);
			if (strpos($options['class_location'],'%s') !== false) {
                $outfilename   = sprintf($options['class_location'], sanitizeTemplateName($this->template));
            } else {
                $outfilename = "{$options['class_location']}/".$this->sanitizeTemplateName($this->template).".php";
            }
            $oldcontents = '';
            if (file_exists($outfilename)) {
                // file_get_contents???
                $oldcontents = implode('',file($outfilename));
            }
			$out = $this->_generateClassTemplate($oldcontents);
            $this->debug("Writing {$this->classname} to {$outfilename}",'generateClasses');
			$fh = fopen($outfilename, "w");
            fputs($fh,$out);
            fclose($fh);
		}
	}
	
	/**
	 * Generates the class name from a filename.
	 * @param string $filename The filename of the template.
	 * @return string Sanitized filename prefixed with the class_prefix defined in the ini.
	 */
	function generateClassName($filename)
	{
		$options = &PEAR::getStaticProperty('UNL_DWT','options');
		if (!($class_prefix  = @$options['class_prefix'])) {
			$class_prefix = '';
		}
		return $class_prefix.$this->sanitizeTemplateName($filename);;
	}
	
	/**
	 * Cleans the template filename.
	 *
	 * @param string $filename Filename of the template
	 * @return string Sanitized template name
	 */
	function sanitizeTemplateName($filename)
	{
		return preg_replace('/[^A-Z0-9]/i','_',ucfirst(str_replace('.dwt','',$filename)));
	}
	
	/**
	 * Scans the .dwt for regions - all found are loaded into assoc array $this->_regions[$template].
	 *
	 * @param none
	 * @return string derived template file.
	 */
	function scanRegions($dwt)
	{

		$this->_regions[$this->template] = array();
		$dwt = str_replace("\r","\n",$dwt);
		$dwt = preg_replace("/(\<\!-- InstanceBeginEditable name=\"([A-Za-z0-9]*)\" -->)/i","\n\\0\n",$dwt);
		$dwt = preg_replace("/(\<\!-- TemplateBeginEditable name=\"([A-Za-z0-9]*)\" -->)/i","\n\\0\n",$dwt);
		$dwt = preg_replace("/\<\!-- InstanceEndEditable -->/","\n\\0\n",$dwt);
		$dwt = preg_replace("/\<\!-- TemplateEndEditable -->/","\n\\0\n",$dwt);
		$dwt = explode("\n",$dwt);
		$newRegion = false;
		$region = new UNL_DWT_Region();
		$this->debug("Checking {$this->template}",'scanRegions',0);
		foreach ($dwt as $key=>$fileregion) {
			$matches = array();
			if (preg_match("/\<\!-- InstanceBeginEditable name=\"([A-Za-z0-9]*)\" -->/i",$fileregion,$matches)
				|| preg_match("/\<\!-- TemplateBeginEditable name=\"([A-Za-z0-9]*)\" -->/i",$fileregion,$matches)) {
				if ($newRegion == true) {
					// Found a new nested region.
					// Remove the previous one.
					$dwt[$region->line] = str_replace(array("<!--"." InstanceBeginEditable name=\"{$region->name}\" -->"),'',$dwt[$region->line]);
				}
				$newRegion = true;
				$region = new UNL_DWT_Region();
				$region->name = $matches[1];
				$region->line = $key;
				$region->value = "";
			} elseif ((preg_match("/\<\!-- InstanceEndEditable -->/i",$fileregion,$matches) || preg_match("/\<\!-- TemplateEndEditable -->/",$fileregion,$matches))) {
				// Region is closing.
				if ($newRegion===true) {
					$region->value = trim($region->value);
					if ($region->value != "@@(\" \")@@") {
						$this->_regions[$this->template][] = $region;
					} else {
						// Editable Region tags must be removed within .tpl
						unset($dwt[$region->line],$dwt[$key]);
					}
					$newRegion = false;
				} else {
					// Remove the nested region closing tag.
					$dwt[$key] = str_replace("<!--"." InstanceEndEditable -->",'',$fileregion);
				}
			} else {
				if ($newRegion===true) {
					// Add the value of this region.
					$region->value .= trim($fileregion)." ";
				}
			}
		}
		$dwt = implode("\n",$dwt);
		$dwt = preg_replace("/<!--"." InstanceParam name=\"([\w]*)\" type=\"([\w]*)\" value=\"([\w]*)\" -->/",'',$dwt);
		$dwt = str_replace(	array(	"<!--"." TemplateBeginEditable ",
									"<!--"." TemplateEndEditable -->",
									"\n\n"),
							array(	"<!--"." InstanceBeginEditable ",
									"<!--"." InstanceEndEditable -->",
									"\n"),$dwt);
		if (preg_match("<!--"." InstanceBegin template=\"([\/\w\d\.]+)\" codeOutsideHTMLIsLocked=\"([\w]+)\" -->",$dwt)) {
			$dwt = preg_replace("/<!--"." InstanceBegin template=\"([\/\w\d\.]+)\" codeOutsideHTMLIsLocked=\"([\w]+)\" -->/","<!--"." InstanceBegin template=\"/Templates/{$this->template}\" codeOutsideHTMLIsLocked=\"\\2\" -->",$dwt);
		} else {
			$dwt = preg_replace("/<html[^>]*>/","\\0<!--"." InstanceBegin template=\"/Templates/{$this->template}\" codeOutsideHTMLIsLocked=\"false\" -->",$dwt);
		}
		$dwt = str_replace('@@(" ")@@','',$dwt);
		return $dwt;
	}
	
	/**
     * The template class geneation part - single file.
     *
     * @access  private
     * @return  updated .php file
     */
    function _generateClassTemplate($input = '')
    {
        // title = expand me!
        $foot = "";
        $head = "<?php\n/**\n * Template Definition for {$this->template}\n */\n";
        // requires
        $head .= "require_once '{$this->_extendsFile}';\n\n";
        // add dummy class header in...
        // class
        $head .= "class {$this->classname} extends {$this->_extends} \n{";

        $body =  "\n    ###START_AUTOCODE\n";
        $body .= "    /* the code below is auto generated do not remove the above tag */\n\n";
		// table
        $padding = (30 - strlen($this->template));
        if ($padding < 2) $padding =2;
        $p =  str_repeat(' ',$padding) ;

		$options = &PEAR::getStaticProperty('UNL_DWT ','options');
        
        
        $var = (substr(phpversion(),0,1) > 4) ? 'public' : 'var';
        //$body .= "    {$var} \$__template = '{$this->template}';  {$p}// template name\n";
		$body .= "    {$var} \$__template = '".$this->sanitizeTemplateName($this->template).".tpl';  {$p}// template name\n";
		
		$regions = $this->_regions[$this->template];
		
		foreach($regions as $t) {
			if (!strlen(trim($t->name))) {
				continue;
			}
			$padding = (30 - strlen($t->name));
			if ($padding < 2) $padding =2;
			$p =  str_repeat(' ',$padding) ;
			
			$body .="    {$var} \${$t->name} = \"".addslashes($t->value)."\"; {$p}// {$t->type}({$t->len})  {$t->flags}\n";
        }
		
		// simple creation tools ! (static stuff!)
        $body .= "\n";
        $body .= "    /* Static get */\n";
        $body .= "    function staticGet(\$k,\$v=NULL) { return UNL_DWT::staticGet('{$this->classname}',\$k,\$v); }\n";
        
        // generate getter and setter methods
        $body .= $this->_generateGetters($input);
        $body .= $this->_generateSetters($input);
		
		$body .= "\n    /* the code above is auto generated do not remove the tag below */";
        $body .= "\n    ###END_AUTOCODE\n";
		
		$foot .= "}\n";
		$full = $head . $body . $foot;
		
		if (!$input) {
            return $full;
        }
        if (!preg_match('/(\n|\r\n)\s*###START_AUTOCODE(\n|\r\n)/s',$input))  {
            return $full;
        }
        if (!preg_match('/(\n|\r\n)\s*###END_AUTOCODE(\n|\r\n)/s',$input)) {
            return $full;
        }
		
		$class_rewrite = 'UNL_DWT';
        if (!($class_rewrite = @$options['generator_class_rewrite'])) {
            $class_rewrite = 'UNL_DWT';
        }
        if ($class_rewrite == 'ANY') {
            $class_rewrite = '[a-z_]+';
        }
		$input = preg_replace(
            '/(\n|\r\n)class\s*[a-z0-9_]+\s*extends\s*' .$class_rewrite . '\s*\{(\n|\r\n)/si',
            "\nclass {$this->classname} extends {$this->_extends} \n{\n",
            $input);
		
        return preg_replace(
            '/(\n|\r\n)\s*###START_AUTOCODE(\n|\r\n).*(\n|\r\n)\s*###END_AUTOCODE(\n|\r\n)/s',
            $body,$input);
		
	}
	
	/**
    * Generate getter methods for class definition
    *
    * @param    string  $input  Existing class contents
    * @return   string
    * @access   public
    */
    function _generateGetters($input) {

        $options = &PEAR::getStaticProperty('UNL_DWT','options');
        $getters = '';

        // only generate if option is set to true
        if  (empty($options['generate_getters'])) {
            return '';
        }

        // remove auto-generated code from input to be able to check if the method exists outside of the auto-code
        $input = preg_replace('/(\n|\r\n)\s*###START_AUTOCODE(\n|\r\n).*(\n|\r\n)\s*###END_AUTOCODE(\n|\r\n)/s', '', $input);

        $getters .= "\n\n";
        $regions     = $this->_regions[$this->table];

        // loop through properties and create getter methods
        foreach ($regions = $regions as $t) {

            // build mehtod name
            $methodName = 'get' . ucfirst($t->name);

            if (!strlen(trim($t->name)) || preg_match("/function[\s]+[&]?$methodName\(/i", $input)) {
                continue;
            }

            $getters .= "   /**\n";
            $getters .= "    * Getter for \${$t->name}\n";
            $getters .= "    *\n";
            $getters .= (stristr($t->flags, 'multiple_key')) ? "    * @return   object\n"
                                                             : "    * @return   {$t->type}\n";
            $getters .= "    * @access   public\n";
            $getters .= "    */\n";
            $getters .= (substr(phpversion(),0,1) > 4) ? '    public '
                                                       : '    ';
            $getters .= "function $methodName() {\n";
            $getters .= "        return \$this->{$t->name};\n";
            $getters .= "    }\n\n";
        }
   
        return $getters;
    }


   /**
    * Generate setter methods for class definition
    *
    * @param    string  Existing class contents
    * @return   string
    * @access   public
    */
    function _generateSetters($input) {

        $options = &PEAR::getStaticProperty('UNL_DWT','options');
        $setters = '';

        // only generate if option is set to true
        if  (empty($options['generate_setters'])) {
            return '';
        }

        // remove auto-generated code from input to be able to check if the method exists outside of the auto-code
        $input = preg_replace('/(\n|\r\n)\s*###START_AUTOCODE(\n|\r\n).*(\n|\r\n)\s*###END_AUTOCODE(\n|\r\n)/s', '', $input);

        $setters .= "\n";
        $regions     = $this->_regions[$this->table];

        // loop through properties and create setter methods
        foreach ($regions = $regions as $t) {

            // build mehtod name
            $methodName = 'set' . ucfirst($t->name);

            if (!strlen(trim($t->name)) || preg_match("/function[\s]+[&]?$methodName\(/i", $input)) {
                continue;
            }

            $setters .= "   /**\n";
            $setters .= "    * Setter for \${$t->name}\n";
            $setters .= "    *\n";
            $setters .= "    * @param    mixed   input value\n";
            $setters .= "    * @access   public\n";
            $setters .= "    */\n";
            $setters .= (substr(phpversion(),0,1) > 4) ? '    public '
                                                       : '    ';
            $setters .= "function $methodName(\$value) {\n";
            $setters .= "        \$this->{$t->name} = \$value;\n";
            $setters .= "    }\n\n";
        }
        
        return $setters;
    } 

}

class UNL_DWT_Region
{
	var $name;
	var $type = 'string';
	var $len;
	var $line;
	var $flags;
	var $value;
}
