<?php
/**
 * This package generates a table of css samples of all css selectors in a css file.
 * 
 * @created        2006-04-20
 * @author        Brett Bieber <brett.bieber@gmail.com>
 * @package        UNL_HTML_CSS_Sampler
 * @todo         * Parse all selectors using HTML_CSS built in functions.
 *                 * Sort selectors more accurately.
 *                 * Allow regular expressions for omitted selectors.
 *                 * Allow a custom sample generator function for selectors.
 */

require_once 'HTML/CSS.php';
require_once 'HTML/Table.php';

/**
 * Main class for the CSS sampler class.
 *
 * @package UNL_HTML_CSS_Sampler
 */
class UNL_HTML_CSS_Sampler
{
    /**
     * HTML_CSS object
     *
     * @var object HTML_CSS
     */
    var $css;
    
    /**
     * HTML_Table object of output
     *
     * @var object HTML_Table
     */
    var $table;
    
    /**
     * HTML_CSS::toArray()
     *
     * @var array Associative array of the parsed css.
     */
    var $css_array;
    
    /**
     * Options passed to the constructor for HTML_CSS
     *
     * @var array
     */
    var $css_options;
    
    /**
     * Options passed to the constructor for HTML_Table
     *
     * @var array
     */
    var $table_options;
    
    /**
     * Selectors you do not wish to output samples for.
     *
     * @var array
     */
    var $omit_selectors = array();
    
    /**
     * Should the selectors be sorted?
     *
     * @var bool
     */
    var $sort = true;
    
    /**
     * Text used as the sample for each selector.
     *
     * @var string
     */
    var $sampletext = 'The quick brown fox jumped over the lazy dog\'s back.';
    
    /**
     * An array of custom sample text for specific selectors.
     * 
     * @var unknown_type
     */
    var $custom_samples = array();
    
    /**
     * Constructor
     *
     * @param array $css_options
     * @param array $table_options
     */
    function __construct($css_options,$table_options)
    {
        $this->css_options = $css_options;
        $this->table_options = $table_options;
    }
    
    /**
     * PHP 4-type constructor.
     *
     * @param array $css_options
     * @param array $table_options
     * @return unknown
     */
    function Sampler($css_options=array('filename'=>''),$table_options=array('cellspacing="0"'))
    {
        return parent::__construct($css_options,$table_options);
    }
    
    function run()
    {
        $this->parseCSS();
        $this->cleanSelectors();
        if ($this->sort == true) {
            $this->sortSelectors();
        }
        $this->buildSampleTable();
    }
    
    /**
     * Initializes the HTML_CSS object which parses the css.
     *
     */
    function parseCSS()
    {
        $this->css = new HTML_CSS($this->css_options);
        $this->css_array = $this->css->toArray();
    }
    
    /**
     * Sorts the selectors used for output.
     *
     */
    function sortSelectors()
    {
        asort($this->css_array);
    }
    
    /**
     * cleans the selectors before output.
     *
     */
    function cleanSelectors()
    {
        foreach ($this->css_array as $selector=>$attributes) {
            if (trim($selector) != $selector) {
                unset($this->css_array[$selector]);
                $this->css_array[trim($selector)] = $attributes;
            }
        }
    }
    
    /**
     * Takes selectors parsed from HTML_CSS and builds an HTML table with sample
     * output for each selector.
     *
     */
    function buildSampleTable()
    {
        $this->table = new HTML_Table($this->table_options);
        $this->table->addRow(array('Selector Name','Usage','Sample'),NULL,'TH');
        foreach ($this->css_array as $selectors=>$attributes) {
            // Remove whitespace
            //$selectors = str_replace(' ','',$selectors);
            // Get array of all the selectors
            $selectors = explode(',',$selectors);
            foreach($selectors as $selector) {
                $this->buildSampleTableRow($selector);
            }
        }
    }
    
    /**
     * Builds and adds a HTML_Table row containing the sample for this selector.
     *
     * @param unknown_type $selector
     */
    function buildSampleTableRow($selector)
    {

        if (!in_array(trim($selector),$this->omit_selectors)) {
            $sample = $this->generateSample($selector);
            if ($sample !== false) {
                $this->table->addrow(array($selector,'',"<div class='stylewrap'>$sample</div>"));
            }
            $this->omit_selectors[] = $selector;
        }
    }
    
    /**
     * This is the default sample generator function.
     * 
     * @param string The selector to generate a sample for.
     */
    function generateSample($selector)
    {
        $fixed_selector = preg_replace('/\W/', '', $selector);
        $class = $this->selectorToClass($selector);
        if ($class !== false) {
            $selector = trim($selector);
            $sample_text = $this->getSampleText($selector);
            if (substr_count($selector,'.')==0) {
                if (substr_count($selector, 'img')){
                    $example = "<$selector src=\"#\" alt=\"$sample_text\" />\n";
                } else{
                    $example = "<$selector>$sample_text</$selector>\n";
                    $example .= "<$selector>\n\t<a href='{$_SERVER['PHP_SELF']}'>visited link</a>,\n\t<a href=\"#\">unvisited link</a>\n</$selector>\n";
                }
            } else {
                $example =  "<div class='$class'>$sample_text</div>\n";
                $example .= "<a class='$class' href='{$_SERVER['PHP_SELF']}'>visited link</a>,\n\t<a class='$class' href=\"#\">unvisited link</a>";
            }
            $example .= "<div class='vsource'><a href='#' onclick='return showHide(\"$fixed_selector\")'>View source+</a><div style='display:none;' id='$fixed_selector'><pre>".htmlentities($example)."</pre></div></div>";
            return $example;
        } else {
            return false;
        }
    }
    
    function getSampleText($selector)
    {
        if (isset($this->custom_samples[$selector])) {
            return $this->custom_samples[$selector];
        }
        return $this->sampletext;
    }
    
    /**
     * Converts a HTML_CSS parsed selector into the class if applicable.
     *
     * @param string $selector
     * @return selector converted to a css class.
     */
    function selectorToClass($selector)
    {
        if (!empty($selector) && strpos($selector,':')===false && strpos($selector,'#')===false) {

            return trim(substr($selector,strpos($selector,'.')+1),'\']');
        } else {
            return false;
        }
    }
    
    /**
     * Returns the html table of generated samples.
     *
     * @return string HTML table
     */
    function toHtml()
    {
        return $this->table->toHtml();
    }
    
}
?>