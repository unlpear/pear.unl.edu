<?php
/**
 * This PEAR Auth container is intended for authentication against a
 * Lotus Notes LDAP directory.
 * 
 * This is the PEAR Auth LDAP container Modified by Brett Bieber:
 * changed PEAR_ERROR_DIE to PEAR_ERROR_RETURN for graceful exits on bind errors
 * 
 * @package Auth_Container_LotusNotes
 */


require_once 'Auth/Container/LDAP.php';

/**
 * Auth container for use with a Lotus Notes LDAP directory.
 * 
 * @package Auth_Container_LotusNotes
 *
 */
class Auth_Container_LotusNotes extends Auth_Container_LDAP
{
	/**
     * Connect to the LDAP server using the global options
     *
     * @access private
     * @return object  Returns a PEAR error object if an error occurs.
     */
    function _connect()
    {
        // connect
        if (isset($this->options['url']) && $this->options['url'] != '') {
            $this->log('Connecting with URL', AUTH_LOG_DEBUG);
            $conn_params = array($this->options['url']);
        } else {
            $this->log('Connecting with host:port', AUTH_LOG_DEBUG);
            $conn_params = array($this->options['host'], $this->options['port']);
        }

        if(($this->conn_id = @call_user_func_array('ldap_connect', $conn_params)) === false) {
            return PEAR::raiseError('Auth_Container_LDAP: Could not connect to server.', 41, PEAR_ERROR_DIE);
        }
        $this->log('Successfully connected to server', AUTH_LOG_DEBUG);

        // try switchig to LDAPv3
        $ver = 0;
        if(@ldap_get_option($this->conn_id, LDAP_OPT_PROTOCOL_VERSION, $ver) && $ver >= 2) {
            $this->log('Switching to LDAPv3', AUTH_LOG_DEBUG);
            @ldap_set_option($this->conn_id, LDAP_OPT_PROTOCOL_VERSION, 3);
        }

        // bind with credentials or anonymously
        if($this->options['binddn'] && $this->options['bindpw']) {
            $this->log('Binding with credentials', AUTH_LOG_DEBUG);
            $bind_params = array($this->conn_id, $this->options['binddn'], $this->options['bindpw']);
        } else {
            $this->log('Binding anonymously', AUTH_LOG_DEBUG);
            $bind_params = array($this->conn_id);
        }
        
        // bind for searching
        if ((@call_user_func_array('ldap_bind', $bind_params)) == false) {
            $this->log('Could not bind to LDAP server.', AUTH_LOG_DEBUG);
            $this->_disconnect();
            return PEAR::raiseError('Auth_Container_LDAP: Could not bind to LDAP server.', 41, PEAR_ERROR_RETURN);
        }
        $this->log('Binding was successful', AUTH_LOG_DEBUG);
    }	
}

