<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_york extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_york()
	{
		$this->_cities = array(
			'benedict' => 'Benedict',
			'bradshaw' => 'Bradshaw',
			'gresham' => 'Gresham',
			'henderson' => 'Henderson',
			'lushton' => 'Lushton',
			'mccooljunction' => 'McCool Junction',
			'thayer' => 'Thayer',
			'waco' => 'Waco',
			'york' => 'York',
		);
	}

	function countyName()
	{
		return 'York';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="YorkCounty" id="YorkCounty">' .
			'<area shape="rect" coords="130, 235, 282, 268" href="' . sprintf($urlpattern, 'mccooljunction') . '" alt="McCool Junction" />' .
			'<area shape="rect" coords="49, 254, 128, 288" href="' . sprintf($urlpattern, 'lushton') . '" alt="Lushton" />' .
			'<area shape="rect" coords="7, 206, 107, 241" href="' . sprintf($urlpattern, 'henderson') . '" alt="Henderson" />' .
			'<area shape="rect" coords="19, 118, 118, 151" href="' . sprintf($urlpattern, 'bradshaw') . '" alt="Bradshaw" />' .
			'<area shape="rect" coords="278, 103, 342, 145" href="' . sprintf($urlpattern, 'waco') . '" alt="Waco" />' .
			'<area shape="rect" coords="176, 123, 232, 163" href="' . sprintf($urlpattern, 'york') . '" alt="York" />' .
			'<area shape="rect" coords="313, 11, 394, 46" href="' . sprintf($urlpattern, 'gresham') . '" alt="Gresham" />' .
			'<area shape="rect" coords="243, 47, 317, 78" href="' . sprintf($urlpattern, 'thayer') . '" alt="Thayer" />' .
			'<area shape="rect" coords="151, 14, 234, 48" href="' . sprintf($urlpattern, 'benedict') . '" alt="Benedict" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'YorkCounty';
	}	
	
	function imageMapImage() {
		return 'york.gif';
	}
	
}