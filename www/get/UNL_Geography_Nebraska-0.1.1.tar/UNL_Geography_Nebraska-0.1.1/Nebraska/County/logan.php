<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_logan extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_logan()
	{
		$this->_cities = array(
			'gandy' => 'Gandy',
			'stapleton' => 'Stapleton',
		);
	}

	function countyName()
	{
		return 'Logan';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="LoganCounty" id="LoganCounty">' .
			'<area shape="rect" coords="167, 176, 255, 211" href="' . sprintf($urlpattern, 'gandy') . '" alt="Gandy" />' .
			'<area shape="rect" coords="43, 169, 156, 206" href="' . sprintf($urlpattern, 'stapleton') . '" alt="Stapleton" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'LoganCounty';
	}	
	
	function imageMapImage() {
		return 'logan.gif';
	}
	
}