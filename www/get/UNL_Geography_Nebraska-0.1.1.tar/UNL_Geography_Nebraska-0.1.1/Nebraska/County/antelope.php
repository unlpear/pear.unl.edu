<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_antelope extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_antelope()
	{
		$this->_cities = array(
			'brunswick' => 'Brunswick',
			'clearwater' => 'Clearwater',
			'elgin' => 'Elgin',
			'neligh' => 'Neligh',
			'oakdale' => 'Oakdale',
			'orchard' => 'Orchard',
			'royal' => 'Royal',
			'tilden' => 'Tilden',
		);
			
	}

	function countyName()
	{
		return 'Antelope';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="AntelopeCounty" id="AntelopeCounty">' .
			'<area shape="rect" coords="254, 246, 312, 274" href="' . sprintf($urlpattern, 'tilden') . '" alt="Tilden"/>' .
			'<area shape="rect" coords="119, 273, 170, 305" href="' . sprintf($urlpattern, 'elgin') . '" alt="Elgin"/>' .
			'<area shape="rect" coords="182, 221, 255, 247" href="' . sprintf($urlpattern, 'oakdale') . '" alt="Oakdale"/>' .
			'<area shape="rect" coords="144, 184, 203, 210" href="' . sprintf($urlpattern, 'neligh') . '" alt="Neligh"/>' .
			'<area shape="rect" coords="28, 158, 119, 186" href="' . sprintf($urlpattern, 'clearwater') . '" alt="Clearwater"/>' .
			'<area shape="rect" coords="166, 46, 253, 77" href="' . sprintf($urlpattern, 'brunswick') . '" alt="Brunswick"/>' .
			'<area shape="rect" coords="91, 52, 145, 79" href="' . sprintf($urlpattern, 'royal') . '" alt="Royal"/>' .
			'<area shape="rect" coords="7, 47, 73, 79" href="' . sprintf($urlpattern, 'orchard') . '" alt="Orchard"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'AntelopeCounty';
	}	
	
	function imageMapImage() {
		return 'antelope.gif';
	}
	
}