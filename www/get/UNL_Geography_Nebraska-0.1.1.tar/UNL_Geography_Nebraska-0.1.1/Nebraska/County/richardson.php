<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_richardson extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_richardson()
	{
		$this->_cities = array(
			'barada' => 'Barada',
			'dawson' => 'Dawson',
			'fallscity' => 'Falls City',
			'humboldt' => 'Humboldt',
			'preston' => 'Preston',
			'rulo' => 'Rulo',
			'salem' => 'Salem',
			'shubert' => 'Shubert',
			'stella' => 'Stella',
			'verdon' => 'Verdon',
		);
	}

	function countyName()
	{
		return 'Richardson';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="RichardsonCounty" id="RichardsonCounty">' .
			'<area shape="rect" coords="453, 149, 513, 192" href="' . sprintf($urlpattern, 'rulo') . '" alt="Rulo" />' .
			'<area shape="rect" coords="376, 185, 460, 227" href="' . sprintf($urlpattern, 'preston') . '" alt="Preston" />' .
			'<area shape="rect" coords="300, 143, 397, 184" href="' . sprintf($urlpattern, 'fallscity') . '" alt="Falls City" />' .
			'<area shape="rect" coords="205, 130, 278, 174" href="' . sprintf($urlpattern, 'salem') . '" alt="Salem" />' .
			'<area shape="rect" coords="219, 73, 297, 115" href="' . sprintf($urlpattern, 'verdon') . '" alt="Verdon" />' .
			'<area shape="rect" coords="119, 88, 201, 129" href="' . sprintf($urlpattern, 'dawson') . '" alt="Dawson" />' .
			'<area shape="rect" coords="332, 13, 415, 53" href="' . sprintf($urlpattern, 'barada') . '" alt="Barada" />' .
			'<area shape="rect" coords="244, 2, 327, 40" href="' . sprintf($urlpattern, 'shubert') . '" alt="Shubert" />' .
			'<area shape="rect" coords="165, 2, 242, 39" href="' . sprintf($urlpattern, 'stella') . '" alt="Stella" />' .
			'<area shape="rect" coords="13, 55, 109, 100" href="' . sprintf($urlpattern, 'humboldt') . '" alt="Humboldt" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'RichardsonCounty';
	}	
	
	function imageMapImage() {
		return 'richardson.gif';
	}
	
}