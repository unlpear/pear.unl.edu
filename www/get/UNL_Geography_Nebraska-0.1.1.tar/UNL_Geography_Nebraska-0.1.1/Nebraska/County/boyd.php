<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_boyd extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_boyd()
	{
		$this->_cities = array(
				'anoka' => 'Anoka',
				'bristow' => 'Bristow',
				'butte' => 'Butte',
				'gross' => 'Gross',
				'lynch' => 'Lynch',
				'monowi' => 'Monowi',
				'naper' => 'Naper',
				'spencer' => 'Spencer',
			);
	}

	function countyName()
	{
		return 'Boyd';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="BoydCounty" id="BoydCounty">' .
			'<area shape="rect" coords="515, 78, 573, 113" href="' . sprintf($urlpattern, 'monowi') . '" alt="Monowi"/>' .
			'<area shape="rect" coords="449, 93, 501, 126" href="' . sprintf($urlpattern, 'lynch') . '" alt="Lynch"/>' .
			'<area shape="rect" coords="375, 92, 439, 120" href="' . sprintf($urlpattern, 'bristow') . '" alt="Bristow"/>' .
			'<area shape="rect" coords="400, 22, 464, 49" href="' . sprintf($urlpattern, 'gross') . '" alt="Gross"/>' .
			'<area shape="rect" coords="304, 70, 362, 101" href="' . sprintf($urlpattern, 'spencer') . '" alt="Spencer"/>' .
			'<area shape="rect" coords="236, 46, 294, 75" href="' . sprintf($urlpattern, 'butte') . '" alt="Butte"/>' .
			'<area shape="rect" coords="233, 12, 286, 44" href="' . sprintf($urlpattern, 'anoka') . '" alt="Anoka"/>' .
			'<area shape="rect" coords="87, 13, 144, 40" href="' . sprintf($urlpattern, 'naper') . '" alt="Naper"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'BoydCounty';
	}	
	
	function imageMapImage() {
		return 'boyd.gif';
	}
	
}