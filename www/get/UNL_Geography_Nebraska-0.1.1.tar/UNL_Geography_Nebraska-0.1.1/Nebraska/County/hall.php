<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_hall extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_hall()
	{
		$this->_cities = array(
			'alda' => 'Alda',
			'cairo' => 'Cairo',
			'doniphan' => 'Doniphan',
			'grandisland' => 'Grand Island',
			'woodriver' => 'Wood River',
		);
	}

	function countyName()
	{
		return 'Hall';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="HallCounty" id="HallCounty">' .
			'<area shape="rect" coords="248, 203, 343, 243" href="' . sprintf($urlpattern, 'doniphan') . '" alt="Doniphan"/>' .
			'<area shape="rect" coords="244, 74, 366, 115" href="' . sprintf($urlpattern, 'grandisland') . '" alt="Grand Island"/>' .
			'<area shape="rect" coords="177, 124, 239, 163" href="' . sprintf($urlpattern, 'alda') . '" alt="Alda"/>' .
			'<area shape="rect" coords="43, 164, 158, 203" href="' . sprintf($urlpattern, 'woodriver') . '" alt="Wood River"/>' .
			'<area shape="rect" coords="64, 17, 132, 49" href="' . sprintf($urlpattern, 'cairo') . '" alt="Cairo"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'HallCounty';
	}	
	
	function imageMapImage() {
		return 'hall.gif';
	}
	
}