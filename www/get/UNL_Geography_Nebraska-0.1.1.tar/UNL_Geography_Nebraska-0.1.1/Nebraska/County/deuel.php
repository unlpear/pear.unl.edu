<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_deuel extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_deuel()
	{
		$this->_cities = array(
				'bigsprings' => 'Big Springs',
				'chappell' => 'Chappell',
			);
	}

	function countyName()
	{
		return 'Deuel';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="DeuelCounty" id="DeuelCounty">' .
			'<area shape="rect" coords="226, 75, 322, 107" href="' . sprintf($urlpattern, 'bigsprings') . '" alt="Big Springs"/>' .
			'<area shape="rect" coords="53, 67, 128, 98" href="' . sprintf($urlpattern, 'chappell') . '" alt="Chappell"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'DeuelCounty';
	}	
	
	function imageMapImage() {
		return 'deuel.gif';
	}
	
}