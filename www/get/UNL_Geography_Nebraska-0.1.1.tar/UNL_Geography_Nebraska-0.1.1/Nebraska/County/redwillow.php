<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_redwillow extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_redwillow()
	{
		$this->_cities = array(
			'bartley' => 'Bartley',
			'danbury' => 'Danbury',
			'indianola' => 'Indianola',
			'lebanon' => 'Lebanon',
			'mccook' => 'McCook',
		);
	}

	function countyName()
	{
		return 'Red Willow';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="RedWillowCounty" id="RedWillowCounty">' .
			'<area shape="rect" coords="296, 200, 382, 236" href="' . sprintf($urlpattern, 'lebanon') . '" alt="Lebanon" />' .
			'<area shape="rect" coords="205, 210, 287, 242" href="' . sprintf($urlpattern, 'danbury') . '" alt="Danbury" />' .
			'<area shape="rect" coords="270, 63, 352, 98" href="' . sprintf($urlpattern, 'bartley') . '" alt="Bartley" />' .
			'<area shape="rect" coords="190, 73, 277, 106" href="' . sprintf($urlpattern, 'indianola') . '" alt="Indianola" />' .
			'<area shape="rect" coords="52, 90, 146, 128" href="' . sprintf($urlpattern, 'mccook') . '" alt="McCook" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'RedWillowCounty';
	}	
	
	function imageMapImage() {
		return 'redwillow.gif';
	}
	
}