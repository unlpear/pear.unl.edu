<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_dodge extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_dodge()
	{
		$this->_cities = array(
				'ames' => 'Ames',
				'dodge' => 'Dodge',
				'fremont' => 'Fremont',
				'hooper' => 'Hooper',
				'inglewood' => 'Inglewood',
				'nickerson' => 'Nickerson',
				'northbend' => 'North Bend',
				'scribner' => 'Scribner',
				'snyder' => 'Snyder',
				'uehling' => 'Uehling',
				'winslow' => 'Winslow',
			);
	}

	function countyName()
	{
		return 'Dodge';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="DodgeCounty" id="DodgeCounty">' .
			'<area shape="rect" coords="302, 248, 407, 273" href="' . sprintf($urlpattern, 'inglewood') . '" alt="Inglewood" />' .
			'<area shape="rect" coords="304, 216, 392, 243" href="' . sprintf($urlpattern, 'fremont') . '" alt="Fremont" />' .
			'<area shape="rect" coords="178, 207, 229, 235" href="' . sprintf($urlpattern, 'ames') . '" alt="Ames" />' .
			'<area shape="rect" coords="52, 196, 146, 229" href="' . sprintf($urlpattern, 'northbend') . '" alt="North Bend" />' .
			'<area shape="rect" coords="247, 150, 353, 182" href="' . sprintf($urlpattern, 'nickerson') . '" alt="Nickerson" />' .
			'<area shape="rect" coords="209, 92, 285, 123" href="' . sprintf($urlpattern, 'hooper') . '" alt="Hooper" />' .
			'<area shape="rect" coords="285, 83, 360, 113" href="' . sprintf($urlpattern, 'winslow') . '" alt="Winslow" />' .
			'<area shape="rect" coords="181, 51, 267, 77" href="' . sprintf($urlpattern, 'scribner') . '" alt="Scribner" />' .
			'<area shape="rect" coords="279, 9, 355, 37" href="' . sprintf($urlpattern, 'uehling') . '" alt="Uehling" />' .
			'<area shape="rect" coords="87, 23, 166, 52" href="' . sprintf($urlpattern, 'snyder') . '" alt="Snyder" />' .
			'<area shape="rect" coords="14, 8, 85, 39" href="' . sprintf($urlpattern, 'dodge') . '" alt="Dodge" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'DodgeCounty';
	}	
	
	function imageMapImage() {
		return 'dodge.gif';
	}
	
}