<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_mcpherson extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_mcpherson()
	{
		$this->_cities = array(
			'tryon' => 'Tryon',
		);
	}

	function countyName()
	{
		return 'McPherson';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="McPhersonCounty" id="McPhersonCounty">' .
			'<area shape="rect" coords="162, 80, 242, 116" href="' . sprintf($urlpattern, 'tryon') . '" alt="Tryon" />' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'McPhersonCounty';
	}	
	
	function imageMapImage() {
		return 'mcpherson.gif';
	}
	
}