<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_kearney extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_kearney()
	{
		$this->_cities = array(
			'axtell' => 'Axtell',
			'heartwell' => 'Heartwell',
			'minden' => 'Minden',
			'norman' => 'Norman',
			'wilcox' => 'Wilcox',
		);
	}

	function countyName()
	{
		return 'Kearney';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="KearneyCounty" id="KearneyCounty">' .
			'<area shape="rect" coords="273, 73, 369, 112" href="' . sprintf($urlpattern, 'heartwell') . '" alt="Heartwell"/>' .
			'<area shape="rect" coords="275, 147, 356, 184" href="' . sprintf($urlpattern, 'norman') . '" alt="Norman"/>' .
			'<area shape="rect" coords="152, 130, 224, 171" href="' . sprintf($urlpattern, 'minden') . '" alt="Minden"/>' .
			'<area shape="rect" coords="6, 239, 83, 277" href="' . sprintf($urlpattern, 'wilcox') . '" alt="Wilcox"/>' .
			'<area shape="rect" coords="16, 147, 87, 183" href="' . sprintf($urlpattern, 'axtell') . '" alt="Axtell"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'KearneyCounty';
	}	
	
	function imageMapImage() {
		return 'kearney.gif';
	}
	
}