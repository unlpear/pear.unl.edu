<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_blaine extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_blaine()
	{
		$this->_cities = array(
				'brewster' => 'Brewster',
				'dunning' => 'Dunning',
				'purdum' => 'Purdum',
			);
	}

	function countyName()
	{
		return 'Blaine';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="BlaineCounty" id="BlaineCounty">' .
			'<area shape="rect" coords="96, 161, 201, 202" href="' . sprintf($urlpattern, 'dunning') . '" alt="Dunning"/>' .
			'<area shape="rect" coords="257, 82, 379, 126" href="' . sprintf($urlpattern, 'brewster') . '" alt="Brewster"/>' .
			'<area shape="rect" coords="0, 0, 90, 41" href="' . sprintf($urlpattern, 'purdum') . '" alt="Purdum"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'BlaineCounty';
	}	
	
	function imageMapImage() {
		return 'blaine.gif';
	}
	
}