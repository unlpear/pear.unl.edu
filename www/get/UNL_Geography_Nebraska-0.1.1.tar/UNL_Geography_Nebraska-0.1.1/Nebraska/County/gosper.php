<?php
/**
 * Copyright 2005 CALMIT (http://calmit.unl.edu)
 * Copyright 2005 Ben Chavet <bchavet@calmit.unl.edu>
 *
 * See the enclosed file COPYING for license information (LGPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */


class UNL_Geography_Nebraska_County_gosper extends UNL_Geography_Nebraska_County {

	function UNL_Geography_Nebraska_County_gosper()
	{
		$this->_cities = array(
			'elwood' => 'Elwood',
			'smithfield' => 'Smithfield',
		);
	}

	function countyName()
	{
		return 'Gosper';
	}
	
	function imageMap($urlpattern = null)
	{
	
		if (empty($urlpattern)) {
			$urlpattern = '%s.php';
		}
		
		$map = '<map name="GosperCounty" id="GosperCounty">' .
			'<area shape="rect" coords="220, 85, 323, 125" href="' . sprintf($urlpattern, 'smithfield') . '" alt="Smithfield"/>' .
			'<area shape="rect" coords="143, 79, 216, 117" href="' . sprintf($urlpattern, 'elwood') . '" alt="Elwood"/>' .
			'</map>';

		return $map;
	}

	function imageMapName() {
		return 'GosperCounty';
	}	
	
	function imageMapImage() {
		return 'gosper.gif';
	}
	
}