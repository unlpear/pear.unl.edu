<?php
require_once 'CustomClass.php';

$page = new CustomClass();

echo $page;

?>