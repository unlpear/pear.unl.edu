<table class="monthwidget">
	<caption><?php echo $this->caption; ?></caption>
   <thead>
	<tr>
		<th abbr="Sunday" scope="col" title="Sunday">Sun</th>
		<th abbr="Monday" scope="col" title="Monday">Mon</th>
		<th abbr="Tuesday" scope="col" title="Tuesday">Tue</th>
		<th abbr="Wednesday" scope="col" title="Wednesday">Wed</th>
		<th abbr="Thursday" scope="col" title="Thursday">Thu</th>
		<th abbr="Friday" scope="col" title="Friday">Fri</th>
		<th abbr="Saturday" scope="col" title="Saturday">Sat</th>
	</tr>
	</thead>
	<tbody>
		<?php echo $this->tbody; ?>
	</tbody>
</table>