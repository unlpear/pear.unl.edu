<?php
/**
 * This example demonstrates the usage of the UNL Templates.
 *
 * 
 * @package UNL_Templates
 */

require_once ('UNL/Templates.php');
$page = UNL_Templates::factory(	'Fixed', array('sharedcodepath' => 'sharedcode'));
$page->titlegraphic		= "<h1>Hello UNL Templates Test Page</h1>";
$page->maincontentarea	= "<p>This is my main content.</p>";
$page->loadSharedcodeFiles();
echo $page->toHtml();
