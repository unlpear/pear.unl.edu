<?php
/**
 * College data for the UNL_Common package.
 * 
 * @author Brett Bieber
 * @package UNL_Common
 * Created on Mar 27, 2006
 */

/**
 * Class which holds an array of all the colleges on campus.
 * 
 * @package UNL_Common
 */
class UNL_Common_Colleges {
	var $colleges = array();
	function UNL_Common_Colleges()
	{
		$this->colleges[] = 'Business Administration';
		$this->colleges[] = 'Fine & Performing Arts';
		$this->colleges[] = 'Arts & Sciences';
		$this->colleges[] = 'Education and Human Sciences';
		$this->colleges[] = 'Journalism & Mass Communications';
		$this->colleges[] = 'Agricultural Sciences & Natural Resources';
		$this->colleges[] = 'Engineering';
		$this->colleges[] = 'Architecture';
		$this->colleges[] = 'College of Dentistry';
		$this->colleges[] = 'Law';
		array_multisort($this->colleges,SORT_ASC);
	}
	
	/**
	* Return all the codes
	*
	* @access  public
	* @return  array   all colleges as associative array
	*/
	function getAllColleges()
	{
		return $this->colleges;
	}
}
?>
