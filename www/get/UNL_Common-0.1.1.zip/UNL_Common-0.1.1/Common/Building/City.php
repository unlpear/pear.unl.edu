<?php
/**
* @author Brett Bieber
* Created on Sep 27, 2005
*/
class UNL_Common_Building_City
{
	var $codes = array();
	
	/**
	 * Constructor connects to database and loads codes and names.
	 * @return bool False on error
	 */
	function UNL_Common_Building_City()
	{
		$link = mysql_connect('biznas.unl.edu', 'unl_common');
		if (!$link) {
			return false;
		} else {
			mysql_select_db('unl_common');
			$query = 'SELECT * FROM building_city';
			$result = mysql_query($query) or die('Query failed: ' . mysql_error());
			while ($bldg = mysql_fetch_assoc($result)) {
				$this->codes[$bldg['code']]=$bldg['name'];
			}
			mysql_close($link);
		}
	}
}

?>
