<?php
/**
* @author Brett Bieber
* Created on Sep 27, 2005
*/
include('UNL/Common/Building.php');
include('HTML/QuickForm.php');
$bldgs = new UNL_Common_Building();
$form =& new HTML_QuickForm();
$form->addElement('select','buildings','Buildings',$bldgs->codes);
echo $form->toHtml();
?>
