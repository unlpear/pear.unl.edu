<?php if (!empty($this->message)): ?>
<p class="noentry"><?php echo $this->message; ?></p>
<?php endif; ?>